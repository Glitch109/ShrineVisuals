package com.shrine;

import com.shrine.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import static com.shrine.Gfx.*;

/**
 * The crosshair editor: a 13 x 13 grid. Left button paints, right button erases (the "Ластик" switch does the same without a
 * right button), the symmetry switches paint the mirrored pixels too. Ready-made pictures are one tap away.
 */
final class CrossEditScreen extends Screen {
    private static final int N = CrossHud.N;
    private static final int[] PAL = {0xFFFFFFFF, 0xFFBFBFBF, 0xFF7A7A7A, 0xFF000000, 0xFFFF4D4D, 0xFFFF9F43,
            0xFFFFE14D, 0xFF5CFF7A, 0xFF4DFFF1, 0xFF4DA6FF, 0xFFA64DFF, 0xFFFF4DE1};
    private static final float CELL = 26f, GAP = 2f, PITCH = CELL + GAP;

    private final Screen parent;
    private final Scene scene = new Scene();
    private int[] px = new int[N * N];
    private int color = 0;
    private boolean mirrorX = true, mirrorY = true, eraser;
    private boolean painting, paintErase;
    private float k = 1f, vw = 960f;
    private final long openedAt = Util.getMeasuringTimeMs();
    private final float[] rClear = new float[4], rMx = new float[4], rMy = new float[4], rEr = new float[4], rDone = new float[4];

    CrossEditScreen(Screen parent) {
        super(Text.literal("shrine"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        scene.init(width, height);
        scene.instantBackdrop = true;
        k = height / Scene.REF_H;
        vw = width / k;
        px = CrossHud.pixels().clone();
    }

    private float gx() { return vw / 2f - 380f; }
    private float gy() { return 86f; }
    private float rx() { return gx() + N * PITCH + 38f; }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        scene.begin(ctx, mxReal, myReal, delta);
        scene.stars(ctx, delta);
        float t = Math.min(1f, (Util.getMeasuringTimeMs() - openedAt) / 240f), a = 1f - (1f - t) * (1f - t);
        float mx = scene.mx, my = scene.my;
        ctx.fill(0, 0, Math.round(vw) + 1, Math.round(Scene.REF_H) + 1, argb(0.40f * a, 0x000000));

        text(ctx, textRenderer, Fnt.TITLE, "Редактор прицела", gx(), 44f, argb(0.95f * a, 0xFFFFFF));
        boolean invert = ShrineCfg.integer(CrossHud.K_STYLE, 0) == 0;
        text(ctx, textRenderer, Fnt.SMALL, invert ? "Стиль «как в игре»: цвет не важен, пиксели инвертируют фон" : "Стиль «сплошной»: цвета и прозрачность из настроек",
                gx() + 330f, 46f, argb(0.45f * a, 0xFFFFFF));

        // the grid
        float gx = gx(), gy = gy();
        box(ctx, RR, gx - 12f, gy - 12f, N * PITCH - GAP + 24f, N * PITCH - GAP + 24f, 16f, argb(0.85f * a, 0x15161A));
        for (int r = 0; r < N; r++) {
            for (int c = 0; c < N; c++) {
                float x = gx + c * PITCH, y = gy + r * PITCH;
                int v = px[r * N + c];
                boolean center = r == CrossHud.C && c == CrossHud.C;
                box(ctx, RR, x, y, CELL, CELL, 5f, argb((center ? 0.14f : 0.07f) * a, 0xFFFFFF));
                if ((v >>> 24) != 0) box(ctx, RR, x, y, CELL, CELL, 5f, argb(a, v & 0xFFFFFF));
            }
        }

        // right column
        float rx = rx(), y = 86f;
        text(ctx, textRenderer, Fnt.LABEL, "Цвет", rx, y, argb(0.6f * a, 0xFFFFFF));
        y += 18f;
        for (int i = 0; i < PAL.length; i++) {
            float x = rx + (i % 6) * 44f, yy = y + (i / 6) * 44f;
            box(ctx, RR, x, yy, 36f, 36f, 10f, argb(a, PAL[i] & 0xFFFFFF));
            if (PAL[i] == 0xFF000000) box(ctx, RR_RING, x, yy, 36f, 36f, 10f, argb(0.35f * a, 0xFFFFFF));
            if (i == color && !eraser) box(ctx, RR_RING, x - 4f, yy - 4f, 44f, 44f, 13f, argb(a, 0xFFFFFF));
        }
        y += 98f;
        set(rMx, rx, y, 150f, 34f); set(rMy, rx + 160f, y, 150f, 34f);
        pill(ctx, rMx, "Симметрия ↔", mirrorX, mx, my, a); pill(ctx, rMy, "Симметрия ↕", mirrorY, mx, my, a);
        y += 44f;
        set(rEr, rx, y, 150f, 34f); set(rClear, rx + 160f, y, 150f, 34f);
        pill(ctx, rEr, "Ластик", eraser, mx, my, a); pill(ctx, rClear, "Очистить", false, mx, my, a);
        y += 56f;
        text(ctx, textRenderer, Fnt.LABEL, "Готовые", rx, y, argb(0.6f * a, 0xFFFFFF));
        y += 16f;
        for (int i = 0; i < CrossHud.PRESET_NAMES.length; i++) {
            float x = rx + (i % 4) * 80f, yy = y + (i / 4) * 56f;
            boolean hv = inside(mx, my, x, yy, 70f, 50f);
            box(ctx, RR, x, yy, 70f, 50f, 10f, argb((hv ? 0.20f : 0.09f) * a, 0xFFFFFF));
            drawMini(ctx, CrossHud.preset(i), x + 35f - N * 1.5f, yy + 25f - N * 1.5f, 3f, a);
        }
        y += 118f;
        // live preview on a light and a dark ground
        box(ctx, RR, rx, y, 150f, 48f, 12f, argb(a, 0x7FA64A));
        box(ctx, RR, rx + 160f, y, 150f, 48f, 12f, argb(a, 0x25262B));
        // (the preview is drawn after the scene transform ends, in screen pixels)
        float p1x = (rx + 75f) * k, p2x = (rx + 235f) * k, py = (y + 24f) * k;

        set(rDone, vw / 2f - 120f, 494f, 240f, 40f);
        pill(ctx, rDone, "Готово", true, mx, my, a);
        scene.end(ctx);

        float scale = Math.max(0.5f, Math.min(5f, ShrineCfg.num(CrossHud.K_SCALE, 1f)));
        float op = Math.max(0.1f, Math.min(1f, ShrineCfg.num(CrossHud.K_OPACITY, 100f) / 100f));
        CrossHud.draw(ctx, px, p1x, py, scale, invert, op);
        CrossHud.draw(ctx, px, p2x, py, scale, invert, op);
    }

    private void drawMini(DrawContext ctx, int[] pic, float x0, float y0, float cell, float a) {
        for (int r = 0; r < N; r++) {
            for (int c = 0; c < N; c++) {
                int v = pic[r * N + c];
                if ((v >>> 24) != 0) box(ctx, RR, x0 + c * cell, y0 + r * cell, cell, cell, 0f, argb(0.95f * a, 0xFFFFFF));
            }
        }
    }

    private void pill(DrawContext ctx, float[] r, String label, boolean on, float mx, float my, float a) {
        boolean hv = inside(mx, my, r[0], r[1], r[2], r[3]);
        float rad = r[3] / 2f;
        if (on) box(ctx, RR, r[0], r[1], r[2], r[3], rad, argb(0.95f * a, 0xFFFFFF));
        else box(ctx, RR, r[0], r[1], r[2], r[3], rad, argb((hv ? 0.28f : 0.16f) * a, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.LABEL, label, r[0] + r[2] / 2f, r[1] + r[3] / 2f, argb(a, on ? 0x14101A : 0xFFFFFF));
    }

    private static void set(float[] r, float x, float y, float w, float h) { r[0] = x; r[1] = y; r[2] = w; r[3] = h; }

    // ---------- painting ----------
    private void paintAt(double mx, double my) {
        int c = (int) Math.floor((mx - gx()) / PITCH), r = (int) Math.floor((my - gy()) / PITCH);
        if (c < 0 || r < 0 || c >= N || r >= N) return;
        if (((mx - gx()) - c * PITCH) > CELL || ((my - gy()) - r * PITCH) > CELL) return;     // between cells
        put(c, r);
        if (mirrorX) put(N - 1 - c, r);
        if (mirrorY) put(c, N - 1 - r);
        if (mirrorX && mirrorY) put(N - 1 - c, N - 1 - r);
        CrossHud.setPixels(px);
    }

    private void put(int c, int r) { px[r * N + c] = paintErase ? 0 : PAL[color]; }

    private void close() { CrossHud.setPixels(px); ShrineCfg.save(); client.setScreen(parent); }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x() / k, my = click.y() / k;
        int b = click.button();
        if (b != 0 && b != 1) return true;
        if (b == 0) {
            if (inside(mx, my, rDone[0], rDone[1], rDone[2], rDone[3])) { close(); return true; }
            if (inside(mx, my, rMx[0], rMx[1], rMx[2], rMx[3])) { mirrorX = !mirrorX; return true; }
            if (inside(mx, my, rMy[0], rMy[1], rMy[2], rMy[3])) { mirrorY = !mirrorY; return true; }
            if (inside(mx, my, rEr[0], rEr[1], rEr[2], rEr[3])) { eraser = !eraser; return true; }
            if (inside(mx, my, rClear[0], rClear[1], rClear[2], rClear[3])) { px = new int[N * N]; CrossHud.setPixels(px); return true; }
            float rx = rx();
            for (int i = 0; i < PAL.length; i++) {
                if (inside(mx, my, rx + (i % 6) * 44f, 104f + (i / 6) * 44f, 36f, 36f)) { color = i; eraser = false; return true; }
            }
            float py0 = 86f + 18f + 98f + 44f + 56f + 16f;
            for (int i = 0; i < CrossHud.PRESET_NAMES.length; i++) {
                if (inside(mx, my, rx + (i % 4) * 80f, py0 + (i / 4) * 56f, 70f, 50f)) { px = CrossHud.preset(i); CrossHud.setPixels(px); return true; }
            }
        }
        painting = true;
        paintErase = b == 1 || eraser;
        paintAt(mx, my);
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (painting) paintAt(click.x() / k, click.y() / k);
        return true;
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (painting) { painting = false; ShrineCfg.save(); }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        return super.keyPressed(input);
    }

    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean shouldPause() { return false; }
}
