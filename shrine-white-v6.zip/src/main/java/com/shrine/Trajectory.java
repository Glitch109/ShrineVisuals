package com.shrine;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * "Траектории": while you hold something throwable (ender pearl, snowball, egg, potion, XP bottle, trident) or a drawn
 * bow / loaded crossbow, a thin line shows where it will fly and a flat marker shows where it lands. No block outline.
 * When the projectile would hit a creature the marker and the line turn red and the creature gets the vanilla glow
 * outline (like a spectral arrow), not a hitbox. Nothing is drawn around the projectile itself.
 */
final class Trajectory {
    private Trajectory() {}

    static final String KEY = "traj", K_GLOW = "traj.glow", K_WIDTH = "traj.width", K_RADIUS = "traj.radius", K_STYLE = "traj.style";
    static final String[] STYLES = {"Диск", "Кольцо"};

    static void init() {
        WorldRenderEvents.AFTER_ENTITIES.register(Trajectory::render);
    }

    // ---------------- projectile physics ----------------
    private record Shot(float speed, float gravity, float pitchOffset, boolean multi, boolean small) {
        Shot(float speed, float gravity, float pitchOffset) { this(speed, gravity, pitchOffset, false, false); }
    }

    private static boolean multishot(ItemStack s) {
        try {
            for (var e : s.getEnchantments().getEnchantments())
                if (e.getKey().map(k -> k.getValue().getPath().equals("multishot")).orElse(false)) return true;
        } catch (Throwable ignored) {}
        return false;
    }

    private static Shot shotFor(MinecraftClient mc, ItemStack s) {
        if (s.isEmpty()) return null;
        var it = s.getItem();
        if (it == Items.ENDER_PEARL || it == Items.SNOWBALL || it == Items.EGG) return new Shot(1.5f, 0.03f, 0f);
        if (it == Items.SPLASH_POTION || it == Items.LINGERING_POTION) return new Shot(0.5f, 0.05f, -20f);
        if (it == Items.EXPERIENCE_BOTTLE) return new Shot(0.7f, 0.07f, -20f);
        if (it == Items.BOW && mc.player.isUsingItem() && mc.player.getActiveItem().getItem() == it) {
            float pull = BowItem.getPullProgress(mc.player.getItemUseTime());
            return pull < 0.1f ? null : new Shot(pull * 3f, 0.05f, 0f, false, true);
        }
        if (it == Items.CROSSBOW && CrossbowItem.isCharged(s)) return new Shot(3.15f, 0.05f, 0f, multishot(s), true);
        if (it == Items.TRIDENT && mc.player.isUsingItem() && mc.player.getActiveItem().getItem() == it) return new Shot(2.5f, 0.05f, 0f, false, true);
        return null;
    }

    private static final class Sim {
        final List<Vec3d> pts = new ArrayList<>();
        Vec3d hit;
        net.minecraft.util.math.Direction side = net.minecraft.util.math.Direction.UP;
        Entity entity;
        boolean small;
    }

    private static List<Sim> simulate(MinecraftClient mc, float td) {
        var p = mc.player;
        Shot shot = shotFor(mc, p.getMainHandStack());
        if (shot == null) shot = shotFor(mc, p.getOffHandStack());
        if (shot == null) return null;

        List<Sim> out = new ArrayList<>();
        float[] angles = shot.multi() ? new float[]{-10f, 0f, 10f} : new float[]{0f};   // multishot: three lines
        for (float ang : angles) {
            Sim sim = simulateOne(mc, p, shot, ang, td);
            sim.small = shot.small();
            out.add(sim);
        }
        return out;
    }

    private static Sim simulateOne(MinecraftClient mc, net.minecraft.entity.player.PlayerEntity p, Shot shot, float angleDeg, float td) {
        float yaw = p.getYaw(td) * 0.017453292f, pitch = p.getPitch(td) * 0.017453292f;
        double dx = -Math.sin(yaw) * Math.cos(pitch);
        double dy = -Math.sin(pitch + shot.pitchOffset() * 0.017453292f);
        double dz = Math.cos(yaw) * Math.cos(pitch);
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        dx /= len; dy /= len; dz /= len;
        if (angleDeg != 0f) {                       // rotate the direction around the player's "up" axis
            double up = pitch - Math.PI / 2;
            double kx = -Math.sin(yaw) * Math.cos(up), ky = -Math.sin(up), kz = Math.cos(yaw) * Math.cos(up);
            double th = Math.toRadians(angleDeg), c = Math.cos(th), s = Math.sin(th);
            double cx = ky * dz - kz * dy, cy = kz * dx - kx * dz, cz = kx * dy - ky * dx;
            double dot = kx * dx + ky * dy + kz * dz;
            double nx = dx * c + cx * s + kx * dot * (1 - c);
            double ny = dy * c + cy * s + ky * dot * (1 - c);
            double nz = dz * c + cz * s + kz * dot * (1 - c);
            dx = nx; dy = ny; dz = nz;
        }
        Vec3d pv = p.getVelocity();
        Vec3d vel = new Vec3d(dx * shot.speed() + pv.x, dy * shot.speed() + (p.isOnGround() ? 0 : pv.y), dz * shot.speed() + pv.z);
        Vec3d pos = p.getLerpedPos(td).add(0, p.getStandingEyeHeight() - 0.1, 0);

        Sim sim = new Sim();
        sim.pts.add(pos);
        for (int i = 0; i < 200; i++) {
            Vec3d next = pos.add(vel);
            BlockHitResult bh = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            double bd = bh.getType() == HitResult.Type.MISS ? Double.MAX_VALUE : bh.getPos().squaredDistanceTo(pos);

            Entity best = null;
            Vec3d bestPos = null;
            double ed = Double.MAX_VALUE;
            Box sweep = new Box(pos, next).expand(1.0);
            for (Entity e : mc.world.getOtherEntities(p, sweep, e -> e instanceof LivingEntity && e.isAlive() && !e.isSpectator())) {
                Box bb = e.getBoundingBox().expand(0.3);
                Optional<Vec3d> r = bb.raycast(pos, next);
                if (r.isEmpty() && bb.contains(pos)) r = Optional.of(pos);
                if (r.isPresent()) {
                    double d = r.get().squaredDistanceTo(pos);
                    if (d < ed) { ed = d; best = e; bestPos = r.get(); }
                }
            }
            if (best != null && ed < bd) {
                sim.pts.add(bestPos);
                sim.hit = bestPos;
                sim.entity = best;
                return sim;
            }
            if (bd != Double.MAX_VALUE) {
                sim.pts.add(bh.getPos());
                sim.hit = bh.getPos();
                sim.side = bh.getSide();
                return sim;
            }
            pos = next;
            sim.pts.add(pos);
            vel = new Vec3d(vel.x * 0.99, vel.y * 0.99 - shot.gravity(), vel.z * 0.99);
            if (pos.y < mc.world.getBottomY() - 8) break;
        }
        return sim;                         // never landed within range: only the line
    }

    // ---------------- entity glow ----------------
    private static Entity glowing;
    private static boolean glowingWasOn;

    private static void setGlow(Entity e) {
        if (e == glowing) return;
        if (glowing != null && !glowingWasOn) glowing.setGlowing(false);
        glowing = e;
        if (e != null) { glowingWasOn = e.isGlowing(); e.setGlowing(true); }
    }

    // ---------------- camera (found by signature, so it does not depend on the method name) ----------------
    private static Method camPosM, tickM;

    private static Vec3d camPos(MinecraftClient mc) {
        try {
            Camera c = mc.gameRenderer.getCamera();
            if (camPosM == null)
                for (Method m : Camera.class.getMethods())
                    if (m.getParameterCount() == 0 && m.getReturnType() == Vec3d.class) { camPosM = m; break; }
            return camPosM == null ? null : (Vec3d) camPosM.invoke(c);
        } catch (Throwable t) { return null; }
    }

    private static float tickDelta(MinecraftClient mc) {
        try {
            Object c = mc.getRenderTickCounter();
            if (tickM == null)
                for (Method m : c.getClass().getMethods())
                    if (m.getParameterCount() == 1 && m.getParameterTypes()[0] == boolean.class && m.getReturnType() == float.class) { tickM = m; break; }
            return tickM == null ? 1f : (float) tickM.invoke(c, false);
        } catch (Throwable t) { return 1f; }
    }

    // ---------------- render layer (looked up by its name, because the factory method names differ between versions) ----------------
    private static RenderLayer cachedLayer;
    private static boolean layerTried;

    private static RenderLayer layer() {
        if (layerTried) return cachedLayer;
        layerTried = true;
        List<RenderLayer> found = new ArrayList<>();
        for (Method m : RenderLayer.class.getMethods()) {
            if (!java.lang.reflect.Modifier.isStatic(m.getModifiers()) || m.getParameterCount() != 0 || m.getReturnType() != RenderLayer.class) continue;
            try { Object o = m.invoke(null); if (o instanceof RenderLayer l) found.add(l); } catch (Throwable ignored) {}
        }
        for (String want : new String[]{"debug_quads", "lightning"})
            for (RenderLayer l : found)
                if (String.valueOf(l).toLowerCase(java.util.Locale.ROOT).contains(want)) return cachedLayer = l;
        return null;
    }

    // ---------------- drawing ----------------
    private static boolean failed;

    private static void render(WorldRenderContext ctx) {
        if (failed) return;
        try {
            draw(ctx);
        } catch (Throwable t) {
            failed = true;
            setGlow(null);
            t.printStackTrace();
        }
    }

    private static void draw(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || !ShrineCfg.bool(KEY, true)) { setGlow(null); return; }
        List<Sim> sims = simulate(mc, tickDelta(mc));
        if (sims == null) { setGlow(null); return; }

        Entity target = null;
        for (Sim s : sims) if (s.entity != null) { target = s.entity; break; }
        setGlow(target != null && ShrineCfg.bool(K_GLOW, true) ? target : null);

        Vec3d cam = camPos(mc);
        if (cam == null) return;
        RenderLayer layer = layer();
        if (layer == null || ctx.consumers() == null) return;     // no suitable layer in this game build: draw nothing
        MatrixStack ms = ctx.matrices();
        Matrix4f m = ms != null ? ms.peek().getPositionMatrix() : new Matrix4f();   // camera-relative coordinates
        VertexConsumer vc = ctx.consumers().getBuffer(layer);
        float half = ShrineCfg.num(K_WIDTH, 0.03f) / 2f;
        for (Sim sim : sims) drawOne(vc, m, cam, sim, half);
    }

    private static void drawOne(VertexConsumer vc, Matrix4f m, Vec3d cam, Sim sim, float half) {
        boolean red = sim.entity != null;
        int rgb = red ? 0xFF3A3A : 0xFFFFFF;

        // line: a flat ribbon that always faces the camera
        int n = sim.pts.size();
        for (int i = 0; i + 1 < n; i++) {
            Vec3d a = sim.pts.get(i).subtract(cam), b = sim.pts.get(i + 1).subtract(cam);
            Vec3d d = b.subtract(a);
            Vec3d side = d.crossProduct(a.add(b).multiply(0.5));
            if (side.lengthSquared() < 1e-9) continue;
            side = side.normalize().multiply(half);
            int al = (int) (215 * (1f - 0.45f * i / Math.max(1, n)));        // fades slightly towards the end
            quad(vc, m, a.add(side), a.subtract(side), b.subtract(side), b.add(side), (al << 24) | rgb);
        }

        // landing marker: a flat disc (or ring) lying on the surface; on a creature it lies on the ground under its feet
        if (sim.hit == null) return;
        Vec3d center = sim.hit;
        Vec3d nrm = Vec3d.of(sim.side.getVector());
        float r = ShrineCfg.num(K_RADIUS, 0.7f);
        if (red) {
            center = new Vec3d(sim.entity.getX(), sim.entity.getY(), sim.entity.getZ());
            nrm = new Vec3d(0, 1, 0);
            r = Math.max(r * 0.6f, sim.entity.getWidth() * 0.9f);
        } else if (sim.small) {
            r *= 0.4f;                                  // arrows: a small ring, like in the video
        }
        boolean ring = ShrineCfg.integer(K_STYLE, 0) == 1 || sim.small;
        Vec3d c = center.subtract(cam).add(nrm.multiply(0.012));
        Vec3d u = Math.abs(nrm.y) > 0.9 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0).crossProduct(nrm).normalize();
        Vec3d v = nrm.crossProduct(u);
        double inner = sim.small && !red ? 0.7 : 0.86;
        int seg = 40;
        for (int i = 0; i < seg; i++) {
            double a0 = i * Math.PI * 2 / seg, a1 = (i + 1) * Math.PI * 2 / seg;
            Vec3d p0 = c.add(u.multiply(Math.cos(a0) * r)).add(v.multiply(Math.sin(a0) * r));
            Vec3d p1 = c.add(u.multiply(Math.cos(a1) * r)).add(v.multiply(Math.sin(a1) * r));
            Vec3d q0 = c.add(u.multiply(Math.cos(a0) * r * inner)).add(v.multiply(Math.sin(a0) * r * inner));
            Vec3d q1 = c.add(u.multiply(Math.cos(a1) * r * inner)).add(v.multiply(Math.sin(a1) * r * inner));
            quad(vc, m, q0, p0, p1, q1, (230 << 24) | rgb);                 // outer rim
            if (!ring) quad(vc, m, c, q0, q1, c, (88 << 24) | rgb);          // translucent fill
        }
    }

    private static void quad(VertexConsumer vc, Matrix4f m, Vec3d a, Vec3d b, Vec3d c, Vec3d d, int argb) {
        vc.vertex(m, (float) a.x, (float) a.y, (float) a.z).color(argb);
        vc.vertex(m, (float) b.x, (float) b.y, (float) b.z).color(argb);
        vc.vertex(m, (float) c.x, (float) c.y, (float) c.z).color(argb);
        vc.vertex(m, (float) d.x, (float) d.y, (float) d.z).color(argb);
        // the same quad backwards, so it is visible from both sides whatever the layer's culling is
        vc.vertex(m, (float) d.x, (float) d.y, (float) d.z).color(argb);
        vc.vertex(m, (float) c.x, (float) c.y, (float) c.z).color(argb);
        vc.vertex(m, (float) b.x, (float) b.y, (float) b.z).color(argb);
        vc.vertex(m, (float) a.x, (float) a.y, (float) a.z).color(argb);
    }
}
