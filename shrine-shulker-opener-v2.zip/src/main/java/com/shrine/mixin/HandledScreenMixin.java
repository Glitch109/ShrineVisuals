package com.shrine.mixin;

import com.shrine.ShulkerOpener;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Lets {@link ShulkerOpener} take a Shift + left click on a shulker box before the game turns it into a quick-move. */
@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {
    @Inject(method = "mouseClicked(Lnet/minecraft/client/gui/Click;Z)Z", at = @At("HEAD"), cancellable = true)
    private void shrine$openShulker(Click click, boolean doubled, CallbackInfoReturnable<Boolean> cir) {
        try {
            if (ShulkerOpener.onInventoryClick((HandledScreen<?>) (Object) this, click)) cir.setReturnValue(true);
        } catch (Throwable t) {
            System.err.println("[Shrine] shulker opener: " + t);
        }
    }
}
