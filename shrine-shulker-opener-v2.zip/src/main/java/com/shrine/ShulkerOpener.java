package com.shrine;

import com.shrine.mixin.HandledScreenAccessor;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.SimpleNamedScreenHandlerFactory;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Util;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Utility > "Shulker Opener": open a shulker box without placing it.
 * <ul>
 *   <li>in an open inventory / chest: Shift + left click on the box;</li>
 *   <li>in the hand: Shift + click (instead of placing the box it opens).</li>
 * </ul>
 * It opens the REAL container, so items can be taken out and put in, and they stay in the box. A container that is not
 * placed anywhere exists only on the server, so this works where the client has the server in its own hands: singleplayer
 * and the host of a LAN world. On somebody else's server the vanilla protocol has no way to do it, so the mod does nothing
 * there (vanilla behavior stays) and says so once in a while.
 */
public final class ShulkerOpener {
    private ShulkerOpener() {}

    static final String KEY = "ut.shulker", K_INV = "ut.shulker.inv", K_HAND = "ut.shulker.hand", K_BTN = "ut.shulker.btn";
    static final String[] BUTTONS = {"ЛКМ и ПКМ", "Только ЛКМ", "Только ПКМ"};
    private static long lastToast;

    static void register() {
        ClientTickEvents.START_CLIENT_TICK.register(ShulkerOpener::tick);
    }

    static boolean isShulker(ItemStack st) {
        return st != null && !st.isEmpty() && Registries.ITEM.getId(st.getItem()).getPath().endsWith("shulker_box");
    }

    private static void toast(MinecraftClient mc) {
        long now = Util.getMeasuringTimeMs();
        if (now - lastToast < 4000L || mc.player == null) return;
        lastToast = now;
        mc.player.sendMessage(Text.literal("Открыть шалкер без установки можно только в своём мире (одиночная игра или хост LAN)"), true);
    }

    /** Shift is read from GLFW: the game's own helper for it changed between versions. */
    private static boolean shiftDown() {
        long w = GLFW.glfwGetCurrentContext();
        return GLFW.glfwGetKey(w, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(w, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
    }

    // ---------- inventory: Shift + left click (called from the HandledScreen mixin) ----------
    public static boolean onInventoryClick(HandledScreen<?> screen, Click click) {
        if (click.button() != 0 || !shiftDown()) return false;
        if (!ShrineCfg.bool(KEY, false) || !ShrineCfg.bool(K_INV, true)) return false;
        Slot slot = ((HandledScreenAccessor) screen).shrine$focusedSlot();
        if (slot == null || !isShulker(slot.getStack())) return false;
        if (!screen.getScreenHandler().getCursorStack().isEmpty()) return false;       // carrying something: leave the click to the game
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getServer() == null) { toast(mc); return false; }                       // not our server: vanilla shift-click stays
        open(mc, slot.id, null);
        return true;
    }

    // ---------- hand: Shift + click with the box in hand ----------
    private static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.currentScreen != null) return;
        if (!ShrineCfg.bool(KEY, false) || !ShrineCfg.bool(K_HAND, true)) return;
        Hand hand = isShulker(mc.player.getMainHandStack()) ? Hand.MAIN_HAND : isShulker(mc.player.getOffHandStack()) ? Hand.OFF_HAND : null;
        if (hand == null) return;
        if (!(mc.player.isSneaking() || mc.options.sneakKey.isPressed())) return;
        int btn = ShrineCfg.integer(K_BTN, 0);
        boolean use = btn != 1, attack = btn != 2;
        if (mc.getServer() == null) {
            if ((use && mc.options.useKey.isPressed()) || (attack && mc.options.attackKey.isPressed())) toast(mc);
            return;                                                                    // nothing consumed: the game places the box as usual
        }
        boolean fired = false;
        if (use) { while (mc.options.useKey.wasPressed()) fired = true; }              // eat the click so the box is not placed
        if (attack) { while (mc.options.attackKey.wasPressed()) fired = true; }
        if (!fired) return;
        if (use) mc.options.useKey.setPressed(false);
        if (attack) mc.options.attackKey.setPressed(false);
        open(mc, -1, hand);
    }

    // ---------- opening (on the server thread) ----------
    private static void open(MinecraftClient mc, int slotId, Hand hand) {
        MinecraftServer server = mc.getServer();
        if (server == null || mc.player == null) return;
        UUID id = mc.player.getUuid();
        server.execute(() -> {
            try {
                ServerPlayerEntity sp = server.getPlayerManager().getPlayer(id);
                if (sp == null) return;
                ItemStack box;
                if (hand != null) box = sp.getStackInHand(hand);
                else {
                    if (slotId < 0 || slotId >= sp.currentScreenHandler.slots.size()) return;
                    box = sp.currentScreenHandler.getSlot(slotId).getStack();
                }
                if (isShulker(box)) openReal(sp, box);
            } catch (Throwable t) {
                System.err.println("[Shrine] could not open the shulker box: " + t);
            }
        });
    }

    private static void openReal(ServerPlayerEntity sp, ItemStack box) {
        SimpleInventory inv = new SimpleInventory(27);
        ContainerComponent cc = box.get(DataComponentTypes.CONTAINER);
        if (cc != null) {
            List<ItemStack> list = cc.stream().toList();
            for (int i = 0; i < list.size() && i < 27; i++) inv.setStack(i, list.get(i));
        }
        inv.addListener(sender -> save(box, inv));                                     // every change goes straight into the box
        sp.openHandledScreen(new SimpleNamedScreenHandlerFactory((syncId, playerInv, player) -> new Guarded(syncId, playerInv, inv, box), box.getName()));
    }

    private static void save(ItemStack box, SimpleInventory inv) {
        List<ItemStack> out = new ArrayList<>(27);
        for (int i = 0; i < 27; i++) out.add(inv.getStack(i).copy());
        box.set(DataComponentTypes.CONTAINER, ContainerComponent.fromStacks(out));
    }

    /** The vanilla shulker screen, but the box being edited cannot be moved while it is open (that would lose or duplicate items). */
    private static final class Guarded extends ShulkerBoxScreenHandler {
        private final ItemStack box;

        Guarded(int syncId, PlayerInventory playerInv, SimpleInventory inv, ItemStack box) {
            super(syncId, playerInv, inv);
            this.box = box;
        }

        @Override
        public void onSlotClick(int slotIndex, int button, SlotActionType actionType, PlayerEntity player) {
            if (slotIndex >= 0 && slotIndex < this.slots.size() && this.getSlot(slotIndex).getStack() == box) return;
            if (actionType == SlotActionType.SWAP) {                                  // number keys / F swap with a hotbar or offhand slot
                if (button >= 0 && button < 9 && player.getInventory().getStack(button) == box) return;
                if (button == 40 && player.getOffHandStack() == box) return;
            }
            super.onSlotClick(slotIndex, button, actionType, player);
        }
    }
}
