package com.shrine;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;

import static com.shrine.Gfx.*;

/**
 * Hud > "Кастомный прицел": replaces the vanilla crosshair with a configurable one.
 * Eight styles, color, outline, attack-cooldown indicator, spread while moving and a pulse when you hit someone.
 * The same {@link #draw} is used by the HUD and by the editor ({@link CrosshairScreen}), which also stores presets
 * and exports / imports a crosshair as a text code. While the switch is off the vanilla crosshair is drawn untouched.
 */
final class CustomCrosshair {
    private CustomCrosshair() {}

    static final String KEY = "xh.on", K_STYLE = "xh.style", K_SIZE = "xh.size", K_THICK = "xh.thick", K_GAP = "xh.gap",
            K_COLOR = "xh.color", K_ALPHA = "xh.alpha", K_OUTLINE = "xh.outline", K_TARGET = "xh.target",
            K_CD = "xh.cd", K_MOVE = "xh.move", K_HIT = "xh.hit";
    static final String[] STYLES = {"Крест", "Точка", "Круг", "Круг+точка", "Квадрат", "Т-образ", "Х-образ", "Уголки"};
    static final int MAX_PRESETS = 12;
    private static final String CODE_PREFIX = "SHXH1:";
    private static final int TARGET_RGB = 0xFF5A5A;

    /** One complete crosshair look. */
    record Look(int style, int size, int thick, int gap, int color, float alpha,
                boolean outline, boolean target, boolean cd, boolean move, boolean hit) {
        int rgb() { return ShrineGui.PALETTE[clamp(color, 0, ShrineGui.PALETTE.length - 1)]; }
        Look withStyle(int s) { return new Look(s, size, thick, gap, color, alpha, outline, target, cd, move, hit); }
    }

    static Look defaults() { return new Look(0, 5, 1, 3, 1, 1f, true, true, true, false, true); }

    static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    // ---------- settings <-> look ----------
    static Look current() {
        return new Look(
                clamp(ShrineCfg.integer(K_STYLE, 0), 0, STYLES.length - 1),
                clamp(Math.round(ShrineCfg.num(K_SIZE, 5f)), 1, 20),
                clamp(Math.round(ShrineCfg.num(K_THICK, 1f)), 1, 6),
                clamp(Math.round(ShrineCfg.num(K_GAP, 3f)), 0, 12),
                clamp(ShrineCfg.integer(K_COLOR, 1), 0, ShrineGui.PALETTE.length - 1),
                Math.max(0.1f, Math.min(1f, ShrineCfg.num(K_ALPHA, 1f))),
                ShrineCfg.bool(K_OUTLINE, true), ShrineCfg.bool(K_TARGET, true), ShrineCfg.bool(K_CD, true),
                ShrineCfg.bool(K_MOVE, false), ShrineCfg.bool(K_HIT, true));
    }

    static void apply(Look l) {
        ShrineCfg.setInt(K_STYLE, l.style()); ShrineCfg.setInt(K_SIZE, l.size()); ShrineCfg.setInt(K_THICK, l.thick());
        ShrineCfg.setInt(K_GAP, l.gap()); ShrineCfg.setInt(K_COLOR, l.color()); ShrineCfg.setNum(K_ALPHA, l.alpha());
        ShrineCfg.setBool(K_OUTLINE, l.outline()); ShrineCfg.setBool(K_TARGET, l.target()); ShrineCfg.setBool(K_CD, l.cd());
        ShrineCfg.setBool(K_MOVE, l.move()); ShrineCfg.setBool(K_HIT, l.hit());
        ShrineCfg.save();
    }

    // ---------- text code (copy / paste) ----------
    private static String b(boolean v) { return v ? "1" : "0"; }

    static String encode(Look l) {
        return CODE_PREFIX + l.style() + "," + l.size() + "," + l.thick() + "," + l.gap() + "," + l.color() + ","
                + Math.round(l.alpha() * 100f) + "," + b(l.outline()) + "," + b(l.target()) + "," + b(l.cd()) + ","
                + b(l.move()) + "," + b(l.hit());
    }

    /** Returns null when the text is not a crosshair code. */
    static Look decode(String code) {
        if (code == null) return null;
        code = code.trim();
        if (!code.startsWith(CODE_PREFIX)) return null;
        String[] p = code.substring(CODE_PREFIX.length()).split(",");
        if (p.length < 10) return null;
        try {
            return new Look(
                    clamp(Integer.parseInt(p[0].trim()), 0, STYLES.length - 1),
                    clamp(Integer.parseInt(p[1].trim()), 1, 20),
                    clamp(Integer.parseInt(p[2].trim()), 1, 6),
                    clamp(Integer.parseInt(p[3].trim()), 0, 12),
                    clamp(Integer.parseInt(p[4].trim()), 0, ShrineGui.PALETTE.length - 1),
                    clamp(Integer.parseInt(p[5].trim()), 10, 100) / 100f,
                    "1".equals(p[6].trim()), "1".equals(p[7].trim()), "1".equals(p[8].trim()), "1".equals(p[9].trim()),
                    p.length < 11 || "1".equals(p[10].trim()));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    // ---------- presets ("Мои пресеты") ----------
    static int presetCount() { return clamp(ShrineCfg.integer("xh.pn", 0), 0, MAX_PRESETS); }
    static String presetName(int i) { return ShrineCfg.str("xh.p." + i + ".name", "Прицел " + (i + 1)); }
    static Look presetLook(int i) { return decode(ShrineCfg.str("xh.p." + i + ".code", "")); }

    static boolean addPreset(Look l) {
        int n = presetCount();
        if (n >= MAX_PRESETS) return false;
        int id = ShrineCfg.integer("xh.pc", 0) + 1;
        ShrineCfg.setInt("xh.pc", id);
        ShrineCfg.setStr("xh.p." + n + ".name", "Прицел " + id);
        ShrineCfg.setStr("xh.p." + n + ".code", encode(l));
        ShrineCfg.setInt("xh.pn", n + 1);
        ShrineCfg.save();
        return true;
    }

    static void removePreset(int i) {
        int n = presetCount();
        if (i < 0 || i >= n) return;
        for (int j = i; j < n - 1; j++) {
            ShrineCfg.setStr("xh.p." + j + ".name", ShrineCfg.str("xh.p." + (j + 1) + ".name", ""));
            ShrineCfg.setStr("xh.p." + j + ".code", ShrineCfg.str("xh.p." + (j + 1) + ".code", ""));
        }
        ShrineCfg.setInt("xh.pn", n - 1);
        ShrineCfg.save();
    }

    // ---------- in-game element ----------
    private static float moveGap, hitGap;   // smoothed extra spread

    static void register() {
        // The original element is kept so the vanilla crosshair comes back when the switch is off.
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (ctx, tick) -> {
            if (!ShrineCfg.bool(KEY, false)) { original.render(ctx, tick); return; }
            render(ctx);
        });
    }

    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson()) return;
        Look l = current();

        float moveTarget = l.move() ? (float) Math.min(1.0, mc.player.getVelocity().horizontalLength() / 0.28) * 5f : 0f;
        moveGap += (moveTarget - moveGap) * 0.2f;
        float hitTarget = l.hit() && mc.targetedEntity instanceof LivingEntity le && le.hurtTime > 0 ? 4f : 0f;
        hitGap += (hitTarget - hitGap) * 0.35f;

        int cx = mc.getWindow().getScaledWidth() / 2, cy = mc.getWindow().getScaledHeight() / 2;
        draw(ctx, cx, cy, l, mc.player.getAttackCooldownProgress(0f), mc.targetedEntity != null, moveGap + hitGap);
    }

    // ---------- drawing (HUD, editor tiles, editor preview) ----------
    static void draw(DrawContext ctx, int cx, int cy, Look l, float cooldown, boolean aimed, float spread) {
        int rgb = l.target() && aimed ? TARGET_RGB : l.rgb();
        float alpha = l.alpha();
        boolean showCd = l.cd() && cooldown < 1f;
        if (showCd) alpha *= 0.4f + 0.6f * cooldown;
        int extra = Math.max(0, Math.round(spread));
        int col = argb(alpha, rgb), dark = argb(alpha * 0.85f, 0x000000);

        if (l.outline()) shapes(ctx, cx, cy, l, extra, col, dark, true);   // outlines first, so arms do not cover each other
        shapes(ctx, cx, cy, l, extra, col, dark, false);

        if (showCd) {                                      // thin attack-cooldown bar under the crosshair
            int half = Math.max(6, l.size() + l.gap() + extra + 2), y = cy + l.size() + l.gap() + extra + 7;
            ctx.fill(cx - half, y, cx + half, y + 2, argb(0.35f, 0x000000));
            ctx.fill(cx - half, y, cx - half + Math.round(half * 2 * cooldown), y + 2, argb(0.9f, rgb));
        }
    }

    private static void shapes(DrawContext ctx, int cx, int cy, Look l, int extra, int col, int dark, boolean o) {
        int size = l.size(), t = l.thick(), t0 = t / 2, t1 = t - t0, gap = l.gap() + extra;
        switch (l.style()) {
            case 1 -> {                                   // dot
                int r = Math.max(1, t);
                rect(ctx, cx - r, cy - r, cx + r, cy + r, col, dark, o);
            }
            case 2 -> ring(ctx, cx, cy, size + extra / 2, col, dark, o);
            case 3 -> {                                   // ring + dot
                ring(ctx, cx, cy, size + extra / 2, col, dark, o);
                rect(ctx, cx - 1, cy - 1, cx + 1, cy + 1, col, dark, o);
            }
            case 4 -> {                                   // square frame
                int a = size + extra / 2, w = Math.min(t, a);
                rect(ctx, cx - a, cy - a, cx + a, cy - a + w, col, dark, o);
                rect(ctx, cx - a, cy + a - w, cx + a, cy + a, col, dark, o);
                rect(ctx, cx - a, cy - a + w, cx - a + w, cy + a - w, col, dark, o);
                rect(ctx, cx + a - w, cy - a + w, cx + a, cy + a - w, col, dark, o);
            }
            case 5 -> {                                   // T shape: no top arm
                rect(ctx, cx - gap - size, cy - t0, cx - gap, cy + t1, col, dark, o);
                rect(ctx, cx + gap, cy - t0, cx + gap + size, cy + t1, col, dark, o);
                rect(ctx, cx - t0, cy + gap, cx + t1, cy + gap + size, col, dark, o);
            }
            case 6 -> {                                   // X: four diagonals
                for (int i = 0; i < size; i++) {
                    int d = gap + i;
                    rect(ctx, cx + d - t0, cy + d - t0, cx + d + t1, cy + d + t1, col, dark, o);
                    rect(ctx, cx - d - t0, cy + d - t0, cx - d + t1, cy + d + t1, col, dark, o);
                    rect(ctx, cx + d - t0, cy - d - t0, cx + d + t1, cy - d + t1, col, dark, o);
                    rect(ctx, cx - d - t0, cy - d - t0, cx - d + t1, cy - d + t1, col, dark, o);
                }
            }
            case 7 -> {                                   // corner brackets
                int a = size + extra + 2, arm = Math.max(2, size * 2 / 3);
                for (int sx = -1; sx <= 1; sx += 2) {
                    for (int sy = -1; sy <= 1; sy += 2) {
                        int x0 = cx + sx * a, y0 = cy + sy * a, x1 = cx + sx * (a - arm), y1 = cy + sy * (a - arm);
                        rect(ctx, Math.min(x0, x1), y0 - t0, Math.max(x0, x1), y0 + t1, col, dark, o);   // horizontal
                        rect(ctx, x0 - t0, Math.min(y0, y1), x0 + t1, Math.max(y0, y1), col, dark, o);   // vertical
                    }
                }
            }
            default -> {                                  // cross with a gap in the middle
                rect(ctx, cx - gap - size, cy - t0, cx - gap, cy + t1, col, dark, o);   // left
                rect(ctx, cx + gap, cy - t0, cx + gap + size, cy + t1, col, dark, o);   // right
                rect(ctx, cx - t0, cy - gap - size, cx + t1, cy - gap, col, dark, o);   // top
                rect(ctx, cx - t0, cy + gap, cx + t1, cy + gap + size, col, dark, o);   // bottom
            }
        }
    }

    private static void ring(DrawContext ctx, int cx, int cy, int size, int col, int dark, boolean o) {
        float d = size * 2f + 4f;
        if (o) centered(ctx, RING, cx, cy, d + 2f, d + 2f, dark);
        else centered(ctx, RING, cx, cy, d, d, col);
    }

    /** Outline pass: a dark rectangle 1px bigger; fill pass: the colored rectangle. */
    private static void rect(DrawContext ctx, int x1, int y1, int x2, int y2, int col, int dark, boolean o) {
        if (o) ctx.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, dark);
        else ctx.fill(x1, y1, x2, y2, col);
    }
}
