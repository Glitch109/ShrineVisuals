package com.shrine;

import com.shrine.CustomCrosshair.Look;
import com.shrine.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import static com.shrine.Gfx.*;

/**
 * Editor of the custom crosshair (Hud > Кастомный прицел > Редактор): live preview on a dark and a light background,
 * style tiles, color swatches, "My presets" (left click loads, right click deletes) and copy / paste of a crosshair code.
 * Size, thickness, gap and the other sliders stay in the settings window.
 */
final class CrosshairScreen extends Screen {
    private final Screen parent;
    private final long openedAt = Util.getMeasuringTimeMs();
    private float k = 1f, vw = 960f;
    private String status = "";
    private long statusAt;

    CrosshairScreen(Screen parent) {
        super(Text.literal("Shrine"));
        this.parent = parent;
    }

    @Override protected void init() { k = height / Scene.REF_H; vw = width / k; }
    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }

    // ---------- layout (virtual units) ----------
    private float lx() { return vw / 2f - 350f; }
    private float rx() { return vw / 2f + 6f; }
    private float[] preview() { return new float[]{lx(), 84f, 300f, 240f}; }
    private float[] tile(int i) { return new float[]{rx() + (i % 4) * 86f, 84f + (i / 4) * 76f, 80f, 70f}; }
    private float[] swatch(int i) { return new float[]{rx() + 12f + i * 31f, 262f}; }
    private float[] btn(int i) { return new float[]{rx() + (i % 2) * 172f, 300f + (i / 2) * 46f, 166f, 38f}; }
    private float[] preset(int i) { return new float[]{lx() + (i % 4) * 76f, 348f + (i / 4) * 38f, 70f, 32f}; }
    private float[] done() { return new float[]{vw / 2f - 65f, Scene.REF_H - 74f, 130f, 40f}; }
    private static final String[] BTN = {"Сохранить", "Копировать код", "Вставить код", "Сбросить"};

    private void say(String s) { status = s; statusAt = Util.getMeasuringTimeMs(); }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        ctx.fillGradient(0, 0, width, height, argb(0.62f, 0x050505), argb(0.80f, 0x161616));
        float mx = mxReal / k, my = myReal / k;
        long now = Util.getMeasuringTimeMs();
        Look cur = CustomCrosshair.current();

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);

        textC(ctx, textRenderer, Fnt.UI_B, "Кастомный прицел", vw / 2f, 44, argb(1f, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.SMALL, "Размер, толщина, зазор и остальное - в окне настроек", vw / 2f, 64, argb(0.55f, 0xFFFFFF));

        // preview: dark half and light half, attack charge and aiming cycle on their own
        float[] pv = preview();
        box(ctx, RR, pv[0], pv[1], pv[2], pv[3], 20, argb(1f, 0x151515));
        ctx.fill(Math.round(pv[0] + 150f), Math.round(pv[1] + 14f), Math.round(pv[0] + pv[2] - 14f), Math.round(pv[1] + pv[3] - 14f), 0xFFD8D8D8);
        long ms = now - openedAt;
        float cd = Math.min(1f, (ms % 2400L) / 2000f);
        boolean aimed = (ms / 1500L) % 2L == 1L;
        float spread = cur.move() ? 2.5f * (0.5f + 0.5f * (float) Math.sin(ms / 500.0)) : 0f;
        if (cur.hit() && aimed && ms % 1500L < 200L) spread += 4f;
        drawPreview(ctx, pv[0] + 78f, pv[1] + pv[3] / 2f, cur, cd, aimed, spread);
        drawPreview(ctx, pv[0] + 218f, pv[1] + pv[3] / 2f, cur, cd, aimed, spread);

        // style tiles
        for (int i = 0; i < CustomCrosshair.STYLES.length; i++) {
            float[] r = tile(i);
            boolean hov = inside(mx, my, r[0], r[1], r[2], r[3]), sel = i == cur.style();
            box(ctx, RR, r[0], r[1], r[2], r[3], 14, argb(sel ? 0.20f : hov ? 0.16f : 0.08f, 0xFFFFFF));
            if (sel) box(ctx, RR_RING, r[0], r[1], r[2], r[3], 14, argb(0.9f, ACCENT));
            Look mini = new Look(i, Math.min(cur.size(), 8), cur.thick(), Math.min(cur.gap(), 4), cur.color(), 1f,
                    cur.outline(), false, false, false, false);
            ctx.getMatrices().pushMatrix();
            ctx.getMatrices().translate(r[0] + r[2] / 2f, r[1] + 27f);
            ctx.getMatrices().scale(2f / k, 2f / k);
            CustomCrosshair.draw(ctx, 0, 0, mini, 1f, false, 0f);
            ctx.getMatrices().popMatrix();
            textC(ctx, textRenderer, Fnt.SMALL, CustomCrosshair.STYLES[i], r[0] + r[2] / 2f, r[1] + r[3] - 11f,
                    argb(sel ? 1f : 0.75f, 0xFFFFFF));
        }

        // color swatches
        for (int i = 0; i < ShrineGui.PALETTE.length; i++) {
            float[] c = swatch(i);
            centered(ctx, DISC, c[0], c[1], 22, 22, argb(1f, ShrineGui.PALETTE[i]));
            if (i == cur.color()) centered(ctx, RING, c[0], c[1], 30, 30, argb(1f, 0xFFFFFF));
        }

        // buttons
        for (int i = 0; i < BTN.length; i++) button(ctx, btn(i), BTN[i], false, mx, my);
        button(ctx, done(), "Готово", true, mx, my);

        // presets
        textC(ctx, textRenderer, Fnt.SMALL, "Мои пресеты  -  ПКМ удалить", lx() + 150f, 338f, argb(0.65f, 0xFFFFFF));
        int n = CustomCrosshair.presetCount();
        if (n == 0) textC(ctx, textRenderer, Fnt.SMALL, "Пока пусто. Нажми \"Сохранить\"", lx() + 150f, 366f, argb(0.4f, 0xFFFFFF));
        for (int i = 0; i < n; i++) {
            float[] r = preset(i);
            boolean hov = inside(mx, my, r[0], r[1], r[2], r[3]);
            box(ctx, RR, r[0], r[1], r[2], r[3], 12, argb(hov ? 0.20f : 0.10f, 0xFFFFFF));
            textC(ctx, textRenderer, Fnt.SMALL, CustomCrosshair.presetName(i), r[0] + r[2] / 2f, r[1] + r[3] / 2f, argb(0.9f, 0xFFFFFF));
        }

        // status line
        long age = now - statusAt;
        if (!status.isEmpty() && age < 3000L) {
            float a = age < 2200L ? 1f : 1f - (age - 2200L) / 800f;
            textC(ctx, textRenderer, Fnt.SMALL, status, rx() + 169f, 404f, argb(a, 0xFFFFFF));
        }
        ctx.getMatrices().popMatrix();
    }

    /** The crosshair at 3x size, centered on a virtual point, so details are visible. */
    private void drawPreview(DrawContext ctx, float cx, float cy, Look l, float cd, boolean aimed, float spread) {
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(cx, cy);
        ctx.getMatrices().scale(3f / k, 3f / k);
        CustomCrosshair.draw(ctx, 0, 0, l, cd, aimed, spread);
        ctx.getMatrices().popMatrix();
    }

    private void button(DrawContext ctx, float[] r, String label, boolean primary, float mx, float my) {
        boolean hov = inside(mx, my, r[0], r[1], r[2], r[3]);
        box(ctx, RR, r[0], r[1], r[2], r[3], 18, argb(primary ? (hov ? 1f : 0.92f) : (hov ? 0.22f : 0.12f), primary ? ACCENT : 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI_B, label, r[0] + r[2] / 2f, r[1] + r[3] / 2f, argb(1f, 0xFFFFFF));
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x() / k, my = click.y() / k;
        int b = click.button();
        int n = CustomCrosshair.presetCount();

        if (b == 1) {                                        // right click: delete a preset
            for (int i = 0; i < n; i++) {
                float[] r = preset(i);
                if (inside(mx, my, r[0], r[1], r[2], r[3])) { CustomCrosshair.removePreset(i); say("Пресет удалён"); return true; }
            }
            return super.mouseClicked(click, doubled);
        }
        if (b != 0) return super.mouseClicked(click, doubled);

        float[] d = done();
        if (inside(mx, my, d[0], d[1], d[2], d[3])) { close(); return true; }

        for (int i = 0; i < CustomCrosshair.STYLES.length; i++) {
            float[] r = tile(i);
            if (inside(mx, my, r[0], r[1], r[2], r[3])) { ShrineCfg.setInt(CustomCrosshair.K_STYLE, i); ShrineCfg.save(); return true; }
        }
        for (int i = 0; i < ShrineGui.PALETTE.length; i++) {
            float[] c = swatch(i);
            if (Math.hypot(mx - c[0], my - c[1]) <= 14.0) { ShrineCfg.setInt(CustomCrosshair.K_COLOR, i); ShrineCfg.save(); return true; }
        }
        for (int i = 0; i < BTN.length; i++) {
            float[] r = btn(i);
            if (inside(mx, my, r[0], r[1], r[2], r[3])) { runButton(i); return true; }
        }
        for (int i = 0; i < n; i++) {
            float[] r = preset(i);
            if (inside(mx, my, r[0], r[1], r[2], r[3])) {
                Look l = CustomCrosshair.presetLook(i);
                if (l == null) say("Пресет повреждён"); else { CustomCrosshair.apply(l); say("Пресет загружен"); }
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    private void runButton(int i) {
        if (client == null) return;
        switch (i) {
            case 0 -> say(CustomCrosshair.addPreset(CustomCrosshair.current()) ? "Сохранено в \"Мои пресеты\"" : "Список пресетов заполнен");
            case 1 -> { client.keyboard.setClipboard(CustomCrosshair.encode(CustomCrosshair.current())); say("Код скопирован в буфер"); }
            case 2 -> {
                Look l = CustomCrosshair.decode(client.keyboard.getClipboard());
                if (l == null) say("Код не распознан");
                else { CustomCrosshair.apply(l); say("Прицел импортирован"); }
            }
            default -> { CustomCrosshair.apply(CustomCrosshair.defaults()); say("Настройки прицела сброшены"); }
        }
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        ShrineCfg.save();
        if (client != null) client.setScreen(parent);
    }
}
