package com.shrine;

import com.shrine.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

import static com.shrine.Gfx.*;

/**
 * Account > Multi Account menu (opened with the Multi Account key): a nick field on top (Enter = add the account), the list
 * of accounts with their state, and "Play as" / "Удалить" for the selected one.
 */
final class MultiAccountScreen extends Screen {
    private static final float PW = 440f, PH = 470f, ROW_H = 58f;
    private static final int ROWS = 4;

    private final List<Accounts.Acc> accs = new ArrayList<>();
    private TextFieldWidget field;
    private int sel, first;
    private boolean confirmDel;
    private String status = "";
    private float k = 1f, vw = 960f;
    private final long openedAt = Util.getMeasuringTimeMs();
    private final float[] rField = new float[4], rPlay = new float[4], rDel = new float[4], rClose = new float[4], rRows = new float[ROWS * 4];

    MultiAccountScreen() { super(Text.literal("shrine")); }

    @Override
    protected void init() {
        Accounts.init();
        k = height / Scene.REF_H;
        vw = width / k;
        String keep = field == null ? "" : field.getText();
        field = new TextFieldWidget(textRenderer, 0, 0, 200, 20, Text.empty());
        field.setMaxLength(16);
        field.setTextPredicate(s -> s.matches("[A-Za-z0-9_]*"));
        field.setText(keep);
        clearChildren();
        addDrawableChild(field);
        field.setFocused(false);
        reload();
        for (int i = 0; i < accs.size(); i++) if (accs.get(i).id.equals(Accounts.current)) sel = i;
        fit();
    }

    private void reload() {
        accs.clear();
        accs.addAll(Accounts.LIST);
        sel = Math.max(0, Math.min(sel, accs.size() - 1));
        confirmDel = false;
    }

    private void fit() {
        if (sel < first) first = sel;
        if (sel >= first + ROWS) first = sel - ROWS + 1;
        first = Math.max(0, Math.min(first, Math.max(0, accs.size() - ROWS)));
    }

    private Accounts.Acc selected() { return sel >= 0 && sel < accs.size() ? accs.get(sel) : null; }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        long now = Util.getMeasuringTimeMs();
        float t = Math.min(1f, (now - openedAt) / 220f), a = 1f - (1f - t) * (1f - t), time = (now - openedAt) / 1000f;
        ctx.fill(0, 0, width, height, argb(0.55f * a, 0x000000));
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        float mx = mxReal / k, my = myReal / k;
        float x = vw / 2f - PW / 2f, y = Scene.REF_H / 2f - PH / 2f + (1f - a) * 14f;

        box(ctx, RR, x - 1, y - 1, PW + 2, PH + 2, 25f, argb(0.14f * a, 0xFFFFFF));
        box(ctx, RR, x, y, PW, PH, 24f, argb(0.97f * a, 0x16171B));

        // header
        box(ctx, RR, x + 22, y + 22, 44, 44, 14f, argb(0.12f * a, 0xFFFFFF));
        centered(ctx, DISC, x + 44, y + 38, 9f, 9f, argb(0.9f * a, 0xFFFFFF));
        centered(ctx, RING, x + 44, y + 52, 22f, 14f, argb(0.9f * a, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.UI_B, "Multi Account", x + 80, y + 36, argb(a, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.SMALL, "Misc · несколько аккаунтов", x + 80, y + 56, argb(0.5f * a, 0xFFFFFF));
        set(rClose, x + PW - 54, y + 24, 32, 32);
        boolean hc = inside(mx, my, rClose[0], rClose[1], rClose[2], rClose[3]);
        box(ctx, RR, rClose[0], rClose[1], 32, 32, 16f, argb((hc ? 0.22f : 0.10f) * a, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI, "×", rClose[0] + 16, rClose[1] + 15, argb(a, 0xFFFFFF));

        // nick field
        set(rField, x + 20, y + 84, PW - 40, 42);
        drawField(ctx, time, a);

        // accounts
        float ly = y + 142;
        for (int i = 0; i < ROWS * 4; i++) rRows[i] = 0;
        if (accs.isEmpty()) {
            textC(ctx, textRenderer, Fnt.LABEL, "Пока нет аккаунтов", x + PW / 2f, ly + 80, argb(0.55f * a, 0xFFFFFF));
            textC(ctx, textRenderer, Fnt.SMALL, "Впиши ник выше и нажми Enter", x + PW / 2f, ly + 104, argb(0.35f * a, 0xFFFFFF));
        }
        for (int r = 0; r < ROWS; r++) {
            int idx = first + r;
            if (idx >= accs.size()) break;
            Accounts.Acc acc = accs.get(idx);
            float ry = ly + r * ROW_H, rx = x + 20, rw = PW - 40;
            set(rRows, r, rx, ry, rw, 52f);
            boolean hv = inside(mx, my, rx, ry, rw, 52f), on = acc.id.equals(Accounts.current);
            if (idx == sel) {
                box(ctx, RR, rx, ry, rw, 52f, 16f, argb(0.13f * a, 0xFFFFFF));
                box(ctx, RR_RING, rx, ry, rw, 52f, 16f, argb(0.55f * a, 0xFFFFFF));
            } else if (hv) {
                box(ctx, RR, rx, ry, rw, 52f, 16f, argb(0.06f * a, 0xFFFFFF));
            }
            AccountsScreen.avatar(ctx, rx + 30, ry + 26, 38f, AccountsScreen.TINTS[Math.abs(acc.id.hashCode()) % AccountsScreen.TINTS.length], a);
            text(ctx, textRenderer, Fnt.UI_B, acc.name, rx + 62, ry + 19, argb(a, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, acc.label(), rx + 62, ry + 38, argb(0.45f * a, 0xFFFFFF));
            String pill = on ? "Online" : "Не в игре";
            float pw = width(textRenderer, Fnt.SMALL, pill) + 22f, px = rx + rw - pw - 12, py = ry + 15;
            box(ctx, RR, px, py, pw, 22f, 11f, argb((on ? 0.22f : 0.10f) * a, on ? 0x3DDC84 : 0xFFFFFF));
            textC(ctx, textRenderer, Fnt.SMALL, pill, px + pw / 2f, py + 10, argb((on ? 1f : 0.55f) * a, on ? 0x7BF0B0 : 0xFFFFFF));
        }
        if (accs.size() > ROWS) {
            textC(ctx, textRenderer, Fnt.SMALL, (first + 1) + "–" + Math.min(accs.size(), first + ROWS) + " из " + accs.size() + "   ▲ ▼",
                    x + PW / 2f, ly + ROWS * ROW_H + 4, argb(0.35f * a, 0xFFFFFF));
        }

        // buttons
        Accounts.Acc s = selected();
        boolean canPlay = s != null && !s.id.equals(Accounts.current);
        float by = y + PH - 74, bw = (PW - 40 - 12) / 2f;
        set(rPlay, x + 20, by, bw, 46);
        set(rDel, x + 20 + bw + 12, by, bw, 46);
        boolean hp = canPlay && inside(mx, my, rPlay[0], rPlay[1], rPlay[2], rPlay[3]);
        box(ctx, RR, rPlay[0], rPlay[1], bw, 46, 23f, argb((canPlay ? (hp ? 1f : 0.93f) : 0.10f) * a, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI_B, "Play as", rPlay[0] + bw / 2f, rPlay[1] + 22, argb((canPlay ? 1f : 0.35f) * a, canPlay ? 0x14101A : 0xFFFFFF));
        boolean hd = s != null && inside(mx, my, rDel[0], rDel[1], rDel[2], rDel[3]);
        box(ctx, RR, rDel[0], rDel[1], bw, 46, 23f, argb(((hd ? 0.28f : 0.12f)) * a, confirmDel ? 0xFF6A5A : 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI, confirmDel ? "Точно удалить?" : "Удалить", rDel[0] + bw / 2f, rDel[1] + 22, argb((s != null ? 1f : 0.35f) * a, 0xFFFFFF));

        if (!status.isEmpty()) textC(ctx, textRenderer, Fnt.SMALL, status, x + PW / 2f, y + PH - 14, argb(a, 0xFF8A80));
        ctx.getMatrices().popMatrix();
    }

    private static void set(float[] r, float x, float y, float w, float h) { r[0] = x; r[1] = y; r[2] = w; r[3] = h; }
    private static void set(float[] r, int i, float x, float y, float w, float h) { set2(r, i * 4, x, y, w, h); }
    private static void set2(float[] r, int o, float x, float y, float w, float h) { r[o] = x; r[o + 1] = y; r[o + 2] = w; r[o + 3] = h; }

    private void drawField(DrawContext ctx, float time, float a) {
        boolean focused = field.isFocused();
        float[] r = rField;
        box(ctx, RR, r[0], r[1], r[2], r[3], 20f, argb(0.09f * a, 0xFFFFFF));
        box(ctx, RR_RING, r[0], r[1], r[2], r[3], 20f, argb((focused ? 0.70f : 0.18f) * a, 0xFFFFFF));
        String t = field.getText();
        float cy = r[1] + r[3] / 2f, tx = r[0] + 18f;
        boolean caret = focused && ((int) (time * 2.2f)) % 2 == 0;
        if (t.isEmpty()) {
            if (!focused) text(ctx, textRenderer, Fnt.LABEL, "Ник нового аккаунта", tx, cy, argb(0.38f * a, 0xFFFFFF));
            else if (caret) ctx.fill(Math.round(tx), Math.round(cy - 9), Math.round(tx) + 2, Math.round(cy + 9), argb(0.9f * a, 0xFFFFFF));
            return;
        }
        text(ctx, textRenderer, Fnt.LABEL, t, tx, cy, argb(a, 0xFFFFFF));
        if (caret) {
            int cur = Math.max(0, Math.min(t.length(), field.getCursor()));
            float cx = tx + width(textRenderer, Fnt.LABEL, t.substring(0, cur));
            ctx.fill(Math.round(cx), Math.round(cy - 9), Math.round(cx) + 2, Math.round(cy + 9), argb(0.95f * a, 0xFFFFFF));
        }
    }

    // ---------- actions ----------
    private void addNick() {
        String nick = field.getText();
        if (!Accounts.validNick(nick)) { status = "Ник: 3–16 символов, латиница, цифры и _"; return; }
        Accounts.Acc acc = Accounts.addPirate(nick);
        field.setText("");
        status = "";
        reload();
        for (int i = 0; i < accs.size(); i++) if (accs.get(i).id.equals(acc.id)) sel = i;
        fit();
    }

    private void playAs() {
        Accounts.Acc s = selected();
        if (s == null) return;
        if (s.id.equals(Accounts.current)) { status = "Ты уже играешь за " + s.name; return; }
        client.setScreen(null);
        MultiAccount.switchTo(client, s);
    }

    private void delete() {
        Accounts.Acc s = selected();
        if (s == null) return;
        if (!confirmDel) { confirmDel = true; return; }
        Accounts.remove(s);
        reload();
        fit();
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return true;
        double mx = click.x() / k, my = click.y() / k;
        status = "";
        if (inside(mx, my, rClose[0], rClose[1], rClose[2], rClose[3])) { client.setScreen(null); return true; }
        if (inside(mx, my, rField[0], rField[1], rField[2], rField[3])) { field.setFocused(true); setFocused(field); return true; }
        field.setFocused(false);
        if (inside(mx, my, rPlay[0], rPlay[1], rPlay[2], rPlay[3])) { playAs(); return true; }
        if (inside(mx, my, rDel[0], rDel[1], rDel[2], rDel[3])) { delete(); return true; }
        confirmDel = false;
        for (int r = 0; r < ROWS; r++) {
            int o = r * 4;
            if (rRows[o + 2] > 0 && inside(mx, my, rRows[o], rRows[o + 1], rRows[o + 2], rRows[o + 3]) && first + r < accs.size()) {
                sel = first + r;
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (key == GLFW.GLFW_KEY_ESCAPE) { client.setScreen(null); return true; }
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER)) {
            if (field.isFocused()) addNick(); else playAs();
            return true;
        }
        if (!field.isFocused()) {
            if (key == GLFW.GLFW_KEY_UP) { sel = Math.max(0, sel - 1); confirmDel = false; fit(); return true; }
            if (key == GLFW.GLFW_KEY_DOWN) { sel = Math.min(accs.size() - 1, sel + 1); confirmDel = false; fit(); return true; }
        }
        return super.keyPressed(input);
    }

    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean shouldPause() { return false; }
}
