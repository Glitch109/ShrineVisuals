package com.shrine;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

/**
 * Account > "Multi Account": the key opens {@link MultiAccountScreen}; "Play as" swaps the session ({@link Accounts#activate})
 * and rejoins the SAME server. Also: auto respawn. The previous account leaves the server (one window = one connection).
 */
final class MultiAccount {
    private MultiAccount() {}

    static final String KEY = "multi.on", K_SWITCH = "multi.switch", K_RESPAWN = "multi.respawn";
    static final int DEF_SWITCH = GLFW.GLFW_KEY_F8;

    private static boolean down, busy;
    private static ServerInfo pending;          // server to rejoin after the disconnect
    private static long pendingAt;
    private static String joinedAs = "";

    static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(MultiAccount::tick);
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            if (!joinedAs.isEmpty()) {
                String n = joinedAs;
                joinedAs = "";
                client.execute(() -> { if (client.player != null) client.player.sendMessage(Text.literal("Multi Account: играешь за " + n), true); });
            }
        });
    }

    private static boolean held() {
        int key = ShrineCfg.integer(K_SWITCH, DEF_SWITCH);
        if (key < 0) return false;
        long w = GLFW.glfwGetCurrentContext();
        if (w == 0L) return false;
        if (key >= 1000) return GLFW.glfwGetMouseButton(w, key - 1000) == GLFW.GLFW_PRESS;
        return GLFW.glfwGetKey(w, key) == GLFW.GLFW_PRESS;
    }

    private static void say(MinecraftClient mc, String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("Multi Account: " + s), true);
    }

    static void tick(MinecraftClient mc) {
        boolean now = held();
        boolean edge = now && !down;
        down = now;

        // finishing a switch: once the old connection is gone, join the same server with the new session
        if (pending != null) {
            if (Util.getMeasuringTimeMs() - pendingAt > 15000L) { pending = null; busy = false; return; }
            if (mc.world == null && mc.getNetworkHandler() == null && mc.currentScreen != null
                    && !(mc.currentScreen instanceof ConnectScreen) && Util.getMeasuringTimeMs() - pendingAt > 400L) {
                ServerInfo si = pending;
                pending = null;
                busy = false;
                ConnectScreen.connect(mc.currentScreen, mc, ServerAddress.parse(si.address), si, false, null);
            }
            return;
        }

        if (!ShrineCfg.bool(KEY, false)) return;
        if (mc.player != null && ShrineCfg.bool(K_RESPAWN, true) && mc.player.isDead()) mc.player.requestRespawn();
        if (!edge || busy || mc.player == null || mc.world == null || mc.currentScreen != null) return;
        mc.setScreen(new MultiAccountScreen());
    }

    /** "Play as": makes {@code next} the active account, leaves the server and joins the same one with it. */
    static void switchTo(MinecraftClient mc, Accounts.Acc next) {
        if (busy) return;
        ServerInfo si = mc.getCurrentServerEntry();
        if (si == null) { say(mc, "работает только на сервере"); return; }
        busy = true;
        say(mc, "перехожу на " + next.name + "…");
        Thread t = new Thread(() -> {
            String err = Accounts.activate(next);           // may talk to Microsoft: off the game thread
            mc.execute(() -> {
                if (err != null) { busy = false; say(mc, err); return; }
                joinedAs = next.name;
                pending = si;
                pendingAt = Util.getMeasuringTimeMs();
                if (mc.getNetworkHandler() != null) mc.getNetworkHandler().getConnection().disconnect(Text.literal("Смена аккаунта"));
            });
        }, "shrine-multi-account");
        t.setDaemon(true);
        t.start();
    }
}
