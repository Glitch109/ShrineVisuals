package com.shrine;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.MessageScreen;
import net.minecraft.client.gui.screen.ProgressScreen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.CreateWorldScreen;

public class ShrineClient implements ClientModInitializer {
    private static boolean introDone; // splash + warning play once per launch
    @Override
    public void onInitializeClient() {
        TargetHud.register();     // health indicator of the entity you look at
        InventoryHud.register();  // Hud > Inventory: the whole inventory as a mini grid
        BossBarHud.register();    // Hud > Boss Bar: movable vanilla boss bar
        ScoreboardHud.register(); // Hud > Scoreboard: movable vanilla sidebar scoreboard
        HudEditor.register();     // open chat: frames of all widgets, drag to move
        ShulkerPreview.register(); // Hud > Shulker Preview: contents of a shulker box under the mouse
        NearHud.register();       // Hud > Players Near: list of players around with distance and direction
        Predictions.register();   // Visual > Предсказания: flight line, landing mark, time to land
        WorldParticles.register();   // Visual > Частицы мира
        JumpCircles.register();      // Player > Круги прыжка
        // Right Shift (changeable in Controls) opens the settings window while playing.
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("shrine", "main"));
        KeyBinding openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.shrine.gui", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            TargetBridge.tick(client);
            AutoSwap.tick(client);    // Auto > АвтоСвап
            while (openGui.wasPressed()) if (client.currentScreen == null && client.world != null) client.setScreen(new ShrineGui());
        });
        // The last game frame is still in the framebuffer when the connection closes: grab it for the exit animation.
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            WorldCreateFx.active = false;
            FriendsHost.worldClosed();
            ExitFx.capture(client);
        });
        net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents.GAME.register((msg, overlay) -> FriendsHost.onMessage(msg.getString()));
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> WorldCreateFx.active = false);

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            // Settings: vanilla buttons become a PS5-style vertical list.
            if (screen instanceof OptionsScreen) WorldCreateFx.layoutSettings(screen);
            // Pause menu: vanilla buttons become PS5 control-center cards.
            if (screen instanceof GameMenuScreen) FriendsScreen.addPauseButton(screen);
            if (screen instanceof GameMenuScreen) WorldCreateFx.initPause(screen);
            // "Сохранение мира" and other message screens: the vanilla text widget is replaced by our spinner + title.
            if (screen instanceof MessageScreen) {
                for (Element e : screen.children()) if (e instanceof ClickableWidget cw) cw.visible = false;
            }
            // Leaving a world: instead of "Сохранение мира" / a progress screen, the game shrinks into a window.
            if (screen instanceof MessageScreen || screen instanceof ProgressScreen) {
                ScreenEvents.afterRender(screen).register((scr, ctx, mx, my, delta) -> {
                    if (ExitFx.holding()) ExitFx.overlay(ctx, client, scr.width, scr.height);
                });
            }
            // World creation flow gets the PS5 skin; any Shrine / title screen switches it off again.
            if (screen instanceof CreateWorldScreen) WorldCreateFx.active = true;
            else if (screen instanceof TitleScreen || screen instanceof PsSingleplayerScreen
                    || screen instanceof PsMultiplayerScreen || screen instanceof AccountsScreen) WorldCreateFx.active = false;

            // Every time the vanilla title screen opens, swap it for ours.
            // Leaving a SINGLEPLAYER world lands here: open our "Одиночная игра" with that world selected.
            if (screen instanceof TitleScreen title) {
                client.execute(() -> {
                    if (client.currentScreen == title) {
                        String world = ExitFx.take("world");
                        if (world != null) {
                            introDone = true;
                            client.setScreen(new PsSingleplayerScreen(title, world));
                            return;
                        }
                        // First start of the game: logo animation -> the home screen ("Кто играет?" + the three actions).
                        // Later returns from a world / server land straight on the home screen.
                        Screen home = new AccountsScreen();
                        client.setScreen(introDone ? home : new IntroScreen(home));
                        introDone = true;
                    }
                });
            }
            // Leaving a SERVER makes vanilla open ITS OWN server list. Swap it for our "Сетевая игра"
            // with the server we just left selected.
            else if (screen.getClass() == MultiplayerScreen.class) {
                client.execute(() -> {
                    if (client.currentScreen == screen) {
                        introDone = true;
                        client.setScreen(new PsMultiplayerScreen(new TitleScreen(), ExitFx.take("server")));
                    }
                });
            }
        });
    }
}
