package com.shrine;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static com.shrine.Gfx.argb;

/**
 * Player > "Круги прыжка": an effect on the ground where you left it. Works in first AND third person
 * (the view comes from {@link Predictions#setupView}, which follows the game camera).
 * <p>
 * Looks: textured decals lying flat on the ground (ring, burst, wheel, whirlpool, storm), or "Блоки": the blocks around
 * the jump light up in a circle that spreads outward. A decal is a normal texture, mapped onto the ground plane
 * with an affine matrix built from three projected world points.
 */
final class JumpCircles {
    private JumpCircles() {}

    static final String KEY = "jc.on", K_TYPE = "jc.type", K_SIZE = "jc.size", K_TIME = "jc.time", K_COLOR = "jc.color",
            K_GLOW = "jc.glow";
    static final String[] TYPES = {"Кольцо", "Взрыв", "Колесо", "Омут", "Шторм", "Блоки"};
    private static final int BLOCKS = 5;               // index of the "Блоки" look

    private static Identifier t(String n) { return Identifier.of("shrine", "textures/jump/" + n + ".png"); }
    private static final Identifier RING = t("ring"), GLOW = t("glow"), BOOM1 = t("boom1"), BOOM2 = t("boom2"),
            COLSO1 = t("colso1"), COLSO3 = t("colso3"), OMUT2 = t("omut2"), OMUT3 = t("omut3"),
            SHTORM1 = t("shtorm1"), SHTORM2 = t("shtorm2");

    private static final int MAX_ALIVE = 16;           // hard cap so bunny-hopping cannot flood the screen
    private static final float EDGE = 0.9f;            // how wide (blocks) the lit band of the block wave is

    /** One effect: where it started, when, and (for the block look) the surface blocks around it: {x, topY, z, distance}. */
    private record Fx(double x, double y, double z, long born, List<double[]> blocks) {}

    private static final List<Fx> LIST = new ArrayList<>();
    private static boolean wasOnGround = true;

    static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(JumpCircles::tick);
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "jump_circles"),
                (ctx, tick) -> render(ctx, tick));
    }

    // ---------- spawning: the tick where the feet leave the ground while moving up ----------
    private static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) { LIST.clear(); wasOnGround = true; return; }
        boolean ground = mc.player.isOnGround();
        if (ShrineCfg.bool(KEY, true) && wasOnGround && !ground && mc.player.getVelocity().y > 0.05
                && !mc.player.isTouchingWater() && !mc.player.isClimbing() && !mc.player.hasVehicle()) {
            if (LIST.size() >= MAX_ALIVE) LIST.remove(0);
            double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
            int type = Math.max(0, Math.min(TYPES.length - 1, ShrineCfg.integer(K_TYPE, 0)));
            float radius = Math.max(0.5f, Math.min(4f, ShrineCfg.num(K_SIZE, 1.6f)));
            LIST.add(new Fx(x, y + 0.03, z, Util.getMeasuringTimeMs(), type == BLOCKS ? scan(mc, x, y, z, radius) : null));
        }
        wasOnGround = ground;
    }

    /** Collects the top face of every walkable block within {@code maxR} of the jump point. */
    private static List<double[]> scan(MinecraftClient mc, double cx, double cy, double cz, float maxR) {
        List<double[]> out = new ArrayList<>();
        int r = (int) Math.ceil(maxR) + 1, fx = (int) Math.floor(cx), fy = (int) Math.floor(cy + 0.1), fz = (int) Math.floor(cz);
        BlockPos.Mutable p = new BlockPos.Mutable();
        for (int bx = fx - r; bx <= fx + r; bx++) {
            for (int bz = fz - r; bz <= fz + r; bz++) {
                double d = Math.hypot(bx + 0.5 - cx, bz + 0.5 - cz);
                if (d > maxR + 0.8) continue;
                for (int by = fy; by >= fy - 3; by--) {
                    var st = mc.world.getBlockState(p.set(bx, by, bz));
                    if (!st.isSideSolidFullSquare(mc.world, p, Direction.UP)) continue;
                    if (mc.world.getBlockState(p.set(bx, by + 1, bz)).isAir()) out.add(new double[]{bx, by + 1.012, bz, d});
                    break;
                }
            }
        }
        return out;
    }

    // ---------- drawing ----------
    private static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (LIST.isEmpty() || mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, true)) return;
        Predictions.setupView(mc, tick.getTickProgress(true));

        float radius = Math.max(0.5f, Math.min(4f, ShrineCfg.num(K_SIZE, 1.6f)));
        float life = Math.max(0.3f, Math.min(3f, ShrineCfg.num(K_TIME, 1.1f))) * 1000f;
        int rgb = ShrineGui.PALETTE[Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 1)))];
        boolean glow = ShrineCfg.bool(K_GLOW, true);
        long now = Util.getMeasuringTimeMs();

        for (Iterator<Fx> it = LIST.iterator(); it.hasNext(); ) {
            Fx f = it.next();
            float age = (now - f.born()) / life;
            if (age >= 1f) { it.remove(); continue; }
            float grow = ease(age), fade = (1f - age) * (1f - age);
            float spin = (now - f.born()) / 1000f;
            if (f.blocks() != null) { blocks(ctx, f, radius * grow, fade, rgb); continue; }

            int type = Math.max(0, Math.min(TYPES.length - 1, ShrineCfg.integer(K_TYPE, 0)));
            if (glow) decal(ctx, f, GLOW, radius * grow * 1.25f, 0f, rgb, 0.45f * fade);
            switch (type) {
                case 0 -> decal(ctx, f, RING, radius * grow, 0f, rgb, fade);
                case 1 -> {                                                         // burst: the radial ring flies out, a crescent follows
                    decal(ctx, f, BOOM1, radius * grow, spin * 0.6f, rgb, fade);
                    decal(ctx, f, BOOM2, radius * grow * 0.85f, -spin * 2.2f, rgb, 0.9f * fade);
                }
                case 2 -> {                                                         // wheel: a fine ring and a crescent turning opposite ways
                    decal(ctx, f, COLSO1, radius * grow, 0f, rgb, fade);
                    decal(ctx, f, COLSO3, radius * grow * 0.92f, spin * 2.6f, rgb, fade);
                }
                case 3 -> {                                                         // whirlpool: two smoky layers turning against each other
                    decal(ctx, f, OMUT3, radius * grow, spin * 1.2f, rgb, fade);
                    decal(ctx, f, OMUT2, radius * grow * 0.8f, -spin * 1.8f, rgb, 0.9f * fade);
                }
                default -> {                                                        // storm: fast sweeping arcs
                    decal(ctx, f, SHTORM2, radius * grow, spin * 3.2f, rgb, fade);
                    decal(ctx, f, SHTORM1, radius * grow * 1.1f, -spin * 2.0f, rgb, 0.85f * fade);
                }
            }
        }
    }

    /** Fast at the start, settling at the end. */
    private static float ease(float t) { float u = 1f - t; return 1f - u * u * u; }

    /**
     * A texture lying flat on the ground around the jump point. {@code rad}: radius in blocks (the texture spans
     * 2 x rad), {@code spin}: turn in radians. The square is mapped to the ground with the screen positions of the
     * center and of the points one radius away along the world X and Z axes.
     */
    private static void decal(DrawContext ctx, Fx f, Identifier tex, float rad, float spin, int rgb, float alpha) {
        if (rad < 0.03f || alpha < 0.02f) return;
        float[] c = Predictions.project(new Vec3d(f.x(), f.y(), f.z()));
        float[] ex = Predictions.project(new Vec3d(f.x() + rad, f.y(), f.z()));
        float[] ez = Predictions.project(new Vec3d(f.x(), f.y(), f.z() + rad));
        if (c == null || ex == null || ez == null) return;
        final float half = 32f;                                  // the texture is drawn as a 64 x 64 square around (0, 0)
        float axx = (ex[0] - c[0]) / half, axy = (ex[1] - c[1]) / half, azx = (ez[0] - c[0]) / half, azy = (ez[1] - c[1]) / half;
        if (Math.abs(axx) > 90f || Math.abs(axy) > 90f || Math.abs(azx) > 90f || Math.abs(azy) > 90f) return;   // absurdly close to the camera
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(c[0], c[1]);
        m.mul(new Matrix3x2f(axx, axy, azx, azy, 0f, 0f));       // ground plane
        m.rotate(spin);                                          // turn inside the plane
        Gfx.blit(ctx, tex, -(int) half, -(int) half, (int) half * 2, (int) half * 2, argb(alpha, rgb));
        m.popMatrix();
    }

    /** The "Блоки" look: a ring-shaped wave of light that runs over the top faces of the blocks around the jump. */
    private static void blocks(DrawContext ctx, Fx f, float wave, float fade, int rgb) {
        for (double[] b : f.blocks()) {
            double d = b[3];
            double band = Math.exp(-Math.pow((d - wave) / EDGE, 2.0));          // lit band at the wave front
            double tail = d < wave ? 0.22 * Math.min(1.0, (wave - d) / 1.2) : 0.0;   // a faint glow stays behind it
            float k = (float) Math.min(1.0, Math.max(band, tail)) * fade;
            if (k < 0.03f) continue;
            Vec3d p0 = new Vec3d(b[0], b[1], b[2]);
            float[] s0 = Predictions.project(p0), s1 = Predictions.project(p0.add(1, 0, 0)), s2 = Predictions.project(p0.add(0, 0, 1));
            if (s0 == null || s1 == null || s2 == null) continue;
            var m = ctx.getMatrices();
            m.pushMatrix();
            m.translate(s0[0], s0[1]);
            m.mul(new Matrix3x2f(s1[0] - s0[0], s1[1] - s0[1], s2[0] - s0[0], s2[1] - s0[1], 0f, 0f));
            ctx.fill(0, 0, 1, 1, argb(0.42f * k, rgb));                           // the face (a unit square in block space)
            m.popMatrix();
            if (k > 0.2f) {                                                      // a thin outline on the brightest ones
                Vec3d p1 = p0.add(1, 0, 0), p2 = p0.add(0, 0, 1), p3 = p0.add(1, 0, 1);
                Predictions.seg(ctx, p0, p1, 0.5f, rgb, 0.8f * k);
                Predictions.seg(ctx, p1, p3, 0.5f, rgb, 0.8f * k);
                Predictions.seg(ctx, p3, p2, 0.5f, rgb, 0.8f * k);
                Predictions.seg(ctx, p2, p0, 0.5f, rgb, 0.8f * k);
            }
        }
    }
}
