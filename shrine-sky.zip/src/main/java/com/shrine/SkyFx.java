package com.shrine;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import static com.shrine.Gfx.*;

/**
 * Visual > "Небо": effects in the night sky.
 * Six kinds: aurora (northern lights), nebula (a green one is "emerald nebula"), galaxy, end beams, caustics, black hole.
 * They hang at fixed directions of the sky (they do not move when you walk), fade in at dusk, fade out at dawn,
 * and are not drawn in the Nether / End or when you stand under a roof.
 *
 * The effect is a soft overlay on top of the frame (like the other Visual functions), so it is faded out below the horizon
 * and kept faint; hills and trees that stick into the sky get a light tint of it.
 */
final class SkyFx {
    private SkyFx() {}

    static final String KEY = "sky.on", K_TYPE = "sky.type", K_COLOR = "sky.color", K_POWER = "sky.power", K_NIGHT = "sky.night";
    static final String[] TYPES = {"Аврора", "Туманность", "Галактика", "Лучи Края", "Каустика", "Чёрная дыра"};

    private static final double D = 100.0;       // the sky is drawn on a sphere of this radius around the camera
    private static float vis;                     // current fade (0..1), eased so effects never pop in or out
    private static long last;

    static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "sky_fx"),
                (ctx, tick) -> render(ctx, tick));
    }

    // ---------- helpers ----------
    private static float hash(int i) {
        double v = Math.sin(i * 12.9898 + 78.233) * 43758.5453;
        return (float) (v - Math.floor(v));
    }

    private static float smooth(float a, float b, float x) {
        float t = Math.max(0f, Math.min(1f, (x - a) / (b - a)));
        return t * t * (3f - 2f * t);
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** Screen position of the sky direction (azimuth, elevation in radians), or null when it is behind the camera / off screen. */
    private static float[] sk(double az, double el) {
        double ce = Math.cos(el);
        Vec3d p = new Vec3d(Predictions.cx - Math.sin(az) * ce * D, Predictions.cy + Math.sin(el) * D, Predictions.cz + Math.cos(az) * ce * D);
        float[] s = Predictions.project(p);
        if (s == null) return null;
        if (s[0] < -400 || s[0] > Predictions.sw + 400 || s[1] < -400 || s[1] > Predictions.sh + 400) return null;
        return s;
    }

    /** Pixels (GUI units) of an angle in degrees. */
    private static float ang(double deg) {
        return (float) (Math.toRadians(deg) * Predictions.sh / (2.0 * Predictions.tanH));
    }

    /** Nothing below the horizon: 0 at 1.5 degrees, 1 at 10.5 degrees. */
    private static float horizon(double el) {
        return smooth(1.5f, 10.5f, (float) Math.toDegrees(el));
    }

    private static void blob(DrawContext ctx, double az, double el, double wDeg, double hDeg, int rgb, float a) {
        float h = horizon(el);
        if (h <= 0.01f || a <= 0.003f) return;
        float[] s = sk(az, el);
        if (s == null) return;
        centered(ctx, GLOW, s[0], s[1], ang(wDeg), ang(hDeg), argb(Math.min(1f, a * h), rgb));
    }

    private static void star(DrawContext ctx, double az, double el, float px, int rgb, float a) {
        float h = horizon(el);
        if (h <= 0.01f) return;
        float[] s = sk(az, el);
        if (s == null) return;
        centered(ctx, DISC, s[0], s[1], px, px, argb(Math.min(1f, a * h), rgb));
    }

    // ---------- the HUD element ----------
    private static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        long now = Util.getMeasuringTimeMs();
        float dt = last == 0L ? 0.016f : Math.min(0.1f, (now - last) / 1000f);
        last = now;

        // should the sky show right now?
        boolean want = ShrineCfg.bool(KEY, true) && mc.options.getPerspective().isFirstPerson()
                && mc.world.getRegistryKey() == World.OVERWORLD && mc.world.isSkyVisible(mc.player.getBlockPos());
        float night = 1f;
        if (want && ShrineCfg.bool(K_NIGHT, true)) {
            float tod = (float) (mc.world.getTimeOfDay() % 24000L);
            night = smooth(12000f, 13800f, tod) * (1f - smooth(22200f, 23800f, tod));
        }
        float target = want ? night : 0f;
        vis += (target - vis) * Math.min(1f, dt * 1.5f);
        if (vis < 0.01f) return;

        float td = tick.getTickProgress(true);
        Predictions.setupView(mc, td);
        float t = (now % 600000L) / 1000f;
        float k = vis * Math.max(0.1f, Math.min(1f, ShrineCfg.num(K_POWER, 0.7f)));
        int ci = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 6)));
        int rgb = ShrineGui.PALETTE[ci];
        int type = Math.max(0, Math.min(TYPES.length - 1, ShrineCfg.integer(K_TYPE, 0)));

        switch (type) {
            case 0 -> aurora(ctx, t, rgb, k);
            case 1 -> nebula(ctx, t, rgb, k);
            case 2 -> galaxy(ctx, t, rgb, k);
            case 3 -> beams(ctx, t, rgb, k);
            case 4 -> caustics(ctx, t, rgb, k);
            default -> blackHole(ctx, t, rgb, k);
        }
    }

    // ---------- 1. aurora: curtains of vertical rays ----------
    private static void aurora(DrawContext ctx, float t, int rgb, float k) {
        final int RAYS = 56, STEPS = 8;
        double[] centre = {0.5, 3.4};
        for (int b = 0; b < centre.length; b++) {
            for (int i = 0; i < RAYS; i++) {
                float u = i / (RAYS - 1f);
                double az = centre[b] + (u - 0.5) * 2.0 + Math.sin(t * 0.25 + u * 5.0 + b) * 0.035;
                double base = 0.13 + 0.05 * Math.sin(u * 7.0 + t * 0.4 + b * 2.0);
                double height = 0.30 + 0.45 * (0.5 + 0.5 * Math.sin(u * 3.1 + t * 0.2 + b)) * (0.65 + 0.35 * Math.sin(u * 11.0 + t * 0.5));
                float flick = 0.6f + 0.4f * (float) Math.sin(t * 1.1 + i * 0.7 + b * 3.0);
                float edge = (float) Math.sqrt(Math.sin(u * Math.PI));
                float w = ang(1.7);
                for (int s = 0; s < STEPS; s++) {
                    double e0 = base + height * s / STEPS, e1 = base + height * (s + 1) / STEPS;
                    float fall = (float) Math.pow(1.0 - s / (double) STEPS, 1.4);
                    float a = k * 0.20f * flick * edge * fall * horizon((e0 + e1) / 2);
                    if (a < 0.004f) continue;
                    float[] p1 = sk(az, e0), p2 = sk(az, e1);
                    if (p1 == null || p2 == null) continue;
                    int col = mix(rgb, 0xFFFFFF, 0.1f + 0.3f * (s / (float) STEPS));
                    Predictions.line(ctx, p1[0], p1[1], p2[0], p2[1], w, argb(a, col));
                }
            }
        }
    }

    // ---------- 2. nebula: soft glowing clouds ----------
    private static void nebula(DrawContext ctx, float t, int rgb, float k) {
        double[] caz = {0.6, 2.5, 4.4};
        double[] cel = {0.95, 0.65, 1.05};
        for (int c = 0; c < caz.length; c++) {
            for (int i = 0; i < 9; i++) {
                int h = c * 40 + i;
                double az = caz[c] + (hash(h * 3 + 1) - 0.5) * 0.8 + Math.sin(t * 0.05 + h) * 0.02;
                double el = cel[c] + (hash(h * 3 + 2) - 0.5) * 0.45;
                double size = 10 + 16 * hash(h * 3 + 3);
                float pulse = 0.8f + 0.2f * (float) Math.sin(t * 0.3 + h);
                int col = i % 3 == 0 ? mix(rgb, 0xFFFFFF, 0.35f) : rgb;
                blob(ctx, az, el, size * 1.6, size * 1.2, col, 0.20f * k * pulse);
                blob(ctx, az, el, size * 0.7, size * 0.55, mix(col, 0xFFFFFF, 0.2f), 0.22f * k * pulse);
            }
        }
        for (int i = 0; i < 40; i++)                      // a few stars inside the clouds
            star(ctx, caz[i % 3] + (hash(i * 5 + 9) - 0.5) * 1.1, cel[i % 3] + (hash(i * 5 + 11) - 0.5) * 0.6,
                    1.4f, 0xFFFFFF, k * 0.6f * (0.6f + 0.4f * (float) Math.sin(t * 1.5 + i)));
    }

    // ---------- 3. galaxy: a band of stars and a bright core ----------
    private static void galaxy(DrawContext ctx, float t, int rgb, float k) {
        int tint = mix(rgb, 0x5070FF, 0.35f);
        for (int i = 0; i < 14; i++) {                    // soft glow along the band
            double az = i * (Math.PI * 2 / 14);
            double el = 0.75 + 0.45 * Math.sin(az + 0.5);
            blob(ctx, az, el, 16 + 8 * hash(i + 3), 12, tint, 0.10f * k);
        }
        for (int i = 0; i < 320; i++) {                   // stars: most of them along the band
            boolean band = i < 240;
            double az = hash(i * 2 + 1) * Math.PI * 2;
            double el = band ? 0.75 + 0.45 * Math.sin(az + 0.5) + (hash(i * 2 + 2) + hash(i * 7 + 5) - 1.0) * 0.30
                             : 0.15 + hash(i * 2 + 2) * 1.3;
            float tw = 0.55f + 0.45f * (float) Math.sin(t * (0.8 + hash(i + 40) * 1.6) + i);
            star(ctx, az, el, 1f + 1.2f * hash(i + 90), mix(0xFFFFFF, tint, 0.3f * hash(i + 7)), k * (band ? 0.8f : 0.6f) * tw);
        }
        for (int i = 0; i < 6; i++) {                     // the bright core
            double az = 5.3 + (hash(i + 200) - 0.5) * 0.3, el = 0.9 + (hash(i + 210) - 0.5) * 0.25;
            blob(ctx, az, el, 22 - i * 2.5, 17 - i * 2, mix(tint, 0xFFFFFF, i / 8f), 0.20f * k);
        }
    }

    // ---------- 4. end beams: pale columns of light standing on the horizon ----------
    private static void beams(DrawContext ctx, float t, int rgb, float k) {
        final int N = 18, STEPS = 10;
        int col = mix(rgb, 0xFFFFFF, 0.3f);
        for (int i = 0; i < N; i++) {
            double az = i * (Math.PI * 2 / N) + hash(i + 5) * 0.3;
            double top = 1.15 + 0.3 * hash(i + 17);
            float widthDeg = 0.7f + 1.5f * hash(i + 31);
            float pulse = 0.5f + 0.5f * (float) Math.sin(t * 0.5 + i * 1.7);
            for (int s = 0; s < STEPS; s++) {
                double e0 = 0.02 + top * s / STEPS, e1 = 0.02 + top * (s + 1) / STEPS;
                float fall = (float) Math.pow(1.0 - s / (double) STEPS, 0.8);
                float a = k * 0.13f * pulse * fall;
                float[] p1 = sk(az, e0), p2 = sk(az, e1);
                if (p1 == null || p2 == null) continue;
                Predictions.line(ctx, p1[0], p1[1], p2[0], p2[1], ang(widthDeg * 3.0), argb(a * 0.35f, rgb));
                Predictions.line(ctx, p1[0], p1[1], p2[0], p2[1], ang(widthDeg), argb(a, col));
            }
        }
    }

    // ---------- 5. caustics: a web of bright water-light lines on a tinted sky ----------
    private static void caustics(DrawContext ctx, float t, int rgb, float k) {
        for (int i = 0; i < 8; i++)
            blob(ctx, i * 0.8, 0.7 + 0.5 * hash(i + 60), 55, 45, rgb, 0.14f * k);
        int bright = mix(rgb, 0xFFFFFF, 0.55f);
        final int LINES = 30, PTS = 14;
        for (int i = 0; i < LINES; i++) {
            double az = hash(i * 4 + 1) * Math.PI * 2, el = 0.25 + hash(i * 4 + 2) * 1.1;
            double dir = hash(i * 4 + 3) * Math.PI * 2;
            double step = 0.07 + 0.05 * hash(i * 4 + 4);
            float[] prev = null;
            double prevEl = el;
            for (int j = 0; j < PTS; j++) {
                double wob = Math.sin(t * 0.6 + j * 0.9 + i) * 0.25;
                dir += wob * 0.35;
                az += Math.cos(dir) * step;
                el += Math.sin(dir) * step * 0.8;
                float[] s = sk(az, el);
                float a = k * 0.40f * (0.6f + 0.4f * (float) Math.sin(t * 1.2 + i + j * 0.4)) * horizon((el + prevEl) / 2);
                if (prev != null && s != null && a > 0.004f)
                    Predictions.line(ctx, prev[0], prev[1], s[0], s[1], 0.9f, argb(a, bright));
                prev = s;
                prevEl = el;
            }
        }
    }

    // ---------- 6. black hole: a dark sphere inside a bright turning disc ----------
    private static void blackHole(DrawContext ctx, float t, int rgb, float k) {
        double az = 0.5, el = 0.75;
        float[] c = sk(az, el);
        if (c == null) return;
        float a = k * horizon(el);
        if (a < 0.01f) return;
        float r = ang(5.0);                                   // radius of the dark sphere
        centered(ctx, GLOW, c[0], c[1], r * 7f, r * 7f, argb(0.30f * a, rgb));
        final int DOTS = 170;
        for (int pass = 0; pass < 2; pass++) {                // pass 0: far half of the disc, then the hole, pass 1: near half
            if (pass == 1) centered(ctx, DISC, c[0], c[1], r * 2f, r * 2f, argb(Math.min(1f, a * 1.4f), 0x000000));
            for (int j = 0; j < DOTS; j++) {
                float h = hash(j * 3 + 1), h2 = hash(j * 3 + 2);
                double th = (j / (double) DOTS) * Math.PI * 2 + t * (0.5 - 0.3 * h);
                boolean near = Math.sin(th) > 0;
                if (near != (pass == 1)) continue;
                float rad = r * (1.35f + 2.6f * h);
                float x = c[0] + (float) Math.cos(th) * rad, y = c[1] + (float) Math.sin(th) * rad * 0.26f;
                float heat = 1f - (rad / r - 1.35f) / 2.6f;           // hotter near the hole
                int col = mix(rgb, 0xFFFFFF, Math.max(0f, heat));
                float sz = 1.5f + 2.5f * h2;
                centered(ctx, GLOW, x, y, sz * 4f, sz * 4f, argb(0.30f * a, col));
                centered(ctx, DISC, x, y, sz, sz, argb(Math.min(1f, (0.5f + 0.5f * heat) * a), col));
            }
        }
        for (int j = 0; j < 80; j++) {                        // the light bent over the top and under the bottom of the hole
            double th = j * (Math.PI * 2 / 80);
            float x = c[0] + (float) Math.cos(th) * r * 1.18f, y = c[1] + (float) Math.sin(th) * r * 1.18f;
            centered(ctx, DISC, x, y, 2f, 2f, argb(0.85f * a, mix(rgb, 0xFFFFFF, 0.6f)));
        }
    }
}
