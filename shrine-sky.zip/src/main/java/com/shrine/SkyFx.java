package com.shrine;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import static com.shrine.Gfx.*;

/**
 * Visual > "Небо": effects in the night sky, drawn from generated textures (assets/shrine/textures/gui/sky_*.png).
 * Six kinds: aurora (soft curtains), nebula (clouds), galaxy (milky-way band + core), end beams, caustics, black hole.
 * They hang at fixed directions of the sky (they do not move when you walk), fade in at dusk, fade out at dawn,
 * and are not drawn in the Nether / End or when you stand under a roof.
 * Everything is a soft overlay: it fades out towards the horizon so the ground is not painted over.
 */
final class SkyFx {
    private SkyFx() {}

    static final String KEY = "sky.on", K_TYPE = "sky.type", K_COLOR = "sky.color", K_POWER = "sky.power", K_NIGHT = "sky.night";
    static final String[] TYPES = {"Аврора", "Туманность", "Галактика", "Лучи Края", "Каустика", "Чёрная дыра"};

    private static final Identifier T_AURORA = tex("sky_aurora"), T_CLOUD_A = tex("sky_cloud_a"), T_CLOUD_B = tex("sky_cloud_b"),
            T_CLOUD_CORE = tex("sky_cloud_core"), T_GALAXY = tex("sky_galaxy"), T_CAUSTICS = tex("sky_caustics"),
            T_HAZE = tex("sky_haze"), T_BEAM = tex("sky_beam"), T_BH_TINT = tex("sky_bh_tint"), T_BH_HOT = tex("sky_bh_hot"),
            T_BH_HOLE = tex("sky_bh_hole"), T_BH_FRONT = tex("sky_bh_front");

    private static final double D = 100.0;       // the sky is drawn on a sphere of this radius around the camera
    private static float vis;                     // current fade (0..1), eased so effects never pop in or out
    private static long last;

    static void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "sky_fx"),
                (ctx, tick) -> render(ctx, tick));
    }

    // ---------- helpers ----------
    private static float hash(int i) {
        double v = Math.sin(i * 12.9898 + 78.233) * 43758.5453;
        return (float) (v - Math.floor(v));
    }

    private static float smooth(float a, float b, float x) {
        float t = Math.max(0f, Math.min(1f, (x - a) / (b - a)));
        return t * t * (3f - 2f * t);
    }

    private static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static float[] skRaw(double az, double el) {
        double ce = Math.cos(el);
        Vec3d p = new Vec3d(Predictions.cx - Math.sin(az) * ce * D, Predictions.cy + Math.sin(el) * D, Predictions.cz + Math.cos(az) * ce * D);
        return Predictions.project(p);
    }

    /** Screen position of the sky direction (azimuth, elevation in radians), or null when it is behind the camera / far off screen. */
    private static float[] sk(double az, double el) {
        float[] s = skRaw(az, el);
        if (s == null) return null;
        if (s[0] < -400 || s[0] > Predictions.sw + 400 || s[1] < -400 || s[1] > Predictions.sh + 400) return null;
        return s;
    }

    /** Pixels (GUI units) of an angle in degrees. */
    private static float ang(double deg) {
        return (float) (Math.toRadians(deg) * Predictions.sh / (2.0 * Predictions.tanH));
    }

    /** Nothing below the horizon: 0 at 1.5 degrees, 1 at 10.5 degrees. */
    private static float horizon(double el) {
        return smooth(1.5f, 10.5f, (float) Math.toDegrees(el));
    }

    /** Screen y of the horizon line (eye level), straight across the screen. */
    private static float horizonY() {
        double f = Predictions.sh / (2.0 * Predictions.tanH);
        double elev = Math.asin(Math.max(-1.0, Math.min(1.0, Predictions.fy)));
        return (float) (Predictions.sh / 2.0 + Math.tan(elev) * f);
    }

    /** Azimuth the player looks at, in the same convention as sk(). */
    private static double lookAz() {
        return Math.atan2(-Predictions.fx, Predictions.fz);
    }

    /** One texture region as a (rotated) quad centred on (cx, cy): u, v, rw, rh are in texels. */
    private static void quad(DrawContext ctx, Identifier id, float cx, float cy, float w, float h, float rot,
                             float u, float v, float rw, float rh, int tw, int th, int color) {
        if (w < 0.5f || h < 0.5f || ((color >>> 24) & 255) < 2) return;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(cx, cy);
        if (rot != 0f) m.rotate(rot);
        m.scale(w, h);
        m.translate(-0.5f, -0.5f);
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, id, 0, 0, u, v, 1, 1, Math.round(rw), Math.round(rh), tw, th, color);
        m.popMatrix();
    }

    /** A whole texture as a quad centred on a sky direction, wDeg x hDeg degrees large. */
    private static void sprite(DrawContext ctx, Identifier id, double az, double el, double wDeg, double hDeg, float rot,
                               int rgb, float a) {
        float h = horizon(el);
        if (h <= 0.01f || a <= 0.003f) return;
        float[] s = sk(az, el);
        if (s == null) return;
        quad(ctx, id, s[0], s[1], ang(wDeg), ang(hDeg), rot, 0f, 0f, 1f, 1f, 1, 1, argb(Math.min(1f, a * h), rgb));
    }

    private static void star(DrawContext ctx, double az, double el, float px, int rgb, float a) {
        float h = horizon(el);
        if (h <= 0.01f) return;
        float[] s = sk(az, el);
        if (s == null) return;
        centered(ctx, DISC, s[0], s[1], px, px, argb(Math.min(1f, a * h), rgb));
    }

    /** Thin night-sky tint over everything above the horizon (strongest at the top, nothing at the horizon). */
    private static void wash(DrawContext ctx, int rgb, float a) {
        int yh = Math.round(horizonY());
        if (yh <= 2 || a < 0.01f) return;
        int top = Math.max(0, yh - Math.round(ang(80)));
        if (yh - top < 4) return;
        if (top > 0) ctx.fill(0, 0, Predictions.sw, top, argb(a, rgb));
        ctx.fillGradient(0, top, Predictions.sw, yh, argb(a, rgb), argb(0f, rgb));
    }

    /** A faint field of twinkling stars over the whole sky. */
    private static void stars(DrawContext ctx, float t, float k, int count, int tint) {
        for (int i = 0; i < count; i++) {
            double az = hash(i * 3 + 301) * Math.PI * 2, el = 0.10 + hash(i * 3 + 302) * 1.40;
            float tw = 0.55f + 0.45f * (float) Math.sin(t * (0.7 + hash(i + 400) * 1.8) + i);
            star(ctx, az, el, 1f + 1.4f * hash(i + 450), mix(0xFFFFFF, tint, 0.35f * hash(i + 470)), k * 0.75f * tw);
        }
    }

    // ---------- the HUD element ----------
    private static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        long now = Util.getMeasuringTimeMs();
        float dt = last == 0L ? 0.016f : Math.min(0.1f, (now - last) / 1000f);
        last = now;

        // should the sky show right now?
        boolean want = ShrineCfg.bool(KEY, true) && mc.options.getPerspective().isFirstPerson()
                && mc.world.getRegistryKey() == World.OVERWORLD && mc.world.isSkyVisible(mc.player.getBlockPos());
        float night = 1f;
        if (want && ShrineCfg.bool(K_NIGHT, true)) {
            float tod = (float) (mc.world.getTimeOfDay() % 24000L);
            night = smooth(12000f, 13800f, tod) * (1f - smooth(22200f, 23800f, tod));
        }
        float target = want ? night : 0f;
        vis += (target - vis) * Math.min(1f, dt * 1.5f);
        if (vis < 0.01f) return;

        float td = tick.getTickProgress(true);
        Predictions.setupView(mc, td);
        float t = (now % 600000L) / 1000f;
        float k = vis * Math.max(0.1f, Math.min(1f, ShrineCfg.num(K_POWER, 0.7f)));
        int ci = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 6)));
        int rgb = ShrineGui.PALETTE[ci];
        int type = Math.max(0, Math.min(TYPES.length - 1, ShrineCfg.integer(K_TYPE, 0)));

        switch (type) {
            case 0 -> aurora(ctx, t, rgb, k);
            case 1 -> nebula(ctx, t, rgb, k);
            case 2 -> galaxy(ctx, t, rgb, k);
            case 3 -> beams(ctx, t, rgb, k);
            case 4 -> caustics(ctx, t, rgb, k);
            default -> blackHole(ctx, t, rgb, k);
        }
    }

    // ---------- 1. aurora: soft curtains of light with a bright lower edge ----------
    private static void aurora(DrawContext ctx, float t, int rgb, float k) {
        final int STRIPS = 52, BANDS = 4, TW = 1024, TH = 512, RW = 26;
        int topCol = mix(rgb, 0xA77BFF, 0.55f), lowCol = mix(rgb, 0xFFFFFF, 0.30f);
        wash(ctx, mix(rgb, 0x0A1030, 0.75f), 0.10f * k);
        stars(ctx, t, k, 90, rgb);
        double[] centre = {0.5, 3.6};
        double[] span = {2.1, 1.7};
        for (int b = 0; b < centre.length; b++) {
            for (int i = 0; i < STRIPS; i++) {
                float u = i / (STRIPS - 1f);
                double az = centre[b] + (u - 0.5) * span[b] + Math.sin(t * 0.22 + u * 5.0 + b) * 0.04;
                double base = 0.10 + 0.07 * Math.sin(u * 6.5 + t * 0.35 + b * 2.0);
                double height = 0.55 + 0.45 * (0.5 + 0.5 * Math.sin(u * 3.3 + t * 0.18 + b)) * (0.7 + 0.3 * Math.sin(u * 9.0 + t * 0.45));
                float flick = 0.65f + 0.35f * (float) Math.sin(t * 0.9 + i * 0.55 + b * 3.0);
                float edge = (float) Math.sqrt(Math.sin(u * Math.PI));
                float[] p0 = skRaw(az, base), p1 = skRaw(az, base + height);
                if (p0 == null || p1 == null) continue;
                if (p0[0] < -60 || p0[0] > Predictions.sw + 60) continue;
                float wPx = Math.max(3f, ang(Math.toDegrees(span[b]) / STRIPS * 2.0 * Math.cos(base + height / 2)));
                float u0 = (i * (TW - RW) / (STRIPS - 1f)) * 0.8f + 90f * (0.5f + 0.5f * (float) Math.sin(t * 0.12 + b * 2.0 + u * 2.0));
                u0 = Math.max(0f, Math.min(TW - RW, u0));
                for (int j = 0; j < BANDS; j++) {
                    float f0 = j / (float) BANDS, f1 = (j + 1) / (float) BANDS;      // 0 = top of the ray, 1 = its lower edge
                    float y0 = p1[1] + (p0[1] - p1[1]) * f0, y1 = p1[1] + (p0[1] - p1[1]) * f1;
                    if (y1 < -30 || y0 > Predictions.sh + 30) continue;
                    double elMid = base + height * (1.0 - (f0 + f1) / 2);
                    float a = k * 0.42f * flick * edge * horizon(elMid);
                    if (a < 0.004f) continue;
                    int col = mix(topCol, lowCol, (f0 + f1) / 2);
                    quad(ctx, T_AURORA, p0[0], (y0 + y1) / 2, wPx, y1 - y0 + 0.8f, 0f, u0, f0 * TH, RW, TH / (float) BANDS, TW, TH, argb(a, col));
                }
            }
        }
    }

    // ---------- 2. nebula: big soft clouds with bright cores ----------
    private static void nebula(DrawContext ctx, float t, int rgb, float k) {
        int blue = mix(rgb, 0x4A6CFF, 0.5f), pale = mix(rgb, 0xFFFFFF, 0.38f);
        wash(ctx, mix(rgb, 0x10081E, 0.7f), 0.20f * k);
        stars(ctx, t, k, 150, rgb);
        for (int c = 0; c < 16; c++) {
            int h = c * 11;
            double az = hash(h + 1) * Math.PI * 2 + Math.sin(t * 0.03 + c) * 0.02;
            double el = 0.55 + hash(h + 2) * 0.85;
            double size = 38 + 42 * hash(h + 3);
            float rot = hash(h + 4) * 6.28f + t * 0.01f * (c % 2 == 0 ? 1 : -1);
            float pulse = 0.85f + 0.15f * (float) Math.sin(t * 0.25 + c * 1.3);
            int col = c % 3 == 0 ? rgb : (c % 3 == 1 ? blue : mix(rgb, blue, 0.5f));
            sprite(ctx, c % 2 == 0 ? T_CLOUD_A : T_CLOUD_B, az, el, size * 1.5, size * 1.1, rot, col, 0.42f * k * pulse);
            if (c % 3 == 0) {
                sprite(ctx, T_CLOUD_CORE, az + 0.04, el, size * 0.55, size * 0.45, rot * 1.3f, pale, 0.38f * k * pulse);
                sprite(ctx, GLOW, az + 0.04, el, size * 0.8, size * 0.6, 0f, pale, 0.14f * k * pulse);
            }
        }
    }

    // ---------- 3. galaxy: a band of milky light across the sky with a bright core ----------
    private static void galaxy(DrawContext ctx, float t, int rgb, float k) {
        final int N = 80, TW = 1024, TH = 256;
        int tint = mix(rgb, 0x5070FF, 0.40f), warm = mix(tint, 0xFFD2A0, 0.45f);
        wash(ctx, mix(rgb, 0x080C28, 0.8f), 0.14f * k);
        for (int i = 0; i < N; i++) {                      // the band: one slice per step of azimuth, following the band's curve
            double az = i * (Math.PI * 2 / N);
            double el = 0.80 + 0.48 * Math.sin(az + 0.5);
            double el2 = 0.80 + 0.48 * Math.sin(az + 0.5 + 0.05);
            float[] s = sk(az, el);
            if (s == null) continue;
            float hz = horizon(el);
            if (hz < 0.01f) continue;
            float w = Math.max(3f, ang(360.0 / N * 1.7 * Math.cos(el)));
            float slope = (float) Math.atan2(-(Math.sin(el2) - Math.sin(el)) * 100.0, 0.05 * 100.0 * Math.cos(el)) * 0.3f;
            float tw = 0.85f + 0.15f * (float) Math.sin(t * 0.2 + i * 0.4);
            quad(ctx, T_GALAXY, s[0], s[1], w, ang(46), slope, i * (TW / (float) N), 0f, TW / (float) N * 1.2f, TH, TW, TH,
                    argb(Math.min(1f, 0.85f * k * hz * tw), tint));
        }
        double caz = 5.3, cel = 0.80 + 0.48 * Math.sin(caz + 0.5);        // the bright core of the band
        sprite(ctx, T_CLOUD_CORE, caz, cel, 34, 26, t * 0.01f, warm, 0.30f * k);
        sprite(ctx, GLOW, caz, cel, 48, 34, 0f, warm, 0.22f * k);
        sprite(ctx, GLOW, caz, cel, 18, 14, 0f, 0xFFFFFF, 0.20f * k);
        for (int i = 0; i < 300; i++) {                    // stars: most of them along the band
            boolean band = i < 220;
            double az = hash(i * 2 + 1) * Math.PI * 2;
            double el = band ? 0.80 + 0.48 * Math.sin(az + 0.5) + (hash(i * 2 + 2) + hash(i * 7 + 5) - 1.0) * 0.34
                             : 0.15 + hash(i * 2 + 2) * 1.3;
            float tw = 0.55f + 0.45f * (float) Math.sin(t * (0.8 + hash(i + 40) * 1.6) + i);
            star(ctx, az, el, 1f + 1.3f * hash(i + 90), mix(0xFFFFFF, tint, 0.35f * hash(i + 7)), k * (band ? 0.85f : 0.65f) * tw);
        }
    }

    // ---------- 4. end beams: pale columns of light standing on the horizon ----------
    private static void beams(DrawContext ctx, float t, int rgb, float k) {
        final int N = 30;
        int col = mix(rgb, 0xFFFFFF, 0.35f);
        wash(ctx, mix(rgb, 0x120A28, 0.7f), 0.16f * k);
        stars(ctx, t, k, 110, rgb);
        int yh = Math.round(horizonY());                   // a pale haze lying on the horizon
        int hz0 = yh - Math.round(ang(26));
        if (yh > 0 && hz0 < Predictions.sh) ctx.fillGradient(0, hz0, Predictions.sw, yh, argb(0f, rgb), argb(0.16f * k, rgb));
        for (int i = 0; i < N; i++) {
            double az = i * (Math.PI * 2 / N) + hash(i + 5) * 0.18;
            double top = 0.85 + 0.55 * hash(i + 17);
            float widthDeg = 1.2f + 3.4f * hash(i + 31);
            float pulse = 0.55f + 0.45f * (float) Math.sin(t * 0.45 + i * 1.7);
            float[] p0 = skRaw(az, 0.0), p1 = skRaw(az, top);
            if (p0 == null || p1 == null) continue;
            if (p0[0] < -80 || p0[0] > Predictions.sw + 80) continue;
            float a = k * 0.62f * pulse * (0.5f + 0.5f * hash(i + 77));
            quad(ctx, T_BEAM, p0[0], (p0[1] + p1[1]) / 2, ang(widthDeg), p0[1] - p1[1], 0f, 0f, 0f, 1f, 1f, 1, 1, argb(a, col));
        }
    }

    // ---------- 5. caustics: the sky as sunlit water, with moving ribbons of light ----------
    private static void caustics(DrawContext ctx, float t, int rgb, float k) {
        int yh = Math.round(horizonY());
        if (yh <= 4) return;
        int water = mix(rgb, 0x0A7C8C, 0.55f), bright = mix(rgb, 0xFFFFFF, 0.55f);
        float fade = ang(16);                              // the layers melt away over this many pixels above the horizon
        float f = (float) (Predictions.sh / (2.0 * Predictions.tanH));
        float ox = (float) (-lookAz() * f), oy = horizonY();
        wash(ctx, water, 0.38f * k);
        tiled(ctx, T_HAZE, 512, Predictions.sh * 1.25f, ox * 0.6f + t * 6f, oy - t * 3f, yh, fade, water, 0.28f * k);
        tiled(ctx, T_CAUSTICS, 512, Predictions.sh * 0.95f, ox + t * 14f, oy + t * 9f, yh, fade, bright, 0.62f * k);
        tiled(ctx, T_CAUSTICS, 512, Predictions.sh * 0.60f, ox * 1.2f - t * 11f, oy + t * 15f, yh, fade, mix(bright, rgb, 0.4f), 0.42f * k);
    }

    /** Tiles a square texture over the screen above yMax (fading out towards yMax), scrolled by (ox, oy). */
    private static void tiled(DrawContext ctx, Identifier id, int tex, float size, float ox, float oy, int yMax, float fade, int rgb, float a) {
        final int BANDS = 16;
        float bh = size / BANDS;
        float sx = ox - (float) Math.floor(ox / size) * size - size;        // first tile column starting left of the screen
        float sy = oy - (float) Math.floor(oy / size) * size - size * 2;      // first tile row, well above the screen
        for (float tx = sx; tx < Predictions.sw; tx += size) {
            for (float ty = sy; ty < yMax; ty += size) {
                for (int b = 0; b < BANDS; b++) {
                    float y0 = ty + b * bh, y1 = y0 + bh;
                    if (y1 < 0 || y0 > yMax) continue;
                    float al = a * smooth(yMax, yMax - fade, (y0 + y1) / 2f);
                    if (al < 0.004f) continue;
                    quad(ctx, id, tx + size / 2f, (y0 + y1) / 2f, size + 0.8f, bh + 0.8f, 0f, 0f, b * (tex / (float) BANDS), tex, tex / (float) BANDS, tex, tex, argb(al, rgb));
                }
            }
        }
    }

    // ---------- 6. black hole: a dark sphere inside a bright turning disc ----------
    private static void blackHole(DrawContext ctx, float t, int rgb, float k) {
        double az = 0.5, el = 0.75;
        wash(ctx, mix(rgb, 0x020402, 0.85f), 0.16f * k);
        stars(ctx, t, k, 130, rgb);
        float[] c = sk(az, el);
        if (c == null) return;
        float a = k * horizon(el);
        if (a < 0.01f) return;
        float size = ang(46);                              // the textures are 46 degrees wide; the sphere is ~5.5 degrees in radius
        float tilt = 0.10f * (float) Math.sin(t * 0.08);
        float pulse = 0.92f + 0.08f * (float) Math.sin(t * 0.7);
        int hot = mix(rgb, 0xFFFFFF, 0.75f);
        centered(ctx, GLOW, c[0], c[1], size * 1.5f, size * 1.1f, argb(0.30f * a, rgb));
        quad(ctx, T_BH_TINT, c[0], c[1], size, size, tilt, 0f, 0f, 1f, 1f, 1, 1, argb(Math.min(1f, 0.95f * a * pulse), rgb));
        quad(ctx, T_BH_HOT, c[0], c[1], size, size, tilt, 0f, 0f, 1f, 1f, 1, 1, argb(Math.min(1f, 0.85f * a), hot));
        quad(ctx, T_BH_HOLE, c[0], c[1], size, size, tilt, 0f, 0f, 1f, 1f, 1, 1, argb(Math.min(1f, a * 1.4f), 0xFFFFFF));
        quad(ctx, T_BH_FRONT, c[0], c[1], size, size, tilt, 0f, 0f, 1f, 1f, 1, 1, argb(Math.min(1f, 0.95f * a * pulse), rgb));
        quad(ctx, T_BH_HOT, c[0], c[1] + size * 0.012f, size, size, tilt, 0f, 0f, 1f, 1f, 1, 1, argb(0.30f * a, hot));
        final int DOTS = 110;                              // sparks circling in the disc
        float r = size * 0.24f / 2f;
        for (int j = 0; j < DOTS; j++) {
            float h = hash(j * 3 + 1), h2 = hash(j * 3 + 2);
            double th = (j / (double) DOTS) * Math.PI * 2 + t * (0.55 - 0.35 * h);
            float rad = r * (1.4f + 3.3f * h);
            float x = c[0] + (float) Math.cos(th) * rad, y = c[1] + (float) Math.sin(th) * rad * 0.20f;
            float heat = 1f - (rad / r - 1.4f) / 3.3f;
            int col = mix(rgb, 0xFFFFFF, Math.max(0f, heat));
            float sz = 1.2f + 2.2f * h2;
            centered(ctx, GLOW, x, y, sz * 4f, sz * 4f, argb(0.22f * a, col));
            centered(ctx, DISC, x, y, sz, sz, argb(Math.min(1f, (0.45f + 0.5f * heat) * a), col));
        }
    }
}
