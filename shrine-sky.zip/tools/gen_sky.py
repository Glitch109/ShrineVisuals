import numpy as np
from PIL import Image
import os
OUT = "/home/claude/work/proj/src/main/resources/assets/shrine/textures/gui"
rng = np.random.default_rng(7)

def save(name, rgba):
    a = np.clip(rgba, 0, 1)
    Image.fromarray((a * 255 + 0.5).astype(np.uint8), "RGBA").save(os.path.join(OUT, name + ".png"))
    open(os.path.join(OUT, name + ".png.mcmeta"), "w").write('{"texture": {"blur": true, "clamp": true}}')

def smooth(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)

def tile_noise(w, h, cells_x, cells_y, seed):
    r = np.random.default_rng(seed)
    g = r.random((cells_y, cells_x))
    # bicubic-ish via smooth interpolation, tileable
    ys = np.linspace(0, cells_y, h, endpoint=False)
    xs = np.linspace(0, cells_x, w, endpoint=False)
    y0 = np.floor(ys).astype(int); x0 = np.floor(xs).astype(int)
    fy = ys - y0; fx = xs - x0
    fy = fy * fy * (3 - 2 * fy); fx = fx * fx * (3 - 2 * fx)
    y1 = (y0 + 1) % cells_y; x1 = (x0 + 1) % cells_x
    y0 %= cells_y; x0 %= cells_x
    a = g[np.ix_(y0, x0)]; b = g[np.ix_(y0, x1)]; c = g[np.ix_(y1, x0)]; d = g[np.ix_(y1, x1)]
    fxm = fx[None, :]; fym = fy[:, None]
    return (a * (1 - fxm) + b * fxm) * (1 - fym) + (c * (1 - fxm) + d * fxm) * fym

def fbm(w, h, base, octs, seed, gain=0.5):
    s = np.zeros((h, w)); amp = 1.0; tot = 0
    for o in range(octs):
        cx = base * 2 ** o; cy = max(1, int(base * 2 ** o * h / w))
        s += amp * tile_noise(w, h, cx, cy, seed + o * 17); tot += amp; amp *= gain
    return s / tot

# ---------- 1. aurora curtain: U = along the curtain (tileable), V = height (0 top .. 1 bottom edge) ----------
W, H = 1024, 512
x = np.linspace(0, 1, W, endpoint=False)[None, :]
v = np.linspace(0, 1, H)[:, None]        # 0 = top, 1 = bottom
rays = (0.6 * fbm(W, 8, 24, 3, 3)[0] + 0.4 * fbm(W, 8, 9, 2, 5)[0])[None, :]            # fine vertical rays
rays2 = fbm(W, 8, 11, 2, 9)[0][None, :]           # broad brightness variation
ray = np.clip(0.30 + 1.2 * (rays - 0.35), 0, 1) * (0.45 + 0.8 * rays2)
length = 0.30 + 0.62 * np.clip(fbm(W, 8, 7, 3, 21)[0][None, :] * 1.4 - 0.1, 0, 1)   # how far each ray reaches up
up = 1 - v                                         # 0 at bottom edge, 1 at top
fall = np.clip(1 - up / length, 0, 1) ** 1.5
bottom = smooth(0.0, 0.07, up) * 1.0               # soft cut right at the lower edge ...
glow_bottom = np.exp(-((up) / 0.05) ** 2) * 0.9    # ... with a brighter lower rim
a = (ray * fall * bottom + glow_bottom * (0.3 + 0.7 * ray) * np.clip(1 - up / 0.2, 0, 1))
a *= smooth(0.0, 0.02, 1 - up * 0 - 0) # noop keeps shape
a *= smooth(0.0, 0.015, v[::-1] * 0 + 1 - v) if False else 1
a = np.clip(a * 1.25, 0, 1)
rgba = np.zeros((H, W, 4)); rgba[..., :3] = 1.0; rgba[..., 3] = a
save("sky_aurora", rgba)

# ---------- 2. soft nebula clouds (two variants) ----------
def cloud(size, seed, scale, warp, thresh, soft):
    n = size
    base = fbm(n, n, scale, 5, seed)
    wx = fbm(n, n, scale, 3, seed + 100); wy = fbm(n, n, scale, 3, seed + 200)
    yy, xx = np.mgrid[0:n, 0:n]
    sx = (xx + (wx - 0.5) * warp * n).astype(int) % n
    sy = (yy + (wy - 0.5) * warp * n).astype(int) % n
    f = base[sy, sx]
    d = np.sqrt(((xx - n / 2) / (n / 2)) ** 2 + ((yy - n / 2) / (n / 2)) ** 2)
    mask = smooth(1.0, 0.35, d)
    dens = smooth(thresh, thresh + soft, f) * mask
    return dens, f, mask
n = 512
d1, f1, m1 = cloud(n, 5, 3, 0.35, 0.30, 0.30)
rgba = np.zeros((n, n, 4)); rgba[..., :3] = 1.0
rgba[..., 3] = np.clip(d1 * (0.9 + 0.9 * f1), 0, 1)
save("sky_cloud_a", rgba)
d2, f2, m2 = cloud(n, 41, 4, 0.55, 0.34, 0.30)
rgba = np.zeros((n, n, 4)); rgba[..., :3] = 1.0
rgba[..., 3] = np.clip(d2 * (0.8 + 0.9 * f2), 0, 1)
save("sky_cloud_b", rgba)
# bright puffy core (like the bright blob in the nebula video)
d3, f3, m3 = cloud(n, 77, 4, 0.25, 0.36, 0.34)
rgba = np.zeros((n, n, 4)); rgba[..., :3] = 1.0
rgba[..., 3] = np.clip(d3 ** 0.9 * 1.4, 0, 1)
save("sky_cloud_core", rgba)

# ---------- 3. galaxy band: U = along the band, V = across it ----------
W, H = 1024, 256
u = np.linspace(0, 1, W, endpoint=False)[None, :]
c = np.linspace(-1, 1, H)[:, None]
width = 0.55 + 0.25 * fbm(W, 8, 5, 3, 55)[0][None, :]
prof = np.exp(-(c / width) ** 2 * 2.2)
dust_n = fbm(W, H, 14, 5, 61)
dust = smooth(0.50, 0.66, dust_n) * np.exp(-(c / 0.55) ** 2)
cloudy = fbm(W, H, 9, 5, 71)
lum = prof * (0.35 + 0.9 * cloudy) * (1 - 0.7 * dust)
core = np.exp(-(((u - 0.5) / 0.14) ** 2 + (c / 0.35) ** 2))
lum = lum + 0.9 * core
star_band = (rng.random((H, W)) > 0.9965) * prof * rng.random((H, W)) * 1.5
rgba = np.zeros((H, W, 4)); rgba[..., :3] = 1.0
rgba[..., 3] = np.clip(lum * 0.55 + star_band, 0, 1)
save("sky_galaxy", rgba)

# ---------- 4. caustics tile (seamless): smooth flowing light ribbons ----------
N = 512
TAU = 6.28318530718
uv = np.mgrid[0:N, 0:N] / N
px = np.mod(uv[1] * TAU, TAU) - 250.0
py = np.mod(uv[0] * TAU, TAU) - 250.0
ix, iy = px.copy(), py.copy()
c = np.ones((N, N)); inten = 0.005; tt = 9.5
for n_ in range(5):
    t_ = tt * (1.0 - 3.5 / (n_ + 1))
    ix, iy = px + np.cos(t_ - ix) + np.sin(t_ + iy), py + np.sin(t_ - iy) + np.cos(t_ + ix)
    c += 1.0 / np.sqrt((px / (np.sin(ix + t_) / inten)) ** 2 + (py / (np.cos(iy + t_) / inten)) ** 2)
c /= 5.0
c = 1.17 - np.power(c, 1.4)
l = np.clip(np.power(np.abs(c), 8.0), 0, 1)
l = np.clip(l * 1.15, 0, 1)
rgba = np.zeros((N, N, 4)); rgba[..., :3] = 1.0; rgba[..., 3] = l
save("sky_caustics", rgba)
# soft wide ripple tile for the lit water haze
hz = fbm(N, N, 3, 4, 123)
rgba = np.zeros((N, N, 4)); rgba[..., :3] = 1.0; rgba[..., 3] = np.clip((hz - 0.3) * 1.6, 0, 1) * 0.8
save("sky_haze", rgba)

# ---------- 5. end beam: soft column, U = across, V = up (0 top .. 1 bottom) ----------
W, H = 128, 512
cx_ = np.linspace(-1, 1, W)[None, :]
vv = np.linspace(0, 1, H)[:, None]
core = np.exp(-(cx_ / 0.18) ** 2) * 0.95 + np.exp(-(cx_ / 0.6) ** 2) * 0.35
fallv = (vv ** 1.3)
fade_bot = 1 - smooth(0.96, 1.0, vv)
a = core * fallv * fade_bot
rgba = np.zeros((H, W, 4)); rgba[..., :3] = 1.0; rgba[..., 3] = np.clip(a, 0, 1)
save("sky_beam", rgba)

# ---------- 6. black hole ----------
S = 1024
yy, xx = np.mgrid[0:S, 0:S]
X = (xx - S / 2) / (S / 2); Y = (yy - S / 2) / (S / 2)
R = 0.24   # radius of the dark sphere, in half-texture units
r = np.sqrt(X ** 2 + Y ** 2)
# flat disc seen almost edge-on
tilt = 0.20
rd = np.sqrt(X ** 2 + (Y / tilt) ** 2)
inner, outer = 0.25 * R, 0.95
disc_r = (rd - inner) / (outer - inner)
disc_mask = smooth(0, 0.02, disc_r) * (1 - smooth(0.55, 1.0, disc_r))
heat = np.clip(1 - disc_r * 1.6, 0, 1)
swirl = 0.65 + 0.35 * fbm(S, S, 6, 3, 200)
back = disc_mask * swirl
# front half of the disc (lower half) passes in front of the hole
front_half = (Y > 0).astype(float)
# lensed arc over the top: ring around the hole, thick above, thin below
ang = np.arctan2(Y, X)
lens_r = np.abs(r - R * 1.25)
arc = np.exp(-(lens_r / 0.045) ** 2) * (0.35 + 0.65 * np.clip(-np.sin(ang) * 0.5 + 0.5, 0, 1) ** 1.2)
arc *= np.exp(-(np.abs(X) / 0.65) ** 2)
glow = np.exp(-(r / 0.55) ** 2) * 0.35
tint = np.clip(back * (0.9 + heat) + arc * 1.1 + glow, 0, 1)
rgba = np.zeros((S, S, 4)); rgba[..., :3] = 1.0; rgba[..., 3] = tint
save("sky_bh_tint", rgba)
# hot white inner part
hot = np.clip(back * heat ** 1.4 * 1.5 + arc * 0.9, 0, 1) * np.exp(-(r / 0.5) ** 2 * 0.5)
rgba = np.zeros((S, S, 4)); rgba[..., :3] = 1.0; rgba[..., 3] = hot
save("sky_bh_hot", rgba)
# the black sphere with a thin white rim (like the video)
hole = smooth(R + 0.004, R - 0.004, r)
rim = np.exp(-((r - R * 1.04) / 0.006) ** 2) * 0.9
rgba = np.zeros((S, S, 4))
rgba[..., :3] = np.where(hole[..., None] > 0.5, 0.0, 1.0)
rgba[..., 3] = np.clip(hole + rim * (1 - hole), 0, 1)
save("sky_bh_hole", rgba)
# near half of the disc, drawn after the hole
nearA = disc_mask * swirl * front_half * (0.9 + heat)
rgba = np.zeros((S, S, 4)); rgba[..., :3] = 1.0; rgba[..., 3] = np.clip(nearA, 0, 1)
save("sky_bh_front", rgba)
print("done")
