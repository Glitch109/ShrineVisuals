package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.shrine.Gfx.*;

/**
 * Visual > "Предсказания": where the thing in your hand will land.
 * A thin white line follows the flight, a grainy white disc marks the landing spot, a small card shows the seconds
 * until it lands. When the flight ends on a creature, the line, the disc and the creature's hitbox turn red.
 * Works for ender pearls, snowballs, eggs, potions, bow, crossbow (all three lines with multishot) and trident,
 * and also for projectiles that other players (or mobs) have already thrown.
 *
 * Everything is drawn as a HUD overlay: the 3D points are projected to the screen with the player's own view,
 * so only the plain 2D DrawContext is needed.
 */
final class Predictions {
    private Predictions() {}

    static final String KEY = "pred.on", K_THROW = "pred.throw", K_BOW = "pred.bow", K_OTHERS = "pred.others",
            K_TIMER = "pred.timer", K_HITBOX = "pred.hitbox", K_SIZE = "pred.size";

    private static final int WHITE = 0xFFFFFF, RED = 0xFF4A4A;
    private static final int MAX_TICKS = 160;

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "predictions"),
                (ctx, tick) -> render(ctx, tick));
    }

    // ---------- the player's view (rebuilt every frame) ----------
    private static double cx, cy, cz, rx, ry, rz, ux, uy, uz, fx, fy, fz, tanH, aspect;
    private static int sw, sh;

    /** The vertical field of view the game really uses: the slider value times the sprint / speed / bow-draw zoom. */
    private static double fov(MinecraftClient mc) {
        double base = mc.options.getFov().getValue();
        var p = mc.player;
        float f = 1f;
        if (p.getAbilities().flying) f *= 1.1f;
        float walk = p.getAbilities().getWalkSpeed();
        if (walk > 0f) f *= (p.getMovementSpeed() / walk + 1f) / 2f;
        if (Float.isNaN(f) || Float.isInfinite(f)) f = 1f;
        if (p.isUsingItem() && p.getActiveItem().isOf(Items.BOW)) {
            float g = p.getItemUseTime() / 20f;
            g = g > 1f ? 1f : g * g;
            f *= 1f - g * 0.15f;
        }
        double scale = mc.options.getFovEffectScale().getValue();
        f = (float) (1.0 + (f - 1.0) * scale);
        return base * f;
    }

    private static void setupView(MinecraftClient mc, float td) {
        var p = mc.player;
        Vec3d eye = p.getCameraPosVec(td);
        cx = eye.x; cy = eye.y; cz = eye.z;
        double yaw = Math.toRadians(p.getYaw(td)), pitch = Math.toRadians(p.getPitch(td));
        fx = -Math.sin(yaw) * Math.cos(pitch);
        fy = -Math.sin(pitch);
        fz = Math.cos(yaw) * Math.cos(pitch);
        rx = -Math.cos(yaw); ry = 0; rz = -Math.sin(yaw);
        ux = ry * fz - rz * fy;        // up = right x forward
        uy = rz * fx - rx * fz;
        uz = rx * fy - ry * fx;
        sw = mc.getWindow().getScaledWidth();
        sh = mc.getWindow().getScaledHeight();
        aspect = sw / (double) sh;
        tanH = Math.tan(Math.toRadians(fov(mc)) / 2.0);
    }

    private static double[] toCam(Vec3d v) {
        double dx = v.x - cx, dy = v.y - cy, dz = v.z - cz;
        return new double[]{dx * rx + dy * ry + dz * rz, dx * ux + dy * uy + dz * uz, dx * fx + dy * fy + dz * fz};
    }

    private static float[] toScr(double[] c) {
        double nx = c[0] / (c[2] * tanH * aspect), ny = c[1] / (c[2] * tanH);
        return new float[]{(float) ((nx * 0.5 + 0.5) * sw), (float) ((0.5 - ny * 0.5) * sh)};
    }

    /** Screen position {x, y, depth} of a world point, or null when it is behind the camera. */
    private static float[] project(Vec3d v) {
        double[] c = toCam(v);
        if (c[2] < 0.05) return null;
        float[] s = toScr(c);
        return new float[]{s[0], s[1], (float) c[2]};
    }

    // ---------- drawing primitives ----------
    private static void line(DrawContext ctx, float x1, float y1, float x2, float y2, float th, int color) {
        float dx = x2 - x1, dy = y2 - y1, len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.25f || len > 6000f) return;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x1, y1);
        m.rotate((float) Math.atan2(dy, dx));
        m.translate(0f, -th / 2f);
        m.scale(len, th);
        ctx.fill(0, 0, 1, 1, color);
        m.popMatrix();
    }

    private static double[] clip(double[] behind, double[] front, double near) {
        double t = (near - behind[2]) / (front[2] - behind[2]);
        return new double[]{behind[0] + (front[0] - behind[0]) * t, behind[1] + (front[1] - behind[1]) * t, near};
    }

    /** A world-space segment: a faint wide glow under a thin bright core. */
    private static void seg(DrawContext ctx, Vec3d a, Vec3d b, float th, int rgb, float alpha) {
        double[] ca = toCam(a), cb = toCam(b);
        final double near = 0.05;
        if (ca[2] < near && cb[2] < near) return;
        if (ca[2] < near) ca = clip(ca, cb, near);
        else if (cb[2] < near) cb = clip(cb, ca, near);
        float[] s1 = toScr(ca), s2 = toScr(cb);
        line(ctx, s1[0], s1[1], s2[0], s2[1], th * 3.2f, argb(0.16f * alpha, rgb));
        line(ctx, s1[0], s1[1], s2[0], s2[1], th, argb(alpha, rgb));
    }

    private static float hash(int i) {
        double v = Math.sin(i * 12.9898 + 78.233) * 43758.5453;
        return (float) (v - Math.floor(v));
    }

    /** The landing mark: a ring of dots and a grainy disc of slowly turning dots, lying on the surface that was hit. */
    private static void disc(DrawContext ctx, Vec3d c, Vec3d n, double radius, int rgb, float alpha, float time) {
        Vec3d ref = Math.abs(n.y) > 0.9 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0);
        Vec3d u = n.crossProduct(ref).normalize(), v = n.crossProduct(u).normalize();
        Vec3d o = c.add(n.multiply(0.03));
        final int RINGN = 56, FILL = 120;
        for (int i = 0; i < RINGN + FILL; i++) {
            boolean ring = i < RINGN;
            float r1 = hash(i * 3 + 1), r2 = hash(i * 3 + 2), r3 = hash(i * 3 + 3);
            double rad = ring ? radius : radius * Math.sqrt(r1) * 0.97;
            double ang = ring ? i * (Math.PI * 2 / RINGN) + time * 0.25 : r2 * Math.PI * 2 + time * (0.18 + 0.25 * r1);
            Vec3d p = o.add(u.multiply(Math.cos(ang) * rad)).add(v.multiply(Math.sin(ang) * rad));
            float[] s = project(p);
            if (s == null) continue;
            float worldSize = ring ? 0.055f : 0.035f + 0.03f * r3;
            float px = Math.max(1f, Math.min(4.5f, (float) (worldSize * sh / (2.0 * tanH * s[2]))));
            float a = ring ? 0.85f : (0.22f + 0.5f * r3) * (0.75f + 0.25f * (float) Math.sin(time * 3f + i));
            centered(ctx, DISC, s[0], s[1], px, px, argb(a * alpha, rgb));
        }
    }

    private static void hitbox(DrawContext ctx, Box b, int rgb, float alpha) {
        Vec3d[] c = new Vec3d[8];
        for (int i = 0; i < 8; i++)
            c[i] = new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
        int[][] edges = {{0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
        for (int[] e : edges) seg(ctx, c[e[0]], c[e[1]], 0.8f, rgb, alpha);
    }

    // ---------- flight simulation ----------
    private record Path(List<Vec3d> pts, Vec3d end, Vec3d normal, LivingEntity target, int ticks) {}

    private static Path sim(MinecraftClient mc, Vec3d pos, Vec3d vel, double grav, Entity skip, List<LivingEntity> cands) {
        List<Vec3d> pts = new ArrayList<>();
        pts.add(pos);
        for (int t = 0; t < MAX_TICKS; t++) {
            Vec3d next = pos.add(vel);
            LivingEntity he = null;
            Vec3d hp = null;
            double best = Double.MAX_VALUE;
            for (LivingEntity e : cands) {
                if (e == skip) continue;
                var o = e.getBoundingBox().expand(0.3).raycast(pos, next);
                if (o.isPresent()) {
                    double d = o.get().squaredDistanceTo(pos);
                    if (d < best) { best = d; he = e; hp = o.get(); }
                }
            }
            BlockHitResult bh = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, skip != null ? skip : mc.player));
            boolean blk = bh.getType() != HitResult.Type.MISS;
            if (he != null && (!blk || best <= bh.getPos().squaredDistanceTo(pos))) {
                pts.add(hp);
                return new Path(pts, hp, new Vec3d(0, 1, 0), he, t + 1);
            }
            if (blk) {
                pts.add(bh.getPos());
                var d = bh.getSide();
                return new Path(pts, bh.getPos(), new Vec3d(d.getOffsetX(), d.getOffsetY(), d.getOffsetZ()), null, t + 1);
            }
            pts.add(next);
            pos = next;
            vel = vel.multiply(0.99).subtract(0, grav, 0);
            if (next.y < mc.world.getBottomY() - 8) break;
        }
        return new Path(pts, null, null, null, MAX_TICKS);
    }

    private static List<LivingEntity> candidates(MinecraftClient mc) {
        List<LivingEntity> l = new ArrayList<>();
        for (Entity e : mc.world.getEntities())
            if (e instanceof LivingEntity le && le.isAlive() && !le.isSpectator() && le.squaredDistanceTo(mc.player) < 96.0 * 96.0) l.add(le);
        return l;
    }

    // ---------- what the player holds ----------
    /** speed, gravity, extra pitch ("roll"), yaw offsets of every line (degrees). */
    private record Shot(double speed, double grav, float roll, float[] yaw) {}

    private static final float[] ONE = {0f}, THREE = {-10f, 0f, 10f};

    private static Shot shot(MinecraftClient mc) {
        var p = mc.player;
        boolean bow = ShrineCfg.bool(K_BOW, true), thr = ShrineCfg.bool(K_THROW, true);
        ItemStack act = p.getActiveItem();
        if (bow && p.isUsingItem()) {
            if (act.isOf(Items.BOW)) {
                float f = p.getItemUseTime() / 20f;
                f = Math.min(1f, (f * f + f * 2f) / 3f);
                if (f >= 0.1f) return new Shot(f * 3.0, 0.05, 0f, ONE);
            } else if (act.isOf(Items.TRIDENT) && p.getItemUseTime() >= 10) {
                return new Shot(2.5, 0.05, 0f, ONE);
            }
        }
        for (ItemStack st : new ItemStack[]{p.getMainHandStack(), p.getOffHandStack()}) {
            if (bow && st.isOf(Items.CROSSBOW) && CrossbowItem.isCharged(st)) {
                var cp = st.get(DataComponentTypes.CHARGED_PROJECTILES);
                boolean fire = false;
                if (cp != null) for (ItemStack a : cp.getProjectiles()) if (a.isOf(Items.FIREWORK_ROCKET)) fire = true;
                boolean multi = cp != null && cp.getProjectiles().size() >= 3;
                return new Shot(fire ? 1.6 : 3.15, fire ? 0.0 : 0.05, 0f, multi ? THREE : ONE);
            }
            if (!thr) continue;
            if (st.isOf(Items.ENDER_PEARL) || st.isOf(Items.SNOWBALL) || st.isOf(Items.EGG)) return new Shot(1.5, 0.03, 0f, ONE);
            if (st.isOf(Items.SPLASH_POTION) || st.isOf(Items.LINGERING_POTION)) return new Shot(0.5, 0.05, -20f, ONE);
            if (st.isOf(Items.EXPERIENCE_BOTTLE)) return new Shot(0.7, 0.07, -20f, ONE);
        }
        return null;
    }

    private static Vec3d rotate(Vec3d v, Vec3d axis, double deg) {
        double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
        return v.multiply(c).add(axis.crossProduct(v).multiply(s)).add(axis.multiply(axis.dotProduct(v) * (1 - c)));
    }

    /** Gravity of a projectile that is already flying, or -1 when it is not one we draw. */
    private static double gravityOf(Entity e) {
        String n = e.getType().getUntranslatedName();
        return switch (n) {
            case "arrow", "spectral_arrow", "trident", "potion", "splash_potion", "lingering_potion" -> 0.05;
            case "ender_pearl", "snowball", "egg" -> 0.03;
            case "experience_bottle" -> 0.07;
            default -> -1.0;
        };
    }

    // ---------- the HUD element ----------
    private static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, true) || !mc.options.getPerspective().isFirstPerson()) return;
        float td = tick.getTickProgress(true);
        float time = (Util.getMeasuringTimeMs() % 600000L) / 1000f;
        float size = Math.max(0.5f, Math.min(2.5f, ShrineCfg.num(K_SIZE, 1f)));
        boolean wantBox = ShrineCfg.bool(K_HITBOX, true), wantTimer = ShrineCfg.bool(K_TIMER, true);

        Shot shot = shot(mc);
        boolean others = ShrineCfg.bool(K_OTHERS, true);
        if (shot == null && !others) return;
        setupView(mc, td);
        List<LivingEntity> cands = candidates(mc);
        float k = sh / Scene.REF_H;
        TextRenderer tr = mc.textRenderer;

        // --- own shot ---
        if (shot != null) {
            var p = mc.player;
            double yawD = p.getYaw(td), pitchD = p.getPitch(td);
            double yr = Math.toRadians(yawD), pr = Math.toRadians(pitchD), gr = Math.toRadians(pitchD + shot.roll());
            Vec3d dir = new Vec3d(-Math.sin(yr) * Math.cos(pr), -Math.sin(gr), Math.cos(yr) * Math.cos(pr)).normalize();
            Vec3d up = new Vec3d(ux, uy, uz);
            Vec3d pv = p.getVelocity();
            Vec3d start = new Vec3d(cx, cy - 0.1, cz);
            Path centre = null;
            for (float off : shot.yaw()) {
                Vec3d d = off == 0f ? dir : rotate(dir, up, off);
                Vec3d vel = d.multiply(shot.speed()).add(pv.x, p.isOnGround() ? 0.0 : pv.y, pv.z);
                Path path = sim(mc, start, vel, shot.grav(), p, cands);
                drawPath(ctx, path, wantBox, size, time, td);
                if (off == 0f) centre = path;
            }
            if (centre != null && centre.end() != null && wantTimer)
                card(ctx, tr, sw / k, k, centre.ticks() / 20f, centre.target() != null);
        }

        // --- projectiles that are already in the air (other players', mobs', and your own) ---
        if (others) {
            int shown = 0;
            for (Entity e : mc.world.getEntities()) {
                if (shown >= 12) break;
                if (!(e instanceof ProjectileEntity proj) || e.isRemoved()) continue;
                double g = gravityOf(e);
                Vec3d vel = e.getVelocity();
                if (g < 0.0 || vel.lengthSquared() < 0.04 || e.squaredDistanceTo(mc.player) > 80.0 * 80.0) continue;
                Path path = sim(mc, e.getLerpedPos(td), vel, g, proj.getOwner(), cands);
                if (path.end() == null) continue;
                shown++;
                drawPath(ctx, path, wantBox, size, time, td);
                float[] s = project(path.end());
                if (s != null) {
                    String t = String.format(Locale.ROOT, "%.1f с", path.ticks() / 20f);
                    ctx.getMatrices().pushMatrix();
                    ctx.getMatrices().scale(k, k);
                    textC(ctx, tr, Fnt.TINY_B, t, s[0] / k, s[1] / k - 16f,
                            argb(0.95f, path.target() != null ? RED : WHITE));
                    ctx.getMatrices().popMatrix();
                }
            }
        }
    }

    private static void drawPath(DrawContext ctx, Path path, boolean wantBox, float size, float time, float td) {
        boolean hit = path.target() != null;
        int rgb = hit ? RED : WHITE;
        List<Vec3d> pts = path.pts();
        int n = pts.size();
        for (int i = 0; i + 1 < n; i++) {
            float fade = 1f - 0.55f * (i / (float) Math.max(1, n - 1));   // brighter near the hand, softer toward the end
            seg(ctx, pts.get(i), pts.get(i + 1), 0.75f, rgb, fade);
        }
        if (path.end() == null) return;
        disc(ctx, path.end(), path.normal(), 0.75 * size, rgb, 1f, time);
        if (hit && wantBox) {
            LivingEntity t = path.target();
            Vec3d lp = t.getLerpedPos(td);
            Box b = t.getBoundingBox().offset(lp.x - t.getX(), lp.y - t.getY(), lp.z - t.getZ());
            hitbox(ctx, b, RED, 0.95f);
        }
    }

    /** "До падения 2.1 s": a small glass card at the top of the screen. */
    private static void card(DrawContext ctx, TextRenderer tr, float vw, float k, float sec, boolean red) {
        float W = 158f, H = 54f;
        int rgb = red ? RED : WHITE;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.scale(k, k);
        m.translate(vw / 2f - W / 2f, 84f);
        box(ctx, RR, -1, -1, W + 2, H + 2, 15, argb(red ? 0.55f : 0.14f, rgb));
        box(ctx, RR, 0, 0, W, H, 14, argb(0.88f, 0x0E0E0E));
        text(ctx, tr, Fnt.TINY_B, "ДО", 18, H / 2f - 8f, argb(0.5f, WHITE));
        text(ctx, tr, Fnt.TINY_B, "ПАДЕНИЯ", 18, H / 2f + 8f, argb(0.5f, WHITE));
        String num = String.format(Locale.ROOT, "%.1f", sec);
        float nw = width(tr, Fnt.NAME_B, num), sw2 = width(tr, Fnt.TINY_B, "s");
        text(ctx, tr, Fnt.NAME_B, num, W - 18f - sw2 - 3f - nw, H / 2f, argb(1f, rgb));
        text(ctx, tr, Fnt.TINY_B, "s", W - 18f - sw2, H / 2f + 5f, argb(0.7f, rgb));
        m.popMatrix();
    }
}
