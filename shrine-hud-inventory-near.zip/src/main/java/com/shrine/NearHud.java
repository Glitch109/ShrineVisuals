package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.List;

import static com.shrine.Gfx.*;

/**
 * Hud > "Players Near": a list of the players around you, nearest first. Each row has the head, the nick, the distance in
 * blocks (colored: close = warm, far = green-yellow) and an arrow that turns to show where that player is relative to
 * where you look. Position and size: {@link HudEditScreen}.
 */
final class NearHud implements HudEditScreen.HudPanel {
    private NearHud() {}
    static final NearHud PANEL = new NearHud();

    static final String KEY = "hud.near", K_LIMIT = "near.limit", K_RANGE = "near.range", K_ARROW = "near.arrow",
            K_COLOR = "near.color", K_SCALE = "near.scale", K_X = "near.x", K_Y = "near.y";
    static final float LEFT = 10f, TOP = 90f, W = 214f, HEAD = 36f, ROW = 30f, PAD = 12f;
    static final Identifier ARROW = tex("arrow"), SORT = tex("sort");

    static final class Row {
        final String name; final float dist, rel; final AbstractClientPlayerEntity skin;
        Row(String name, float dist, float rel, AbstractClientPlayerEntity skin) { this.name = name; this.dist = dist; this.rel = rel; this.skin = skin; }
    }

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "near_hud"), (ctx, tick) -> render(ctx));
    }

    // ---------- settings ----------
    static float posX() { return ShrineCfg.num(K_X, 0f); }
    static float posY() { return ShrineCfg.num(K_Y, 0f); }
    static float sc() { return Math.max(0.5f, Math.min(2.5f, ShrineCfg.num(K_SCALE, 1f))); }
    private static int color() { return ShrineGui.PALETTE[Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 0)))]; }
    static float height(int rows) { return HEAD + Math.max(1, rows) * ROW + 10f; }

    // ---------- the in-game element ----------
    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, false)) return;
        float range = ShrineCfg.num(K_RANGE, 64f);
        int limit = Math.max(1, Math.min(22, ShrineCfg.integer(K_LIMIT, 4)));
        List<Row> all = new ArrayList<>();
        for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || p.isSpectator()) continue;
            float d = mc.player.distanceTo(p);
            if (d > range) continue;
            double dx = p.getX() - mc.player.getX(), dz = p.getZ() - mc.player.getZ();
            float toYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));      // Minecraft yaw: 0 = +Z, turning right grows it
            all.add(new Row(p.getName().getString(), d, MathHelper.wrapDegrees(toYaw - mc.player.getYaw()), p));
        }
        all.sort((a, b) -> Float.compare(a.dist, b.dist));
        int total = all.size();
        List<Row> rows = all.size() > limit ? all.subList(0, limit) : all;
        drawAt(ctx, mc.textRenderer, rows, total);
    }

    static void drawAt(DrawContext ctx, TextRenderer tr, List<Row> rows, int total) {
        MinecraftClient mc = MinecraftClient.getInstance();
        float k = mc.getWindow().getScaledHeight() / Scene.REF_H;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        ctx.getMatrices().translate(LEFT + posX(), TOP + posY());
        ctx.getMatrices().scale(sc(), sc());
        panel(ctx, tr, rows, total);
        ctx.getMatrices().popMatrix();
    }

    private static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** Close = orange, middle = amber, far = yellow-green. */
    private static int distColor(float d) {
        if (d <= 8f) return 0xFF8A57;
        if (d <= 20f) return mix(0xFF8A57, 0xFFC857, (d - 8f) / 12f);
        if (d <= 40f) return mix(0xFFC857, 0xD7E56A, (d - 20f) / 20f);
        return 0xD7E56A;
    }

    private static String fit(TextRenderer tr, Fnt f, String s, float max) {
        if (width(tr, f, s) <= max) return s;
        String t = s;
        while (t.length() > 1 && width(tr, f, t + "…") > max) t = t.substring(0, t.length() - 1);
        return t + "…";
    }

    private static void panel(DrawContext ctx, TextRenderer tr, List<Row> rows, int total) {
        int col = color();
        int n = Math.max(1, rows.size());
        float H = height(rows.size());
        box(ctx, RR, -1.5f, -1.5f, W + 3f, H + 3f, 19.5f, argb(0.55f, col));
        box(ctx, RR, 0, 0, W, H, 18, argb(0.90f, 0x0E0E12));
        // header: icon, title, count
        centered(ctx, SORT, PAD + 8f, HEAD / 2f, 16, 16, argb(0.85f, 0xFFFFFF));
        text(ctx, tr, Fnt.UI_B, "Players Near", PAD + 24f, HEAD / 2f, argb(1f, 0xFFFFFF));
        String cnt = String.valueOf(total);
        text(ctx, tr, Fnt.LABEL, cnt, W - PAD - width(tr, Fnt.LABEL, cnt), HEAD / 2f, argb(0.6f, 0xFFFFFF));
        box(ctx, RR, PAD, HEAD - 3f, W - PAD * 2, 1, 0, argb(0.14f, 0xFFFFFF));
        if (rows.isEmpty()) {
            textC(ctx, tr, Fnt.SMALL, "Рядом никого", W / 2f, HEAD + ROW / 2f, argb(0.5f, 0xFFFFFF));
            return;
        }
        boolean arrows = ShrineCfg.bool(K_ARROW, true);
        for (int i = 0; i < n && i < rows.size(); i++) {
            Row r = rows.get(i);
            float cy = HEAD + i * ROW + ROW / 2f;
            if (i == 0 && r.dist <= 10f) box(ctx, RR, 5, cy - ROW / 2f + 2f, W - 10f, ROW - 4f, 10, argb(0.07f, 0xFFFFFF));
            // head
            float hs = 20f, hx = PAD, hy = cy - hs / 2f;
            box(ctx, RR, hx - 1.5f, hy - 1.5f, hs + 3f, hs + 3f, 7, argb(0.5f, 0x000000));
            if (r.skin != null) PlayerSkinDrawer.draw(ctx, r.skin.getSkin(), Math.round(hx), Math.round(hy), Math.round(hs), argb(1f, 0xFFFFFF));
            else box(ctx, RR, hx, hy, hs, hs, 6, argb(0.9f, 0x333333));
            // right side: arrow circle, distance
            float ax = W - PAD - 11f;
            float dEnd = arrows ? ax - 11f - 8f : W - PAD;
            String ds = Math.round(r.dist) + "m";
            int dc = distColor(r.dist);
            text(ctx, tr, Fnt.UI_B, ds, dEnd - width(tr, Fnt.UI_B, ds), cy, argb(1f, dc));
            float nameMax = dEnd - width(tr, Fnt.UI_B, ds) - (PAD + hs + 8f) - 8f;
            text(ctx, tr, Fnt.LABEL, fit(tr, Fnt.LABEL, r.name, nameMax), PAD + hs + 8f, cy, argb(1f, 0xFFFFFF));
            if (arrows) {
                centered(ctx, DISC, ax, cy, 22, 22, argb(0.16f, col));
                ctx.getMatrices().pushMatrix();
                ctx.getMatrices().translate(ax, cy);
                ctx.getMatrices().rotate((float) Math.toRadians(r.rel));
                centered(ctx, ARROW, 0f, 0f, 14, 14, argb(1f, 0xFFFFFF));
                ctx.getMatrices().popMatrix();
            }
        }
    }

    // ---------- the position editor ----------
    @Override public float[] bounds(float vw) { float s = sc(); return new float[]{LEFT + posX(), TOP + posY(), W * s, height(4) * s}; }
    @Override public float scale() { return sc(); }
    @Override public void setScale(float s) { ShrineCfg.setNum(K_SCALE, s); }
    @Override public void reset() { ShrineCfg.setNum(K_X, 0f); ShrineCfg.setNum(K_Y, 0f); ShrineCfg.setNum(K_SCALE, 1f); }
    @Override public void place(float vw, float left, float top, float[] b) {
        ShrineCfg.setNum(K_X, Math.max(-LEFT, Math.min(vw - 40f, left - LEFT)));
        ShrineCfg.setNum(K_Y, Math.max(-TOP, Math.min(Scene.REF_H - TOP - 20f, top - TOP)));
    }
    @Override public void drawDemo(DrawContext ctx, TextRenderer tr, float vw) {
        AbstractClientPlayerEntity me = MinecraftClient.getInstance().player;
        List<Row> rows = List.of(new Row("Kaktus", 7f, -62f, me), new Row("Frostbyte", 14f, 38f, me),
                new Row("Nightfall", 32f, 150f, me), new Row("Pixel", 33f, -140f, me));
        drawAt(ctx, tr, rows, 4);
    }
}
