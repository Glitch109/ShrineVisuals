package com.shrine;

import com.shrine.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

import static com.shrine.Gfx.*;

/** Position editor for a HUD panel (target health or inventory): drag it with the mouse, change its size with the wheel. */
final class HudEditScreen extends Screen {
    /** A HUD panel that can be placed with the mouse: the target panel, the inventory grid, the nearby-players list. */
    interface HudPanel {
        /** {left, top, width, height} on the virtual canvas. */
        float[] bounds(float vw);
        void drawDemo(DrawContext ctx, net.minecraft.client.font.TextRenderer tr, float vw);
        /** The panel was dragged so that its top-left corner is at (left, top): store the settings. */
        void place(float vw, float left, float top, float[] bounds);
        void reset();
        float scale();
        void setScale(float s);
        default float maxScale() { return 2.5f; }
    }

    /** The "Здоровье цели" panel (kept as it was). */
    static final HudPanel TARGET = new HudPanel() {
        private final TargetHud.Data demo = TargetHud.demo();
        @Override public float[] bounds(float vw) {
            float sc = TargetHud.scale();
            float[] sz = TargetHud.size(TargetHud.design(), ShrineCfg.bool(TargetHud.KEY_ARMOR, true));
            return new float[]{vw / 2f + TargetHud.posX() - sz[0] * sc / 2f, TargetHud.DEFAULT_TOP + TargetHud.posY(), sz[0] * sc, sz[1] * sc};
        }
        @Override public void drawDemo(DrawContext ctx, net.minecraft.client.font.TextRenderer tr, float vw) { TargetHud.drawAt(ctx, tr, vw, demo, 1f, 0f); }
        @Override public void place(float vw, float left, float top, float[] b) {
            float nx = left + b[2] / 2f - vw / 2f, ny = top - TargetHud.DEFAULT_TOP;
            ShrineCfg.setNum(TargetHud.K_X, Math.max(-vw, Math.min(vw, nx)));
            ShrineCfg.setNum(TargetHud.K_Y, Math.max(-TargetHud.DEFAULT_TOP, Math.min(Scene.REF_H - TargetHud.DEFAULT_TOP - 20f, ny)));
        }
        @Override public void reset() { ShrineCfg.setNum(TargetHud.K_X, 0f); ShrineCfg.setNum(TargetHud.K_Y, 0f); ShrineCfg.setNum(TargetHud.K_SCALE, 1f); }
        @Override public float scale() { return TargetHud.scale(); }
        @Override public void setScale(float s) { ShrineCfg.setNum(TargetHud.K_SCALE, s); }
    };

    private final Screen parent;
    private final HudPanel panel;
    private float k = 1f, vw = 960f;
    private boolean drag;
    private float offX, offY;
    private float[] rDone = new float[4], rReset = new float[4];

    HudEditScreen(Screen parent) { this(parent, TARGET); }

    HudEditScreen(Screen parent, HudPanel panel) {
        super(Text.literal("Shrine"));
        this.parent = parent;
        this.panel = panel;
    }

    private float sc() { return panel.scale(); }

    @Override protected void init() { k = height / Scene.REF_H; vw = width / k; }
    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }

    /** Panel bounds in virtual units: {left, top, width, height}. */
    private float[] bounds() { return panel.bounds(vw); }

    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        ctx.fillGradient(0, 0, width, height, argb(0.30f, 0x050505), argb(0.50f, 0x161616));
        float mx = mxReal / k, my = myReal / k;

        // center guides
        ctx.fill(width / 2, 0, width / 2 + 1, height, argb(0.10f, 0xFFFFFF));
        ctx.fill(0, height / 2, width, height / 2 + 1, argb(0.10f, 0xFFFFFF));

        panel.drawDemo(ctx, textRenderer, vw);

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        float[] b = bounds();
        boolean hov = drag || inside(mx, my, b[0], b[1], b[2], b[3]);
        box(ctx, RR_RING, b[0] - 5, b[1] - 5, b[2] + 10, b[3] + 10, 20, argb((hov ? 0.9f : 0.45f), ACCENT));

        textC(ctx, textRenderer, Fnt.UI_B, "Перетащи панель мышью", vw / 2f, 60, argb(1f, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.SMALL, "Колёсико мыши - размер (" + Math.round(sc() * 100f) + "%)", vw / 2f, 84, argb(0.65f, 0xFFFFFF));

        float by = Scene.REF_H - 74f;
        rDone = new float[]{vw / 2f + 6f, by, 130f, 40f};
        rReset = new float[]{vw / 2f - 136f, by, 130f, 40f};
        button(ctx, rReset, "Сбросить", false, mx, my);
        button(ctx, rDone, "Готово", true, mx, my);
        ctx.getMatrices().popMatrix();
    }

    private void button(DrawContext ctx, float[] r, String label, boolean primary, float mx, float my) {
        boolean hov = inside(mx, my, r[0], r[1], r[2], r[3]);
        box(ctx, RR, r[0], r[1], r[2], r[3], 20, argb(primary ? (hov ? 1f : 0.92f) : (hov ? 0.22f : 0.12f), primary ? ACCENT : 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI_B, label, r[0] + r[2] / 2f, r[1] + r[3] / 2f, argb(1f, 0xFFFFFF));
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        double mx = click.x() / k, my = click.y() / k;
        if (inside(mx, my, rDone[0], rDone[1], rDone[2], rDone[3])) { close(); return true; }
        if (inside(mx, my, rReset[0], rReset[1], rReset[2], rReset[3])) {
            panel.reset();
            return true;
        }
        float[] b = bounds();
        if (inside(mx, my, b[0], b[1], b[2], b[3])) { drag = true; offX = (float) mx - b[0]; offY = (float) my - b[1]; return true; }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (!drag) return super.mouseDragged(click, dx, dy);
        double mx = click.x() / k, my = click.y() / k;
        float[] b = bounds();
        float left = (float) mx - offX, top = (float) my - offY;
        panel.place(vw, left, top, b);
        return true;
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (drag) { drag = false; ShrineCfg.save(); return true; }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        float s = sc() * (float) Math.pow(1.08, verticalAmount);
        panel.setScale(Math.max(0.5f, Math.min(panel.maxScale(), s)));
        ShrineCfg.save();
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (input.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        ShrineCfg.save();
        if (client != null) client.setScreen(parent);
    }
}
