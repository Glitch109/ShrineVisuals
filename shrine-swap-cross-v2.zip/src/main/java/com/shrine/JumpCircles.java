package com.shrine;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static com.shrine.Gfx.argb;

/**
 * Player > "Круги прыжка": an effect on the ground where you left it. Works in first AND third person
 * (the view comes from {@link Predictions#setupView}, which follows the game camera).
 * <p>
 * Looks: textured decals lying flat on the ground (ring, burst, wheel, whirlpool, storm), "Блоки": the blocks around
 * the jump light up in a circle that spreads outward, and "Ударная волна": on LANDING a ring of glowing block outlines
 * runs out from the feet. A decal is drawn as a 16 x 16 grid of small textured cells; every cell corner is projected
 * on its own, so the perspective is right even when the ring is large or close to the camera (an old version
 * stretched one flat picture over the ground and it flooded the screen when the circle grew).
 */
final class JumpCircles {
    private JumpCircles() {}

    static final String KEY = "jc.on", K_TYPE = "jc.type", K_SIZE = "jc.size", K_TIME = "jc.time", K_COLOR = "jc.color",
            K_GLOW = "jc.glow";
    static final String[] TYPES = {"Кольцо", "Взрыв", "Колесо", "Омут", "Шторм", "Блоки", "Ударная волна"};
    private static final int BLOCKS = 5, SHOCK = 6;    // indexes of the block looks

    private static Identifier t(String n) { return Identifier.of("shrine", "textures/jump/" + n + ".png"); }
    /** A decal texture: its id, its size in pixels and which cells of the 16 x 16 grid are not empty. */
    private record Tex(Identifier id, int size, String mask) {}
    private static final Tex RING = new Tex(t("ring"), 512, JumpMasks.RING), GLOW = new Tex(t("glow"), 416, JumpMasks.GLOW),
            BOOM1 = new Tex(t("boom1"), 256, JumpMasks.BOOM1), BOOM2 = new Tex(t("boom2"), 400, JumpMasks.BOOM2),
            COLSO1 = new Tex(t("colso1"), 512, JumpMasks.COLSO1), COLSO3 = new Tex(t("colso3"), 512, JumpMasks.COLSO3),
            OMUT2 = new Tex(t("omut2"), 384, JumpMasks.OMUT2), OMUT3 = new Tex(t("omut3"), 512, JumpMasks.OMUT3),
            SHTORM1 = new Tex(t("shtorm1"), 512, JumpMasks.SHTORM1), SHTORM2 = new Tex(t("shtorm2"), 512, JumpMasks.SHTORM2);
    private static final int GRID = 16, CELL = 16;

    private static final int MAX_ALIVE = 8;            // hard cap so bunny-hopping cannot flood the screen
    private static final float EDGE = 0.9f;            // how wide (blocks) the lit band of the block wave is

    /** One effect: where it started, when, and (for the block look) the surface blocks around it: {x, topY, z, distance}. */
    private record Fx(double x, double y, double z, long born, List<double[]> blocks, boolean shock) {}

    private static final List<Fx> LIST = new ArrayList<>();
    private static boolean wasOnGround = true;
    private static int airTicks;

    static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(JumpCircles::tick);
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "jump_circles"),
                (ctx, tick) -> render(ctx, tick));
    }

    // ---------- spawning: the tick where the feet leave the ground (landing for "Ударная волна") ----------
    private static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) { LIST.clear(); wasOnGround = true; airTicks = 0; return; }
        boolean ground = mc.player.isOnGround();
        int type = Math.max(0, Math.min(TYPES.length - 1, ShrineCfg.integer(K_TYPE, 0)));
        boolean ok = ShrineCfg.bool(KEY, true) && !mc.player.isTouchingWater() && !mc.player.isClimbing() && !mc.player.hasVehicle();
        if (ok && type == SHOCK && ground && !wasOnGround && airTicks >= 4) spawn(mc, type);                        // landed after a real jump / fall
        else if (ok && type != SHOCK && wasOnGround && !ground && mc.player.getVelocity().y > 0.05) spawn(mc, type); // took off
        airTicks = ground ? 0 : airTicks + 1;
        wasOnGround = ground;
    }

    private static void spawn(MinecraftClient mc, int type) {
        if (LIST.size() >= MAX_ALIVE) LIST.remove(0);
        double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
        float radius = Math.max(0.5f, Math.min(4f, ShrineCfg.num(K_SIZE, 1.6f)));
        boolean blocks = type == BLOCKS || type == SHOCK;
        float scanR = type == SHOCK ? radius * 1.8f : radius;        // the shockwave runs farther than the other looks
        LIST.add(new Fx(x, y + 0.03, z, Util.getMeasuringTimeMs(), blocks ? scan(mc, x, y, z, scanR) : null, type == SHOCK));
    }

    /** Collects the top face of every walkable block within {@code maxR} of the jump point. */
    private static List<double[]> scan(MinecraftClient mc, double cx, double cy, double cz, float maxR) {
        List<double[]> out = new ArrayList<>();
        int r = (int) Math.ceil(maxR) + 1, fx = (int) Math.floor(cx), fy = (int) Math.floor(cy + 0.1), fz = (int) Math.floor(cz);
        BlockPos.Mutable p = new BlockPos.Mutable();
        for (int bx = fx - r; bx <= fx + r; bx++) {
            for (int bz = fz - r; bz <= fz + r; bz++) {
                double d = Math.hypot(bx + 0.5 - cx, bz + 0.5 - cz);
                if (d > maxR + 0.8) continue;
                for (int by = fy; by >= fy - 3; by--) {
                    var st = mc.world.getBlockState(p.set(bx, by, bz));
                    if (!st.isSideSolidFullSquare(mc.world, p, Direction.UP)) continue;
                    if (mc.world.getBlockState(p.set(bx, by + 1, bz)).isAir()) out.add(new double[]{bx, by + 1.012, bz, d});
                    break;
                }
            }
        }
        return out;
    }

    // ---------- drawing ----------
    private static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (LIST.isEmpty() || mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, true)) return;
        Predictions.setupView(mc, tick.getTickProgress(true));

        float radius = Math.max(0.5f, Math.min(4f, ShrineCfg.num(K_SIZE, 1.6f)));
        float life = Math.max(0.3f, Math.min(3f, ShrineCfg.num(K_TIME, 1.1f))) * 1000f;
        int rgb = ShrineGui.PALETTE[Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 1)))];
        boolean glow = ShrineCfg.bool(K_GLOW, true);
        long now = Util.getMeasuringTimeMs();

        for (Iterator<Fx> it = LIST.iterator(); it.hasNext(); ) {
            Fx f = it.next();
            float age = (now - f.born()) / life;
            if (age >= 1f) { it.remove(); continue; }
            float grow = ease(age), fade = (1f - age) * (1f - age);
            float spin = (now - f.born()) / 1000f;
            if (f.blocks() != null) {
                if (f.shock()) shock(ctx, f, radius * 1.8f * grow, fade, rgb);
                else blocks(ctx, f, radius * grow, fade, rgb);
                continue;
            }

            int type = Math.max(0, Math.min(TYPES.length - 1, ShrineCfg.integer(K_TYPE, 0)));
            if (glow) decal(ctx, f, GLOW, radius * grow * 1.25f, 0f, rgb, 0.45f * fade);
            switch (type) {
                case 0 -> decal(ctx, f, RING, radius * grow, 0f, rgb, fade);
                case 1 -> {                                                         // burst: the radial ring flies out, a crescent follows
                    decal(ctx, f, BOOM1, radius * grow, spin * 0.6f, rgb, fade);
                    decal(ctx, f, BOOM2, radius * grow * 0.85f, -spin * 2.2f, rgb, 0.9f * fade);
                }
                case 2 -> {                                                         // wheel: a fine ring and a crescent turning opposite ways
                    decal(ctx, f, COLSO1, radius * grow, 0f, rgb, fade);
                    decal(ctx, f, COLSO3, radius * grow * 0.92f, spin * 2.6f, rgb, fade);
                }
                case 3 -> {                                                         // whirlpool: two smoky layers turning against each other
                    decal(ctx, f, OMUT3, radius * grow, spin * 1.2f, rgb, fade);
                    decal(ctx, f, OMUT2, radius * grow * 0.8f, -spin * 1.8f, rgb, 0.9f * fade);
                }
                default -> {                                                        // storm: fast sweeping arcs
                    decal(ctx, f, SHTORM2, radius * grow, spin * 3.2f, rgb, fade);
                    decal(ctx, f, SHTORM1, radius * grow * 1.1f, -spin * 2.0f, rgb, 0.85f * fade);
                }
            }
        }
    }

    /** Fast at the start, settling at the end. */
    private static float ease(float t) { float u = 1f - t; return 1f - u * u * u; }

    /**
     * A texture lying flat on the ground around the jump point. {@code rad}: radius in blocks (the texture spans 2 x rad),
     * {@code spin}: turn in radians. The ground square is cut into 16 x 16 cells; each cell corner is projected on its own and
     * each non-empty cell is drawn as a small textured parallelogram, which is exact enough for a cell. Cells that are
     * behind the camera are dropped and cells close to the camera fade out, so a big ring never floods the screen.
     */
    private static void decal(DrawContext ctx, Fx f, Tex tex, float rad, float spin, int rgb, float alpha) {
        if (rad < 0.03f || alpha < 0.02f) return;
        final int n = GRID;
        float[][] sx = new float[n + 1][n + 1], sy = new float[n + 1][n + 1], sd = new float[n + 1][n + 1];
        boolean[][] ok = new boolean[n + 1][n + 1];
        double cs = Math.cos(spin), sn = Math.sin(spin);
        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <= n; j++) {
                double u = (i / (double) n * 2.0 - 1.0) * rad, v = (j / (double) n * 2.0 - 1.0) * rad;
                float[] s = Predictions.project(new Vec3d(f.x() + u * cs - v * sn, f.y(), f.z() + u * sn + v * cs));
                if (s == null) continue;
                sx[i][j] = s[0]; sy[i][j] = s[1]; sd[i][j] = s[2]; ok[i][j] = true;
            }
        }
        final int region = tex.size() / n;
        final float limit = Predictions.sh * 1.2f;                       // a cell wider than this is a camera-clipping artifact
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (tex.mask().charAt(j * n + i) != '1') continue;
                if (!(ok[i][j] && ok[i + 1][j] && ok[i][j + 1] && ok[i + 1][j + 1])) continue;
                float depth = (sd[i][j] + sd[i + 1][j] + sd[i][j + 1] + sd[i + 1][j + 1]) * 0.25f;
                float near = Math.min(1f, Math.max(0f, (depth - 0.9f) / 1.4f));
                float a = alpha * near;
                if (a < 0.02f) continue;
                float ax = sx[i + 1][j] - sx[i][j], ay = sy[i + 1][j] - sy[i][j], bx = sx[i][j + 1] - sx[i][j], by = sy[i][j + 1] - sy[i][j];
                if (Math.max(Math.max(Math.abs(ax), Math.abs(ay)), Math.max(Math.abs(bx), Math.abs(by))) > limit) continue;
                var m = ctx.getMatrices();
                m.pushMatrix();
                m.translate(sx[i][j], sy[i][j]);
                m.mul(new Matrix3x2f(ax / CELL, ay / CELL, bx / CELL, by / CELL, 0f, 0f));
                ctx.drawTexture(RenderPipelines.GUI_TEXTURED, tex.id(), 0, 0, (float) (i * region), (float) (j * region),
                        CELL + 1, CELL + 1, region, region, tex.size(), tex.size(), argb(a, rgb));   // +1: the cells overlap a little, no hairline gaps
                m.popMatrix();
            }
        }
    }

    /** The "Блоки" look: a ring-shaped wave of light that runs over the top faces of the blocks around the jump. */
    private static void blocks(DrawContext ctx, Fx f, float wave, float fade, int rgb) {
        for (double[] b : f.blocks()) {
            double d = b[3];
            double band = Math.exp(-Math.pow((d - wave) / EDGE, 2.0));          // lit band at the wave front
            double tail = d < wave ? 0.22 * Math.min(1.0, (wave - d) / 1.2) : 0.0;   // a faint glow stays behind it
            float k = (float) Math.min(1.0, Math.max(band, tail)) * fade;
            if (k < 0.03f) continue;
            Vec3d p0 = new Vec3d(b[0], b[1], b[2]);
            float[] s0 = Predictions.project(p0), s1 = Predictions.project(p0.add(1, 0, 0)), s2 = Predictions.project(p0.add(0, 0, 1));
            if (s0 == null || s1 == null || s2 == null) continue;
            k *= Math.min(1f, Math.max(0f, (s0[2] - 0.8f) / 1.2f));                  // blocks next to the camera fade out
            if (k < 0.03f || Math.abs(s1[0] - s0[0]) > Predictions.sh || Math.abs(s2[1] - s0[1]) > Predictions.sh) continue;
            var m = ctx.getMatrices();
            m.pushMatrix();
            m.translate(s0[0], s0[1]);
            m.mul(new Matrix3x2f(s1[0] - s0[0], s1[1] - s0[1], s2[0] - s0[0], s2[1] - s0[1], 0f, 0f));
            ctx.fill(0, 0, 1, 1, argb(0.42f * k, rgb));                           // the face (a unit square in block space)
            m.popMatrix();
            if (k > 0.2f) {                                                      // a thin outline on the brightest ones
                Vec3d p1 = p0.add(1, 0, 0), p2 = p0.add(0, 0, 1), p3 = p0.add(1, 0, 1);
                Predictions.seg(ctx, p0, p1, 0.5f, rgb, 0.8f * k);
                Predictions.seg(ctx, p1, p3, 0.5f, rgb, 0.8f * k);
                Predictions.seg(ctx, p3, p2, 0.5f, rgb, 0.8f * k);
                Predictions.seg(ctx, p2, p0, 0.5f, rgb, 0.8f * k);
            }
        }
    }

    /**
     * The "Ударная волна" look: on landing a ring of glowing block outlines runs out from the feet. Only blocks near the wave front
     * light up (a narrow band), their outline is thick and bright, their top rises a little as the wave passes.
     */
    private static void shock(DrawContext ctx, Fx f, float wave, float fade, int rgb) {
        for (double[] b : f.blocks()) {
            double band = Math.exp(-Math.pow((b[3] - wave) / 0.8, 2.0));
            float k = (float) band * fade;
            if (k < 0.05f) continue;
            Vec3d p0 = new Vec3d(b[0], b[1] + 0.12 * k, b[2]);
            float[] s0 = Predictions.project(p0);
            if (s0 == null) continue;
            k *= Math.min(1f, Math.max(0f, (s0[2] - 0.8f) / 1.2f));
            if (k < 0.04f) continue;
            Vec3d p1 = p0.add(1, 0, 0), p2 = p0.add(0, 0, 1), p3 = p0.add(1, 0, 1);
            float[] s1 = Predictions.project(p1), s2 = Predictions.project(p2);
            if (s1 != null && s2 != null && Math.abs(s1[0] - s0[0]) < Predictions.sh && Math.abs(s2[1] - s0[1]) < Predictions.sh) {
                var m = ctx.getMatrices();
                m.pushMatrix();
                m.translate(s0[0], s0[1]);
                m.mul(new Matrix3x2f(s1[0] - s0[0], s1[1] - s0[1], s2[0] - s0[0], s2[1] - s0[1], 0f, 0f));
                ctx.fill(0, 0, 1, 1, argb(0.16f * k, rgb));                       // a faint tint of the lifted top face
                m.popMatrix();
            }
            float th = Math.max(1.2f, Math.min(5f, 0.10f * Predictions.pxPerBlock(s0[2])));   // the outline is ~0.1 block thick in the world
            Predictions.seg(ctx, p0, p1, th, rgb, k);
            Predictions.seg(ctx, p1, p3, th, rgb, k);
            Predictions.seg(ctx, p3, p2, th, rgb, k);
            Predictions.seg(ctx, p2, p0, th, rgb, k);
        }
    }
}
