package com.shrine;

/**
 * "A background account's packet is being applied right now": the game's globals (world, player, ...) are the background
 * account's own. The mixins in com.shrine.mixin read this to keep what happens to it (sounds, particles, titles, chat, screens)
 * away from the account that is on the screen.
 */
public final class BgCtx {
    private BgCtx() {}

    public static volatile boolean active;
    public static volatile Sess cur;
}
