package com.shrine;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/**
 * Hud > "Scoreboard": the vanilla sidebar scoreboard can be moved and scaled by dragging its frame while chat is open.
 * The vanilla element is wrapped in a matrix transform; its anchor is the right edge, middle of the screen.
 */
final class ScoreboardHud implements HudEditScreen.HudPanel {
    private ScoreboardHud() {}
    static final ScoreboardHud PANEL = new ScoreboardHud();

    static final String KEY = "hud.scoreboard", K_SCALE = "score.scale", K_X = "score.x", K_Y = "score.y";
    // the frame in the editor is a typical sidebar: 110 x 82 px, right edge 1 px from the screen edge, a bit above the middle
    private static final float FW = 110f, FH = 82f, RIGHT_GAP = 1f, ABOVE_MID = 55f;

    static void register() {
        try {
            HudElementRegistry.replaceElement(Identifier.of("minecraft", "scoreboard"), original -> (ctx, tick) -> {
                if (!ShrineCfg.bool(KEY, true)) { original.render(ctx, tick); return; }
                MinecraftClient mc = MinecraftClient.getInstance();
                float k = mc.getWindow().getScaledHeight() / Scene.REF_H;
                float ax = mc.getWindow().getScaledWidth(), ay = mc.getWindow().getScaledHeight() / 2f, s = sc();
                ctx.getMatrices().pushMatrix();
                ctx.getMatrices().translate(posX() * k, posY() * k);
                ctx.getMatrices().translate(ax, ay);
                ctx.getMatrices().scale(s, s);
                ctx.getMatrices().translate(-ax, -ay);
                original.render(ctx, tick);
                ctx.getMatrices().popMatrix();
            });
        } catch (Throwable t) {
            System.err.println("[Shrine] scoreboard element could not be wrapped: " + t);
        }
    }

    static float posX() { return ShrineCfg.num(K_X, 0f); }
    static float posY() { return ShrineCfg.num(K_Y, 0f); }
    static float sc() { return Math.max(0.5f, Math.min(2.5f, ShrineCfg.num(K_SCALE, 1f))); }
    private static float k() { return MinecraftClient.getInstance().getWindow().getScaledHeight() / Scene.REF_H; }

    // ---------- the chat editor ----------
    @Override public String title() { return "Скорборд"; }
    @Override public boolean enabled() { return ShrineCfg.bool(KEY, true); }
    @Override public boolean placeholder() { return true; }
    @Override public float[] bounds(float vw) {
        float k = k(), s = sc();
        return new float[]{vw - (FW + RIGHT_GAP) * s / k + posX(), Scene.REF_H / 2f - ABOVE_MID * s / k + posY(), FW * s / k, FH * s / k};
    }
    @Override public void drawDemo(DrawContext ctx, TextRenderer tr, float vw) {}
    @Override public void place(float vw, float left, float top, float[] b) {
        float k = k(), s = sc();
        ShrineCfg.setNum(K_X, Math.max(-vw, Math.min(vw, left - (vw - (FW + RIGHT_GAP) * s / k))));
        ShrineCfg.setNum(K_Y, Math.max(-Scene.REF_H, Math.min(Scene.REF_H, top - (Scene.REF_H / 2f - ABOVE_MID * s / k))));
    }
    @Override public void reset() { ShrineCfg.setNum(K_X, 0f); ShrineCfg.setNum(K_Y, 0f); ShrineCfg.setNum(K_SCALE, 1f); }
    @Override public float scale() { return sc(); }
    @Override public void setScale(float s) { ShrineCfg.setNum(K_SCALE, s); }
}
