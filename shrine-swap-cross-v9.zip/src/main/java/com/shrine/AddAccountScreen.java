package com.shrine;

import com.shrine.Gfx.Fnt;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

import static com.shrine.Gfx.*;

/**
 * "Добавить пользователя" - the PS5 two-column panel. Left: a licensed (Microsoft) account, with the button "Начинаем".
 * Right: a pirate account by nick ("Войти и играть") or a random nick ("Быстрая игра").
 */
final class AddAccountScreen extends Screen {
    private static final Identifier AVATAR_PLUS = tex("avatar_plus"), I_USER = tex("icon_user");

    private final AccountsScreen back;
    private final Scene scene = new Scene();
    private TextFieldWidget field;
    private float k = 1f, vw = 960f;
    private final long openedAt = Util.getMeasuringTimeMs();

    // Microsoft login state: 0 idle, 1 asking for the code, 2 code shown (waiting), 3 failed
    private volatile int ms;
    private volatile MsLogin.Code code;
    private volatile String error = "";
    private Thread msThread;

    private final float[] rClose = new float[4], rStart = new float[4], rCopyLink = new float[4], rCopyCode = new float[4],
            rCancel = new float[4], rField = new float[4], rPlay = new float[4];

    AddAccountScreen(AccountsScreen back) {
        super(Text.literal("shrine"));
        this.back = back;
    }

    @Override
    protected void init() {
        scene.init(width, height);
        scene.instantBackdrop = true;
        k = height / Scene.REF_H;
        vw = width / k;
        String keep = field == null ? "" : field.getText();
        field = new TextFieldWidget(textRenderer, 0, 0, 200, 20, Text.empty());
        field.setMaxLength(16);
        field.setTextPredicate(s -> s.matches("[A-Za-z0-9_]*"));
        field.setText(keep);
        clearChildren();
        addDrawableChild(field);
        if (ms == 0) { field.setFocused(false); }
    }

    private float alpha() {
        float t = Math.min(1f, (Util.getMeasuringTimeMs() - openedAt) / 260f);
        return 1f - (1f - t) * (1f - t);
    }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        scene.begin(ctx, mxReal, myReal, delta);
        scene.stars(ctx, delta);
        float a = alpha(), mx = scene.mx, my = scene.my;
        ctx.fill(0, 0, Math.round(vw) + 1, Math.round(Scene.REF_H) + 1, argb(0.45f * a, 0x000000));

        float pw = Math.min(vw - 60f, 900f), ph = 492f, px = (vw - pw) / 2f, py = (Scene.REF_H - ph) / 2f + (1f - a) * 16f;
        box(ctx, RR, px - 1, py - 1, pw + 2, ph + 2, 15, argb(0.10f * a, 0xFFFFFF));
        box(ctx, RR, px, py, pw, ph, 14, argb(0.97f * a, 0x23252A));
        text(ctx, textRenderer, Fnt.TITLE, "Добавить пользователя", px + 46f, py + 54f, argb(0.95f * a, 0xFFFFFF));

        float cxs = px + pw - 36f, cys = py + 38f;
        boolean hc = inside(mx, my, cxs - 15, cys - 15, 30, 30);
        centered(ctx, DISC, cxs, cys, 24, 24, argb((hc ? 1f : 0.85f) * a, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.TINY_B, "×", cxs, cys - 0.5f, argb(a, 0x14101A));
        set(rClose, cxs - 15, cys - 15, 30, 30);

        box(ctx, RR, px + pw / 2f - 0.5f, py + 104f, 1f, ph - 134f, 0f, argb(0.12f * a, 0xFFFFFF));

        float colW = pw / 2f - 110f, lx = px + pw * 0.25f, rx = px + pw * 0.75f;
        drawLeft(ctx, lx, py, ph, colW, mx, my, a);
        drawRight(ctx, rx, py, ph, colW, mx, my, a);

        scene.end(ctx);
    }

    private void drawLeft(DrawContext ctx, float cx, float py, float ph, float colW, float mx, float my, float a) {
        clearRects(rStart, rCopyLink, rCopyCode, rCancel);
        AccountsScreen.avatar(ctx, cx - 6f, py + 172f, 78f, AccountsScreen.TINTS[0], a);                                   // the same round Steve avatar
        centered(ctx, AccountsScreen.I_PLUS, cx + 34f, py + 134f, 26f, 26f, argb(a, 0xFFFFFF));            // with a plus
        if (ms == 0 || ms == 3) {
            textC(ctx, textRenderer, Fnt.UI, "Добавить лицензионный аккаунт", cx, py + 240f, argb(a, 0xFFFFFF));
            String body = ms == 3 ? "Не получилось: " + error
                    : "Войдите в аккаунт Microsoft с купленным Minecraft. Игра покажет код, введите его с телефона или компьютера. Аккаунт сохранится на этом устройстве.";
            float y = py + 282f;
            for (String line : wrap(body, Fnt.LABEL, colW)) { textC(ctx, textRenderer, Fnt.LABEL, line, cx, y, argb((ms == 3 ? 0.95f : 0.58f) * a, ms == 3 ? 0xFF8A80 : 0xFFFFFF)); y += 21f; }
            set(rStart, cx - colW / 2f, py + ph - 82f, colW, 46f);
            pill(ctx, rStart, ms == 3 ? "Повторить" : "Начинаем", true, mx, my, a);
        } else {
            textC(ctx, textRenderer, Fnt.UI, "Вход в Microsoft", cx, py + 240f, argb(a, 0xFFFFFF));
            MsLogin.Code c = code;
            if (c == null) {
                textC(ctx, textRenderer, Fnt.LABEL, "Просим у Microsoft код" + dots(), cx, py + 292f, argb(0.6f * a, 0xFFFFFF));
            } else {
                String uri = c.uri().replace("https://", "").replace("http://", "");
                textC(ctx, textRenderer, Fnt.LABEL, "Откройте " + uri + " и введите код", cx, py + 276f, argb(0.6f * a, 0xFFFFFF));
                textC(ctx, textRenderer, Fnt.NAME_B, c.code(), cx, py + 318f, argb(a, 0xFFFFFF));
                textC(ctx, textRenderer, Fnt.SMALL, "Ждём подтверждения" + dots(), cx, py + 352f, argb(0.4f * a, 0xFFFFFF));
                set(rCopyLink, cx - colW / 2f, py + ph - 156f, colW, 40f);
                set(rCopyCode, cx - colW / 2f, py + ph - 108f, colW, 40f);
                pill(ctx, rCopyLink, "Скопировать ссылку", true, mx, my, a);
                pill(ctx, rCopyCode, "Скопировать код", false, mx, my, a);
            }
            set(rCancel, cx - colW / 2f, py + ph - 60f, colW, 36f);
            pill(ctx, rCancel, "Отмена", false, mx, my, a);
        }
    }

    private void drawRight(DrawContext ctx, float cx, float py, float ph, float colW, float mx, float my, float a) {
        centered(ctx, I_USER, cx, py + 168f, 80f, 80f, argb(a, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI, "Играть без лицензии", cx, py + 240f, argb(a, 0xFFFFFF));
        float y = py + 282f;
        for (String line : wrap("Введите любой ник. Подойдёт для серверов без проверки лицензии.", Fnt.LABEL, colW)) {
            textC(ctx, textRenderer, Fnt.LABEL, line, cx, y, argb(0.58f * a, 0xFFFFFF)); y += 21f;
        }
        set(rField, cx - colW / 2f, py + 346f, colW, 42f);
        drawField(ctx, rField, a);
        boolean ok = Accounts.validNick(field.getText());
        set(rPlay, cx - colW / 2f, py + ph - 82f, colW, 46f);
        pill(ctx, rPlay, "Войти и играть", ok, ok ? mx : -1000, my, a, ok ? 1f : 0.45f);
    }

    private void drawField(DrawContext ctx, float[] r, float a) {
        boolean focused = field.isFocused();
        box(ctx, RR, r[0], r[1], r[2], r[3], 20f, argb(0.09f * a, 0xFFFFFF));
        box(ctx, RR_RING, r[0], r[1], r[2], r[3], 20f, argb((focused ? 0.70f : 0.18f) * a, 0xFFFFFF));
        String t = field.getText();
        float cy = r[1] + r[3] / 2f, tx = r[0] + 18f;
        boolean caret = focused && ((int) (scene.time * 2.2f)) % 2 == 0;
        if (t.isEmpty()) {
            if (!focused) text(ctx, textRenderer, Fnt.LABEL, "Ник (3–16 символов)", tx, cy, argb(0.38f * a, 0xFFFFFF));
            else if (caret) ctx.fill(Math.round(tx), Math.round(cy - 9), Math.round(tx) + 2, Math.round(cy + 9), argb(0.9f * a, 0xFFFFFF));
            return;
        }
        text(ctx, textRenderer, Fnt.LABEL, t, tx, cy, argb(a, 0xFFFFFF));
        if (caret) {
            int cur = Math.max(0, Math.min(t.length(), field.getCursor()));
            float cx = tx + width(textRenderer, Fnt.LABEL, t.substring(0, cur));
            ctx.fill(Math.round(cx), Math.round(cy - 9), Math.round(cx) + 2, Math.round(cy + 9), argb(0.95f * a, 0xFFFFFF));
        }
    }

    private void pill(DrawContext ctx, float[] r, String label, boolean primary, float mx, float my, float a) {
        pill(ctx, r, label, primary, mx, my, a, 1f);
    }

    private void pill(DrawContext ctx, float[] r, String label, boolean primary, float mx, float my, float a, float strength) {
        boolean hv = inside(mx, my, r[0], r[1], r[2], r[3]);
        float rad = r[3] / 2f;
        if (primary && (hv || strength >= 1f)) box(ctx, RR_RING, r[0] - 4, r[1] - 4, r[2] + 8, r[3] + 8, rad + 4, argb((hv ? 0.75f : 0.45f) * a * strength, 0xFFFFFF));
        if (primary) box(ctx, RR, r[0], r[1], r[2], r[3], rad, argb(0.97f * a * strength, 0xFFFFFF));
        else box(ctx, RR, r[0], r[1], r[2], r[3], rad, argb((hv ? 0.30f : 0.20f) * a * strength, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI_B, label, r[0] + r[2] / 2f, r[1] + r[3] / 2f, argb(a * Math.max(0.6f, strength), primary ? 0x14101A : 0xFFFFFF));
    }

    private String dots() { return ".".repeat(1 + (int) (scene.time * 2.5f) % 3); }

    private List<String> wrap(String s, Fnt f, float maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : s.split(" ")) {
            String t = cur.length() == 0 ? w : cur + " " + w;
            if (width(textRenderer, f, t) > maxW && cur.length() > 0) { out.add(cur.toString()); cur = new StringBuilder(w); }
            else cur = new StringBuilder(t);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    private static void set(float[] r, float x, float y, float w, float h) { r[0] = x; r[1] = y; r[2] = w; r[3] = h; }
    private static void clearRects(float[]... rs) { for (float[] r : rs) r[2] = 0; }
    private static boolean hit(float[] r, double mx, double my) { return r[2] > 0 && inside(mx, my, r[0], r[1], r[2], r[3]); }

    // ---------- actions ----------
    private void startMicrosoft() {
        ms = 1; code = null; error = "";
        Thread t = new Thread(() -> {
            try {
                MsLogin.Result r = MsLogin.loginInteractive(c -> code = c);
                client.execute(() -> {
                    Accounts.Acc acc = Accounts.addLicensed(r.name(), r.uuid(), r.refresh());
                    ms = 0;
                    client.setScreen(back);
                    back.useAccount(acc);
                });
            } catch (InterruptedException e) {
                // cancelled
            } catch (Throwable e) {
                String msg = Accounts.describe(e);
                client.execute(() -> { ms = 3; error = msg; });
            }
        }, "shrine-ms-login");
        t.setDaemon(true);
        msThread = t;
        t.start();
    }

    private void cancelMicrosoft() {
        if (msThread != null) msThread.interrupt();
        msThread = null; ms = 0; code = null;
    }

    private void playPirate(String nick) {
        if (!Accounts.validNick(nick)) return;
        Accounts.Acc acc = Accounts.addPirate(nick);
        client.setScreen(back);
        back.useAccount(acc);
    }

    private void copy(String s) { if (s != null) client.keyboard.setClipboard(s); }

    @Override
    public void removed() { cancelMicrosoft(); }

    @Override
    public void close() { cancelMicrosoft(); client.setScreen(back); }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return true;
        double mx = click.x() / k, my = click.y() / k;
        if (hit(rClose, mx, my)) { close(); return true; }
        if (hit(rStart, mx, my)) { startMicrosoft(); return true; }
        if (hit(rCopyLink, mx, my)) { if (code != null) copy(code.directUri()); return true; }
        if (hit(rCopyCode, mx, my)) { if (code != null) copy(code.code()); return true; }
        if (hit(rCancel, mx, my)) { cancelMicrosoft(); return true; }
        if (hit(rField, mx, my)) { field.setFocused(true); setFocused(field); return true; }
        if (hit(rPlay, mx, my)) { playPirate(field.getText()); return true; }
        field.setFocused(false);
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) && field.isFocused()) { playPirate(field.getText()); return true; }
        return super.keyPressed(input);
    }

    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean shouldPause() { return false; }
}
