package com.shrine;

import com.shrine.Gfx.Fnt;
import com.shrine.mixin.HandledScreenAccessor;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.Slot;

import java.util.List;

import static com.shrine.Gfx.*;

/**
 * Hud > "Shulker Preview": point at a shulker box in an inventory / chest screen and a glass panel with everything inside
 * (3 rows of 9) appears left of the tooltip. The panel takes the color of the shulker.
 */
final class ShulkerPreview {
    private ShulkerPreview() {}

    static final String KEY = "hud.shulker", K_TINT = "shulker.tint", K_SCALE = "shulker.scale", K_TITLE = "shulker.title";
    private static final float PAD = 8f, CELL = 24f, GAP = 2f, CHIP_H = 20f;
    private static final int COLS = 9, ROWS = 3;
    private static final float W = PAD * 2 + COLS * CELL + (COLS - 1) * GAP, H = PAD * 2 + ROWS * CELL + (ROWS - 1) * GAP;
    private static final int PURPLE = 0x956A95;   // an undyed shulker box

    static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof HandledScreen<?>) ScreenEvents.afterRender(screen).register(ShulkerPreview::draw);
        });
    }

    /** Dye color of a shulker box item, from its id ("light_gray_shulker_box" -> light gray). */
    private static int dyeColor(String path) {
        String c = path.endsWith("_shulker_box") ? path.substring(0, path.length() - "_shulker_box".length()) : "";
        return switch (c) {
            case "white" -> 0xF9FFFE; case "orange" -> 0xF9801D; case "magenta" -> 0xC74EBD; case "light_blue" -> 0x3AB3DA;
            case "yellow" -> 0xFED83D; case "lime" -> 0x80C71F; case "pink" -> 0xF38BAA; case "gray" -> 0x7A8488;
            case "light_gray" -> 0x9D9D97; case "cyan" -> 0x169C9C; case "purple" -> 0x8932B8; case "blue" -> 0x3C44AA;
            case "brown" -> 0x835432; case "green" -> 0x5E7C16; case "red" -> 0xB02E26; case "black" -> 0x5A5A66;
            default -> PURPLE;
        };
    }

    private static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static void draw(Screen screen, DrawContext ctx, int mx, int my, float delta) {
        if (!ShrineCfg.bool(KEY, false) || !(screen instanceof HandledScreen<?> hs)) return;
        if (!hs.getScreenHandler().getCursorStack().isEmpty()) return;      // vanilla shows no tooltip while you carry something
        Slot slot = ((HandledScreenAccessor) hs).shrine$focusedSlot();
        if (slot == null || !slot.hasStack()) return;
        ItemStack box = slot.getStack();
        String path = Registries.ITEM.getId(box.getItem()).getPath();
        if (!path.endsWith("shulker_box")) return;
        ContainerComponent cc = box.get(DataComponentTypes.CONTAINER);
        if (cc == null) return;
        List<ItemStack> inside = cc.stream().toList();
        boolean any = false;
        for (ItemStack s : inside) if (!s.isEmpty()) { any = true; break; }
        if (!any) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        float k = sh / Scene.REF_H;
        float sc = Math.max(0.6f, Math.min(2f, ShrineCfg.num(K_SCALE, 1f)));
        boolean title = ShrineCfg.bool(K_TITLE, true);
        float pw = W * sc, ph = H * sc, top = title ? (CHIP_H + 3f) * sc : 0f;
        // right edge of the panel sits at the vanilla tooltip (it starts ~12 px right of the mouse)
        float px = (mx + 6) / k - pw, py = (my - 12) / k + top;
        px = Math.max(4f / k, Math.min(px, sw / k - pw - 4f / k));
        py = Math.max(4f / k + top, Math.min(py, (sh - 4f) / k - ph));

        int col = ShrineCfg.bool(K_TINT, true) ? dyeColor(path) : 0xA8A8BC;
        float glass = 0.92f;

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        ctx.getMatrices().translate(px, py);
        ctx.getMatrices().scale(sc, sc);
        panel(ctx, tr, inside, col, glass);
        if (title) chip(ctx, tr, box, col, glass);
        ctx.getMatrices().popMatrix();
    }

    private static void glassBody(DrawContext ctx, float x, float y, float w, float h, float r, int col, float glass) {
        box(ctx, RR, x - 3f, y - 3f, w + 6f, h + 6f, r + 3f, argb(0.10f, col));                       // soft halo in the shulker color
        box(ctx, RR, x, y, w, h, r, argb(glass, mix(0x0B0B10, col, 0.18f)));                         // translucent body
        box(ctx, RR, x + 1f, y + 1f, w - 2f, h * 0.45f, Math.max(2f, r - 1f), argb(0.07f, 0xFFFFFF)); // glass sheen on the upper half
        box(ctx, RR_RING, x, y, w, h, r, argb(0.60f, mix(col, 0xFFFFFF, 0.25f)));                     // thin bright edge
    }

    private static void panel(DrawContext ctx, TextRenderer tr, List<ItemStack> st, int col, float glass) {
        glassBody(ctx, 0f, 0f, W, H, 14f, col, glass);
        for (int i = 0; i < COLS * ROWS; i++) {
            float sx = PAD + (i % COLS) * (CELL + GAP), sy = PAD + (i / COLS) * (CELL + GAP);
            ItemStack s = i < st.size() ? st.get(i) : ItemStack.EMPTY;
            box(ctx, RR, sx, sy, CELL, CELL, 6, s.isEmpty() ? argb(0.05f, 0xFFFFFF) : argb(0.13f, mix(col, 0xFFFFFF, 0.35f)));
            if (s.isEmpty()) continue;
            float is = 1.08f;
            ctx.getMatrices().pushMatrix();
            ctx.getMatrices().translate(sx + (CELL - 16f * is) / 2f, sy + (CELL - 16f * is) / 2f - 1f);
            ctx.getMatrices().scale(is, is);
            ctx.drawItem(s, 0, 0);
            ctx.getMatrices().popMatrix();
            if (s.isItemBarVisible()) {
                float bw = CELL - 10f, fw = Math.max(2f, bw * s.getItemBarStep() / 13f);
                box(ctx, RR, sx + 5, sy + CELL - 5, bw, 2, 1, argb(0.7f, 0x000000));
                box(ctx, RR, sx + 5, sy + CELL - 5, fw, 2, 1, argb(1f, s.getItemBarColor()));
            }
            if (s.getCount() > 1) {
                String n = String.valueOf(s.getCount());
                float tx = sx + CELL - 3f - width(tr, Fnt.TINY_B, n);
                text(ctx, tr, Fnt.TINY_B, n, tx + 1f, sy + CELL - 6f + 1f, argb(0.9f, 0x000000));
                text(ctx, tr, Fnt.TINY_B, n, tx, sy + CELL - 6f, argb(1f, 0xFFFFFF));
            }
        }
    }

    /** The name of the box in a small glass pill above the panel, with the box itself as an icon. */
    private static void chip(DrawContext ctx, TextRenderer tr, ItemStack box, int col, float glass) {
        String name = box.getName().getString();
        float w = Math.min(W, 14f + 16f + width(tr, Fnt.SMALL, name) + 12f);
        float y = -CHIP_H - 3f;
        glassBody(ctx, 0f, y, w, CHIP_H, 10f, col, glass);
        float is = 0.8f;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(7f, y + (CHIP_H - 16f * is) / 2f);
        ctx.getMatrices().scale(is, is);
        ctx.drawItem(box, 0, 0);
        ctx.getMatrices().popMatrix();
        text(ctx, tr, Fnt.SMALL, name, 7f + 16f * is + 6f, y + CHIP_H / 2f, argb(1f, 0xFFFFFF));
    }
}
