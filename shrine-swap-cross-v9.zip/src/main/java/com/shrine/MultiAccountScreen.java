package com.shrine;

import com.shrine.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.shrine.Gfx.*;

/**
 * Account > Multi Account menu. Left: nick field (Enter adds an account), the account list with live states, "Connect all" /
 * "Stop all". Right: the card of the selected account (health, food, ping, world, mode) with Chat / Play as / Disconnect, and
 * the chat view of that account (send as this one or as everyone).
 */
final class MultiAccountScreen extends Screen {
    private static final float PW = 800f, PH = 480f, ROW_H = 58f, LEFT_W = 300f;
    private static final int ROWS = 4;
    private static final int GREEN = 0x3DDC84, GREEN_T = 0x7BF0B0, YELLOW = 0xFFD166, RED = 0xFF6A5A;

    private final List<Accounts.Acc> accs = new ArrayList<>();
    private TextFieldWidget nick, chatIn;
    private int sel, first;
    private boolean chatView, toAll, confirmDel;
    private String status = "";
    private float k = 1f, vw = 960f;
    private final long openedAt = Util.getMeasuringTimeMs();
    private final float[] rNick = new float[4], rClose = new float[4], rAll = new float[4], rStop = new float[4], rBack = new float[4],
            rTarget = new float[4], rChat = new float[4], rBtn = new float[12], rRows = new float[ROWS * 4];
    private final boolean[] btnOn = new boolean[3];
    private int kind;

    MultiAccountScreen() { super(Text.literal("shrine")); }

    @Override
    protected void init() {
        Accounts.init();
        k = height / Scene.REF_H;
        vw = width / k;
        String keepNick = nick == null ? "" : nick.getText(), keepChat = chatIn == null ? "" : chatIn.getText();
        nick = new TextFieldWidget(textRenderer, 0, 0, 200, 20, Text.empty());
        nick.setMaxLength(16);
        nick.setTextPredicate(s -> s.matches("[A-Za-z0-9_]*"));
        nick.setText(keepNick);
        chatIn = new TextFieldWidget(textRenderer, 0, 0, 200, 20, Text.empty());
        chatIn.setMaxLength(256);
        chatIn.setText(keepChat);
        clearChildren();
        addDrawableChild(nick);
        addDrawableChild(chatIn);
        nick.setFocused(false);
        chatIn.setFocused(false);
        reload();
        for (int i = 0; i < accs.size(); i++) if (MultiAccount.isMain(accs.get(i))) sel = i;
        fit();
    }

    private void reload() {
        accs.clear();
        accs.addAll(Accounts.LIST);
        sel = Math.max(0, Math.min(sel, accs.size() - 1));
        confirmDel = false;
    }

    private void fit() {
        if (sel < first) first = sel;
        if (sel >= first + ROWS) first = sel - ROWS + 1;
        first = Math.max(0, Math.min(first, Math.max(0, accs.size() - ROWS)));
    }

    private Accounts.Acc selected() { return sel >= 0 && sel < accs.size() ? accs.get(sel) : null; }

    // ---------- small data helpers ----------
    private float hpOf(Accounts.Acc a) {
        if (MultiAccount.isMain(a)) return client.player == null ? -1f : client.player.getHealth();
        Bg b = MultiAccount.bot(a);
        return b != null && b.online() ? b.health : -1f;
    }

    private int foodOf(Accounts.Acc a) {
        if (MultiAccount.isMain(a)) return client.player == null ? -1 : client.player.getHungerManager().getFoodLevel();
        Bg b = MultiAccount.bot(a);
        return b != null && b.online() ? b.food : -1;
    }

    private int pingOf(Accounts.Acc a) {
        if (MultiAccount.isMain(a)) {
            if (client.player == null || client.getNetworkHandler() == null) return -1;
            PlayerListEntry e = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
            return e == null ? -1 : e.getLatency();
        }
        Bg b = MultiAccount.bot(a);
        return b != null && b.online() ? b.pingMs : -1;
    }

    private String worldOf(Accounts.Acc a) {
        if (MultiAccount.isMain(a)) return client.world == null ? "—" : BotConn.dimName(client.world.getRegistryKey());
        Bg b = MultiAccount.bot(a);
        return b != null && b.online() && !b.world.isEmpty() ? b.world : "—";
    }

    private String modeOf(Accounts.Acc a) {
        if (MultiAccount.isMain(a)) {
            if (client.interactionManager == null) return "—";
            return client.interactionManager.getCurrentGameMode().name().toLowerCase(Locale.ROOT);
        }
        Bg b = MultiAccount.bot(a);
        return b != null && b.online() && !b.mode.isEmpty() ? b.mode : "—";
    }

    private String protocol() {
        try {
            if (!Via.available()) return "Native";
            ServerInfo si = client.getCurrentServerEntry();
            Object v = si == null ? null : Via.forced(si);
            if (v == null) v = Via.global();
            String n = Via.nameOf(v);
            return n.isEmpty() ? "Native" : n;
        } catch (Throwable t) {
            return "Native";
        }
    }

    private String stateText(Accounts.Acc a) {
        if (MultiAccount.isMain(a)) return "Основной";
        Bg b = MultiAccount.bot(a);
        if (b == null) return "Не в игре";
        return switch (b.state) {
            case ONLINE -> "Online";
            case CONNECTING -> "Вход…";
            case FAILED -> "Ошибка";
            default -> "Не в игре";
        };
    }

    private int stateColor(Accounts.Acc a) {
        if (MultiAccount.isMain(a)) return GREEN;
        Bg b = MultiAccount.bot(a);
        if (b == null) return 0xFFFFFF;
        return switch (b.state) {
            case ONLINE -> GREEN;
            case CONNECTING -> YELLOW;
            case FAILED -> RED;
            default -> 0xFFFFFF;
        };
    }

    private String subtitle(Accounts.Acc a) {
        float hp = hpOf(a);
        if (hp >= 0f) {
            int ping = pingOf(a);
            return Math.round(hp) + " hp" + (ping >= 0 ? " · " + ping + " ms" : "");
        }
        return a.label();
    }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        long now = Util.getMeasuringTimeMs();
        float t = Math.min(1f, (now - openedAt) / 220f), a = 1f - (1f - t) * (1f - t), time = (now - openedAt) / 1000f;
        ctx.fill(0, 0, width, height, argb(0.55f * a, 0x000000));
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        float mx = mxReal / k, my = myReal / k;
        float x = vw / 2f - PW / 2f, y = Scene.REF_H / 2f - PH / 2f + (1f - a) * 14f;

        box(ctx, RR, x - 1, y - 1, PW + 2, PH + 2, 25f, argb(0.14f * a, 0xFFFFFF));
        box(ctx, RR, x, y, PW, PH, 24f, argb(0.97f * a, 0x16171B));

        set(rClose, x + PW - 54, y + 22, 32, 32);
        boolean hc = inside(mx, my, rClose[0], rClose[1], rClose[2], rClose[3]);
        box(ctx, RR, rClose[0], rClose[1], 32, 32, 16f, argb((hc ? 0.22f : 0.10f) * a, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI, "×", rClose[0] + 16, rClose[1] + 15, argb(a, 0xFFFFFF));

        drawLeft(ctx, x + 20, y, mx, my, time, a);
        float dx = x + 20 + LEFT_W + 20;
        box(ctx, RR, dx - 10, y + 20, 1.5f, PH - 40, 0.75f, argb(0.10f * a, 0xFFFFFF));
        if (chatView && selected() != null) drawChat(ctx, dx, y, PW - (dx - x) - 20, mx, my, time, a);
        else drawCard(ctx, dx, y, PW - (dx - x) - 20, mx, my, a);

        if (!status.isEmpty()) textC(ctx, textRenderer, Fnt.SMALL, status, x + PW / 2f, y + PH - 12, argb(a, 0xFF8A80));
        ctx.getMatrices().popMatrix();
    }

    private static void set(float[] r, float x, float y, float w, float h) { set(r, 0, x, y, w, h); }
    private static void set(float[] r, int i, float x, float y, float w, float h) { int o = i * 4; r[o] = x; r[o + 1] = y; r[o + 2] = w; r[o + 3] = h; }

    private void drawLeft(DrawContext ctx, float x, float y, float mx, float my, float time, float a) {
        box(ctx, RR, x, y + 22, 44, 44, 14f, argb(0.12f * a, 0xFFFFFF));
        centered(ctx, DISC, x + 22, y + 38, 9f, 9f, argb(0.9f * a, 0xFFFFFF));
        centered(ctx, RING, x + 22, y + 52, 22f, 14f, argb(0.9f * a, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.UI_B, "Multi Account", x + 58, y + 36, argb(a, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.SMALL, "Misc · несколько аккаунтов", x + 58, y + 56, argb(0.5f * a, 0xFFFFFF));

        set(rNick, x, y + 84, LEFT_W, 42);
        drawField(ctx, nick, rNick, "Ник нового аккаунта", time, a);

        float ly = y + 142;
        for (int i = 0; i < ROWS * 4; i++) rRows[i] = 0;
        if (accs.isEmpty()) {
            textC(ctx, textRenderer, Fnt.LABEL, "Пока нет аккаунтов", x + LEFT_W / 2f, ly + 80, argb(0.55f * a, 0xFFFFFF));
            textC(ctx, textRenderer, Fnt.SMALL, "Впиши ник и нажми Enter", x + LEFT_W / 2f, ly + 104, argb(0.35f * a, 0xFFFFFF));
        }
        for (int r = 0; r < ROWS; r++) {
            int idx = first + r;
            if (idx >= accs.size()) break;
            Accounts.Acc acc = accs.get(idx);
            float ry = ly + r * ROW_H, rw = LEFT_W;
            set(rRows, r, x, ry, rw, 52f);
            boolean hv = inside(mx, my, x, ry, rw, 52f);
            if (idx == sel) {
                box(ctx, RR, x, ry, rw, 52f, 16f, argb(0.13f * a, 0xFFFFFF));
                box(ctx, RR_RING, x, ry, rw, 52f, 16f, argb(0.55f * a, 0xFFFFFF));
            } else if (hv) {
                box(ctx, RR, x, ry, rw, 52f, 16f, argb(0.06f * a, 0xFFFFFF));
            }
            AccountsScreen.avatar(ctx, x + 28, ry + 26, 36f, AccountsScreen.TINTS[Math.abs(acc.id.hashCode()) % AccountsScreen.TINTS.length], a);
            text(ctx, textRenderer, Fnt.UI_B, acc.name, x + 56, ry + 18, argb(a, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, subtitle(acc), x + 56, ry + 37, argb(0.45f * a, 0xFFFFFF));
            drawPill(ctx, x + rw - 10, ry + 15, stateText(acc), stateColor(acc), a);
        }
        if (accs.size() > ROWS) {
            textC(ctx, textRenderer, Fnt.SMALL, (first + 1) + "–" + Math.min(accs.size(), first + ROWS) + " из " + accs.size() + "   ▲ ▼",
                    x + LEFT_W / 2f, ly + ROWS * ROW_H + 4, argb(0.35f * a, 0xFFFFFF));
        }

        float by = y + PH - 74, bw = (LEFT_W - 12) / 2f;
        set(rAll, x, by, bw, 46);
        set(rStop, x + bw + 12, by, bw, 46);
        boolean canAll = client.getCurrentServerEntry() != null;
        boolean hA = canAll && inside(mx, my, rAll[0], rAll[1], bw, 46);
        box(ctx, RR, rAll[0], rAll[1], bw, 46, 23f, argb(((canAll ? (hA ? 1f : 0.93f) : 0.10f)) * a, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI_B, "Connect all", rAll[0] + bw / 2f, rAll[1] + 22, argb((canAll ? 1f : 0.35f) * a, canAll ? 0x14101A : 0xFFFFFF));
        boolean hS = inside(mx, my, rStop[0], rStop[1], bw, 46);
        box(ctx, RR, rStop[0], rStop[1], bw, 46, 23f, argb((hS ? 0.28f : 0.12f) * a, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI, "Stop all", rStop[0] + bw / 2f, rStop[1] + 22, argb(a, 0xFFFFFF));
    }

    /** A status pill whose right edge is at {@code right}. */
    private void drawPill(DrawContext ctx, float right, float py, String s, int color, float a) {
        float pw = width(textRenderer, Fnt.SMALL, s) + 22f, px = right - pw;
        boolean live = color != 0xFFFFFF;
        box(ctx, RR, px, py, pw, 22f, 11f, argb((live ? 0.22f : 0.10f) * a, color));
        textC(ctx, textRenderer, Fnt.SMALL, s, px + pw / 2f, py + 10, argb((live ? 1f : 0.55f) * a, color == GREEN ? GREEN_T : color));
    }

    private void drawField(DrawContext ctx, TextFieldWidget f, float[] r, String hint, float time, float a) {
        boolean focused = f.isFocused();
        box(ctx, RR, r[0], r[1], r[2], r[3], 20f, argb(0.09f * a, 0xFFFFFF));
        box(ctx, RR_RING, r[0], r[1], r[2], r[3], 20f, argb((focused ? 0.70f : 0.18f) * a, 0xFFFFFF));
        String t = f.getText();
        float cy = r[1] + r[3] / 2f, tx = r[0] + 18f, maxW = r[2] - 36f;
        boolean caret = focused && ((int) (time * 2.2f)) % 2 == 0;
        if (t.isEmpty()) {
            if (!focused) text(ctx, textRenderer, Fnt.LABEL, hint, tx, cy, argb(0.38f * a, 0xFFFFFF));
            else if (caret) ctx.fill(Math.round(tx), Math.round(cy - 9), Math.round(tx) + 2, Math.round(cy + 9), argb(0.9f * a, 0xFFFFFF));
            return;
        }
        int cur = Math.max(0, Math.min(t.length(), f.getCursor()));
        String shown = t;
        int skip = 0;
        while (width(textRenderer, Fnt.LABEL, shown) > maxW && skip < cur) { skip++; shown = t.substring(skip); }   // keep the caret in view
        text(ctx, textRenderer, Fnt.LABEL, shown, tx, cy, argb(a, 0xFFFFFF));
        if (caret) {
            float cx = tx + width(textRenderer, Fnt.LABEL, t.substring(skip, cur));
            ctx.fill(Math.round(cx), Math.round(cy - 9), Math.round(cx) + 2, Math.round(cy + 9), argb(0.95f * a, 0xFFFFFF));
        }
    }

    /** The card: name, state, two bars like on the video, info tiles and the three buttons. */
    private void drawCard(DrawContext ctx, float x, float y, float w, float mx, float my, float a) {
        Accounts.Acc s = selected();
        if (s == null) {
            textC(ctx, textRenderer, Fnt.LABEL, "Выбери аккаунт слева", x + w / 2f, y + PH / 2f, argb(0.4f * a, 0xFFFFFF));
            return;
        }
        Bg b = MultiAccount.bot(s);
        boolean main = MultiAccount.isMain(s);
        text(ctx, textRenderer, Fnt.UI_B, s.name, x, y + 36, argb(a, 0xFFFFFF));
        drawPill(ctx, x + w - 64, y + 25, stateText(s), stateColor(s), a);

        // the "view" panel
        float py = y + 78, ph = 150f;
        box(ctx, RR, x, py, w, ph, 18f, argb(0.07f * a, 0xFFFFFF));
        box(ctx, RR_RING, x, py, w, ph, 18f, argb(0.30f * a, 0xFFFFFF));
        AccountsScreen.avatar(ctx, x + w / 2f, py + 52, 64f, AccountsScreen.TINTS[Math.abs(s.id.hashCode()) % AccountsScreen.TINTS.length], a);
        float hp = hpOf(s);
        int food = foodOf(s);
        boolean live = hp >= 0f;
        textC(ctx, textRenderer, Fnt.SMALL, live ? "" : (b != null && b.state == Bg.State.FAILED ? "" : "нет данных: аккаунт не на сервере"),
                x + w / 2f, py + 102, argb(0.4f * a, 0xFFFFFF));
        float bx = x + 18, bw = w - 36;
        bar(ctx, bx, py + ph - 38, bw, live ? hp / 20f : 0f, 0xE5484D, live ? String.valueOf(Math.round(hp)) : "—", a);
        bar(ctx, bx, py + ph - 20, bw, food >= 0 ? food / 20f : 0f, 0xF2A33A, food >= 0 ? String.valueOf(food) : "—", a);

        // info tiles
        float ty = py + ph + 14, tw = (w - 12) / 2f, th = 50f;
        int ping = pingOf(s);
        tile(ctx, x, ty, tw, th, "Ping", ping >= 0 ? ping + " ms" : "—", a);
        tile(ctx, x + tw + 12, ty, tw, th, "Protocol", protocol(), a);
        tile(ctx, x, ty + th + 10, tw, th, "World", worldOf(s), a);
        tile(ctx, x + tw + 12, ty + th + 10, tw, th, "Mode", modeOf(s), a);

        // buttons
        String[] label = new String[3];
        if (main) {
            kind = 0; label[0] = "Chat"; btnOn[0] = true; btnOn[1] = false; btnOn[2] = false; label[1] = "Play as"; label[2] = "Disconnect";
        } else if (b != null && b.state == Bg.State.ONLINE) {
            kind = 1; label[0] = "Chat"; label[1] = "Play as"; label[2] = "Disconnect"; btnOn[0] = btnOn[1] = btnOn[2] = true;
        } else if (b != null && b.state == Bg.State.CONNECTING) {
            kind = 2; label[0] = "Chat"; label[1] = "Play as"; label[2] = "Cancel"; btnOn[0] = false; btnOn[1] = false; btnOn[2] = true;
        } else {
            kind = 3; label[0] = "Connect"; label[1] = "Play as"; label[2] = confirmDel ? "Точно?" : "Удалить";
            btnOn[0] = client.getCurrentServerEntry() != null; btnOn[1] = client.getCurrentServerEntry() != null; btnOn[2] = true;
        }
        float by = y + PH - 74, bw3 = (w - 24) / 3f;
        for (int i = 0; i < 3; i++) {
            float bxi = x + i * (bw3 + 12);
            set(rBtn, i, bxi, by, bw3, 46);
            boolean on = btnOn[i], hv = on && inside(mx, my, bxi, by, bw3, 46);
            boolean primary = i == 1 && on;
            int fill = primary ? 0xFFFFFF : (i == 2 && label[2].equals("Точно?") ? RED : 0xFFFFFF);
            box(ctx, RR, bxi, by, bw3, 46, 23f, argb((primary ? (hv ? 1f : 0.93f) : (on ? (hv ? 0.28f : 0.12f) : 0.06f)) * a, fill));
            textC(ctx, textRenderer, Fnt.UI, label[i], bxi + bw3 / 2f, by + 22, argb((on ? 1f : 0.3f) * a, primary ? 0x14101A : 0xFFFFFF));
        }
        if (b != null && b.state == Bg.State.FAILED && !b.error.isEmpty()) {
            String e = b.error;
            while (e.length() > 4 && width(textRenderer, Fnt.SMALL, e) > w) e = e.substring(0, e.length() - 2);
            textC(ctx, textRenderer, Fnt.SMALL, e.equals(b.error) ? e : e + "…", x + w / 2f, by - 14, argb(0.9f * a, RED));
        }
    }

    private void bar(DrawContext ctx, float x, float y, float w, float frac, int color, String value, float a) {
        box(ctx, RR, x, y, w, 8f, 4f, argb(0.16f * a, 0xFFFFFF));
        float fw = Math.max(0f, Math.min(1f, frac)) * w;
        if (fw > 8f) box(ctx, RR, x, y, fw, 8f, 4f, argb(a, color));
        textC(ctx, textRenderer, Fnt.SMALL, value, x + w + 14, y + 4, argb(0.8f * a, 0xFFFFFF));
    }

    private void tile(DrawContext ctx, float x, float y, float w, float h, String label, String value, float a) {
        box(ctx, RR, x, y, w, h, 14f, argb(0.06f * a, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.SMALL, label, x + 14, y + 15, argb(0.45f * a, 0xFFFFFF));
        String v = value;
        while (v.length() > 3 && width(textRenderer, Fnt.UI, v) > w - 28) v = v.substring(0, v.length() - 2) + "…";
        text(ctx, textRenderer, Fnt.UI, v, x + 14, y + 34, argb(a, 0xFFFFFF));
    }

    /** The chat of the selected account: its log, an input and the "only this / everyone" switch. */
    private void drawChat(DrawContext ctx, float x, float y, float w, float mx, float my, float time, float a) {
        Accounts.Acc s = selected();
        Bg b = MultiAccount.bot(s);
        boolean main = MultiAccount.isMain(s);

        set(rBack, x, y + 22, 90, 34);
        boolean hb = inside(mx, my, rBack[0], rBack[1], rBack[2], rBack[3]);
        box(ctx, RR, rBack[0], rBack[1], 90, 34, 17f, argb((hb ? 0.22f : 0.10f) * a, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI, "‹ Назад", rBack[0] + 45, rBack[1] + 16, argb(a, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.UI_B, "Chat", x + 106, y + 34, argb(a, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.SMALL, s.name, x + 106 + width(textRenderer, Fnt.UI_B, "Chat") + 12, y + 36, argb(0.5f * a, 0xFFFFFF));

        float ly = y + 74, lh = PH - 74 - 90;
        box(ctx, RR, x, ly, w, lh, 18f, argb(0.06f * a, 0xFFFFFF));
        List<String> lines = new ArrayList<>();
        if (b != null) synchronized (b.chat) { lines.addAll(b.chat); }
        if (main) {
            textC(ctx, textRenderer, Fnt.SMALL, "Это основной аккаунт: его чат — в самой игре.", x + w / 2f, ly + lh / 2f, argb(0.4f * a, 0xFFFFFF));
        } else if (lines.isEmpty()) {
            textC(ctx, textRenderer, Fnt.SMALL, "Сообщений пока нет", x + w / 2f, ly + lh / 2f, argb(0.4f * a, 0xFFFFFF));
        }
        int maxLines = (int) ((lh - 20f) / 20f);
        int from = Math.max(0, lines.size() - maxLines);
        float cy = ly + 18f;
        for (int i = from; i < lines.size(); i++) {
            String line = lines.get(i);
            while (line.length() > 4 && width(textRenderer, Fnt.SMALL, line) > w - 28) line = line.substring(0, line.length() - 2);
            if (!line.equals(lines.get(i))) line += "…";
            text(ctx, textRenderer, Fnt.SMALL, line, x + 14, cy, argb(0.85f * a, 0xFFFFFF));
            cy += 20f;
        }

        float iy = y + PH - 74;
        float tw = 110f;
        set(rChat, x, iy, w - tw - 10, 46);
        drawField(ctx, chatIn, rChat, "Сообщение от " + s.name, time, a);
        set(rTarget, x + w - tw, iy, tw, 46);
        boolean ht = inside(mx, my, rTarget[0], rTarget[1], tw, 46);
        box(ctx, RR, rTarget[0], rTarget[1], tw, 46, 23f, argb((ht ? 0.28f : 0.12f) * a, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI, toAll ? "Everyone" : "Only this", rTarget[0] + tw / 2f, rTarget[1] + 22, argb(a, 0xFFFFFF));
    }

    // ---------- actions ----------
    private void addNick() {
        String n = nick.getText();
        if (!Accounts.validNick(n)) { status = "Ник: 3–16 символов, латиница, цифры и _"; return; }
        Accounts.Acc acc = Accounts.addPirate(n);
        nick.setText("");
        status = "";
        reload();
        for (int i = 0; i < accs.size(); i++) if (accs.get(i).id.equals(acc.id)) sel = i;
        fit();
    }

    private void button(int i) {
        Accounts.Acc s = selected();
        if (s == null || !btnOn[i]) return;
        switch (kind) {
            case 0 -> { if (i == 0) openChat(); }
            case 1 -> {
                if (i == 0) openChat();
                else if (i == 1) { client.setScreen(null); MultiAccount.playAs(client, s); }
                else MultiAccount.stopBot(s);
            }
            case 2 -> { if (i == 2) MultiAccount.stopBot(s); }
            default -> {
                if (i == 0) MultiAccount.connectBot(client, s);
                else if (i == 1) { client.setScreen(null); MultiAccount.playAs(client, s); }
                else if (!confirmDel) confirmDel = true;
                else { MultiAccount.stopBot(s); Accounts.remove(s); reload(); fit(); }
            }
        }
    }

    private void openChat() {
        chatView = true;
        nick.setFocused(false);
    }

    private void sendChat() {
        Accounts.Acc s = selected();
        String text = chatIn.getText();
        if (s == null || text.isBlank()) return;
        if (toAll) MultiAccount.chatEveryone(client, text);
        else if (MultiAccount.isMain(s)) MultiAccount.sendMain(client, text);
        else {
            Bg b = MultiAccount.bot(s);
            if (b == null || !b.sendChat(text)) { status = "Аккаунт не на сервере"; return; }
        }
        chatIn.setText("");
        status = "";
    }

    private void focus(TextFieldWidget f) {
        nick.setFocused(f == nick);
        chatIn.setFocused(f == chatIn);
        setFocused(f);
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return true;
        double mx = click.x() / k, my = click.y() / k;
        status = "";
        if (inside(mx, my, rClose[0], rClose[1], rClose[2], rClose[3])) { client.setScreen(null); return true; }
        if (inside(mx, my, rNick[0], rNick[1], rNick[2], rNick[3])) { focus(nick); return true; }
        if (chatView && inside(mx, my, rChat[0], rChat[1], rChat[2], rChat[3])) { focus(chatIn); return true; }
        nick.setFocused(false);
        chatIn.setFocused(false);
        if (inside(mx, my, rAll[0], rAll[1], rAll[2], rAll[3])) {
            if (client.getCurrentServerEntry() == null) status = "Сначала зайди на сервер"; else MultiAccount.connectAll(client);
            return true;
        }
        if (inside(mx, my, rStop[0], rStop[1], rStop[2], rStop[3])) { MultiAccount.stopAll(); return true; }
        for (int r = 0; r < ROWS; r++) {
            int o = r * 4;
            if (rRows[o + 2] > 0 && inside(mx, my, rRows[o], rRows[o + 1], rRows[o + 2], rRows[o + 3]) && first + r < accs.size()) {
                sel = first + r;
                confirmDel = false;
                return true;
            }
        }
        if (chatView) {
            if (inside(mx, my, rBack[0], rBack[1], rBack[2], rBack[3])) { chatView = false; return true; }
            if (inside(mx, my, rTarget[0], rTarget[1], rTarget[2], rTarget[3])) { toAll = !toAll; return true; }
            return true;
        }
        for (int i = 0; i < 3; i++) {
            int o = i * 4;
            if (inside(mx, my, rBtn[o], rBtn[o + 1], rBtn[o + 2], rBtn[o + 3])) {
                button(i);
                return true;
            }
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (chatView) { chatView = false; chatIn.setFocused(false); return true; }
            client.setScreen(null);
            return true;
        }
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            if (nick.isFocused()) addNick();
            else if (chatIn.isFocused()) sendChat();
            return true;
        }
        if (!nick.isFocused() && !chatIn.isFocused()) {
            if (key == GLFW.GLFW_KEY_UP) { sel = Math.max(0, sel - 1); confirmDel = false; fit(); return true; }
            if (key == GLFW.GLFW_KEY_DOWN) { sel = Math.min(accs.size() - 1, sel + 1); confirmDel = false; fit(); return true; }
        }
        return super.keyPressed(input);
    }

    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean shouldPause() { return false; }
}
