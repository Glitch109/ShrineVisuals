package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Connects the "Target" card of the Shrine settings window to the TargetESP mod that is nested inside our jar
 * (META-INF/jars/TargetESP-*.jar, unmodified). Everything goes through reflection, so Shrine still loads
 * if that jar is ever missing. A value is pushed to TargetESP only when it changes in the Shrine window.
 */
final class TargetBridge {
    private TargetBridge() {}

    /** A numeric setting of TargetESP: its field name, the Shrine config key and the slider range. */
    record F(String field, String key, String label, float min, float max, float def, float step, String unit, int[] modes) {}

    static final String KEY = "esp.target";          // master switch
    static final String K_MODE = "esp.mode";
    static final String K_COLOR = "esp.color.";      // + mode index
    static final String K_HURT = "esp.hurt", K_AIM = "esp.aim";
    /** Show the effect only while the crosshair is on a creature (no lingering on the last attacked target). */
    static final String K_AIMONLY = "esp.aimonly";

    /** Same order as TargetESP's own mode list. */
    static final String[] MODES = {"Картинка", "Кольцо", "Души", "Кристаллы", "Цепи", "Ghosts", "Молнии", "GhostV3", "Точки", "Разряд"};

    // mode indexes
    private static final int[] ALL = null, RING = {1}, SOULS = {2}, CRYSTALS = {3}, CHAINS = {4}, BOLT = {6}, DOTS = {8};

    static final List<F> FLOATS = List.of(
        new F("size", "esp.size", "Размер", 0.6f, 2.5f, 1.15f, 0.05f, "x", ALL),
        new F("rotateSpeed", "esp.rotate", "Скорость вращения", 0.2f, 4f, 1.2f, 0.05f, "x", ALL),
        new F("ringRadius", "esp.ring.radius", "Радиус кольца", 0.3f, 1.5f, 0.5f, 0.05f, "", RING),
        new F("ringSpeed", "esp.ring.speed", "Скорость кольца", 0.3f, 3f, 1f, 0.1f, "x", RING),
        new F("chainSpeed", "esp.chain.speed", "Скорость цепей", 0.3f, 3f, 1f, 0.1f, "x", CHAINS),
        new F("lightningWidth", "esp.bolt.width", "Толщина молний", 0.25f, 3f, 1f, 0.05f, "x", BOLT),
        new F("lightningSpeed", "esp.bolt.speed", "Скорость молний", 0.25f, 3f, 1f, 0.05f, "x", BOLT),
        new F("dotsCount", "esp.dots.count", "Количество точек", 5f, 60f, 22f, 1f, "", DOTS),
        new F("dotsRadius", "esp.dots.radius", "Радиус точек", 0.3f, 2.5f, 0.85f, 0.05f, "", DOTS),
        new F("dotsSpeed", "esp.dots.speed", "Скорость точек", 0.2f, 5f, 1.8f, 0.1f, "x", DOTS),
        new F("dotsSize", "esp.dots.size", "Размер точек", 0.05f, 0.6f, 0.22f, 0.01f, "", DOTS),
        new F("soulSpeed", "esp.soul.speed", "Скорость душ", 0.1f, 10f, 3.8f, 0.1f, "x", SOULS),
        new F("soulRadius", "esp.soul.radius", "Радиус душ", 0.1f, 2f, 0.6f, 0.05f, "", SOULS),
        new F("soulSize", "esp.soul.size", "Размер душ", 0.05f, 1f, 0.3f, 0.05f, "", SOULS),
        new F("soulOpacity", "esp.soul.opacity", "Видимость душ", 0f, 100f, 100f, 1f, "%", SOULS),
        new F("crystalOrbitSpeed", "esp.crystal.speed", "Скорость кристаллов", 0.1f, 5f, 1f, 0.1f, "x", CRYSTALS)
    );

    // ---------------- runtime ----------------
    private static boolean tried, ok;
    private static Object module;
    private static Class<?> cls;
    private static final Map<String, Object> pushed = new HashMap<>();
    private static long lastAimMs;
    private static Field attackedF, attackTimeF;
    private static boolean attackedTried;

    /** How long (ms) TargetESP may keep fading out after the crosshair left the creature, before it is switched off. */
    private static final long GRACE_MS = 450L;

    /** Is the crosshair on a living creature right now? */
    private static boolean aiming(MinecraftClient mc) {
        if (mc.player == null) return false;
        Entity e = mc.targetedEntity;
        return e instanceof LivingEntity le && le != mc.player && le.isAlive() && !le.isSpectator();
    }

    /** TargetESP also shows the LAST ATTACKED creature for a while. Forget it, so only the crosshair decides. */
    private static void forgetAttacked() {
        try {
            if (!attackedTried) {
                attackedTried = true;
                Class<?> c = Class.forName("dev.mixoratarget.Client", true, TargetBridge.class.getClassLoader());
                Field a = c.getDeclaredField("attacked");
                a.setAccessible(true);
                if (Modifier.isStatic(a.getModifiers())) attackedF = a;
                try {
                    Field t = c.getDeclaredField("attackTime");
                    t.setAccessible(true);
                    if (Modifier.isStatic(t.getModifiers())) attackTimeF = t;
                } catch (Throwable ignored) { }
            }
            if (attackedF != null) attackedF.set(null, null);
            if (attackTimeF != null) attackTimeF.setLong(null, 0L);
        } catch (Throwable t) {
            attackedF = null;
            attackTimeF = null;
        }
    }

    private static boolean init() {
        if (tried) return ok;
        tried = true;
        try {
            cls = Class.forName("dev.mixoratarget.modules.impl.render.TargetESP", true, TargetBridge.class.getClassLoader());
            module = cls.getField("INSTANCE").get(null);
            ok = module != null;
        } catch (Throwable t) {
            ok = false;
        }
        return ok;
    }

    private static Object field(String name) throws Exception {
        Field f = cls.getDeclaredField(name);
        f.setAccessible(true);
        return f.get(module);
    }

    private static void call(Object o, String m, Class<?> argT, Object arg) throws Exception {
        Method me = o.getClass().getMethod(m, argT);
        me.setAccessible(true);
        me.invoke(o, arg);
    }

    /** Called every client tick: copies the Shrine window values into TargetESP when they changed. */
    static void tick(MinecraftClient mc) {
        if (!init()) return;
        try {
            boolean en = ShrineCfg.bool(KEY, true);
            boolean aimOnly = ShrineCfg.bool(K_AIMONLY, true);
            if (en && aimOnly) {
                long now = System.currentTimeMillis();
                if (aiming(mc)) lastAimMs = now;
                forgetAttacked();                               // the attacked creature must not keep the effect alive
                en = now - lastAimMs <= GRACE_MS;                // crosshair left: TargetESP fades out, then it is off
            }
            if (changed("enabled", en)) call(module, "setEnabled", boolean.class, en);

            int mode = ShrineCfg.integer(K_MODE, 0);
            if (changed("mode", mode)) {
                Object ms = field("mode");
                @SuppressWarnings("unchecked")
                List<String> mods = (List<String>) ms.getClass().getMethod("getMods").invoke(ms);
                if (mode >= 0 && mode < mods.size()) call(ms, "set", String.class, mods.get(mode));
            }
            for (F f : FLOATS) {
                float v = ShrineCfg.num(f.key(), f.def());
                if (f.step() >= 1f) v = Math.round(v);
                if (changed(f.field(), v)) call(field(f.field()), "setValue", float.class, v);
            }
            boolean hurt = ShrineCfg.bool(K_HURT, true), aim = aimOnly || ShrineCfg.bool(K_AIM, true);
            if (changed("hurt", hurt)) call(field("hurtColor"), "setState", boolean.class, hurt);
            if (changed("aim", aim)) call(field("aimTarget"), "setState", boolean.class, aim);

            Object[] colors = (Object[]) field("modeColors");
            for (int i = 0; i < colors.length; i++) {
                int idx = ShrineCfg.integer(K_COLOR + i, 0);
                int argb = 0xFF000000 | ShrineGui.PALETTE[Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, idx))];
                if (changed("color" + i, argb)) call(colors[i], "set", int.class, argb);
            }
        } catch (Throwable t) {
            ok = false;   // incompatible TargetESP build: stop touching it
        }
    }

    private static boolean changed(String k, Object v) {
        if (Objects.equals(pushed.get(k), v)) return false;
        pushed.put(k, v);
        return true;
    }
}
