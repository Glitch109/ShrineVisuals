package com.shrine;

import com.shrine.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.shrine.Gfx.*;

/**
 * The home screen, PS5 style: "С возвращением в [logo] Shrine / Кто играет?". A row of users (first "+", then one round
 * avatar per account) and under it the three actions (Настройки, Одиночная игра, Сетевая игра). The focused user grows,
 * gets a ring, name and "Параметры". Click a user = play as them; click an action = go (as the focused user).
 * Mouse hover or the arrow keys move the focus.
 */
final class AccountsScreen extends Screen {
    static final Identifier STEVE = tex("steve_flat"), I_PLUS = tex("icon_plus");
    /** Dark, muted disc colors (PS5 avatars): the white head stands out on them. */
    static final int[] TINTS = {0x3A3D44, 0x30455C, 0x4D3A4A, 0x394E44, 0x574A38, 0x43396B};

    private static final float ROW_Y = 272f, SMALL = 68f, BIG = 110f;
    private static final DateTimeFormatter CLOCK_FMT = DateTimeFormatter.ofPattern("HH:mm, EEEE", Locale.forLanguageTag("ru-RU"));

    /** A round avatar: a dark disc with the white flat Steve head in it. */
    static void avatar(DrawContext ctx, float cx, float cy, float size, int tint, float a) {
        centered(ctx, DISC, cx, cy, size, size, argb(0.92f * a, tint));
        float hs = size * 0.58f;
        centered(ctx, STEVE, cx, cy, hs, hs, argb(a, 0xFFFFFF));
    }

    private final Scene scene = new Scene();
    private final List<Accounts.Acc> accs = new ArrayList<>();
    private float[] anim = new float[0];
    private int focus;
    private boolean busy, menuOpen, confirmDel;
    private String status = "", busyName = "";
    private float k = 1f, vw = 960f;
    private double lastMx = -1, lastMy = -1;
    private final float[] rParams = new float[4], rDel = new float[4];
    private Runnable pending;     // action to run after the fade-out
    private long exitAt;

    AccountsScreen() { super(Text.literal("shrine")); }

    @Override
    protected void init() {
        Accounts.init();
        scene.init(width, height);
        k = height / Scene.REF_H;
        vw = width / k;
        accs.clear();
        accs.addAll(Accounts.LIST);
        anim = new float[accs.size() + 1];
        focus = Math.min(1, accs.size());
        for (int i = 0; i < accs.size(); i++) if (accs.get(i).id.equals(Accounts.current)) focus = i + 1;
        for (int i = 0; i < anim.length; i++) anim[i] = i == focus ? 1f : 0f;
        menuOpen = false; confirmDel = false; pending = null;
    }

    private int count() { return accs.size() + 1; }

    private float cx(int i) {
        int n = count();
        float spacing = n > 1 ? Math.min(150f, (vw - 200f) / (n - 1)) : 0f;
        return vw / 2f - (n - 1) * spacing / 2f + i * spacing;
    }

    private Accounts.Acc focusedAcc() { return focus >= 1 && focus <= accs.size() ? accs.get(focus - 1) : null; }

    private boolean canParams() { Accounts.Acc a = focusedAcc(); return a != null && !a.type.equals("launcher"); }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        float out = 1f;
        if (pending != null) {
            out = 1f - (Util.getMeasuringTimeMs() - exitAt) / 280f;
            if (out <= 0f) { Gfx.cover(ctx, width, height); Runnable r = pending; pending = null; r.run(); return; }
        }
        scene.begin(ctx, mxReal, myReal, delta);
        float a = scene.fade() * out;
        scene.stars(ctx, delta);
        float mx = scene.mx, my = scene.my;

        if (!busy && !menuOpen && pending == null && (mx != lastMx || my != lastMy)) {
            lastMx = mx; lastMy = my;
            for (int i = 0; i < count(); i++) if (inside(mx, my, cx(i) - 56, ROW_Y - 56, 112, 112)) focus = i;
        }
        for (int i = 0; i < anim.length; i++) anim[i] += ((i == focus ? 1f : 0f) - anim[i]) * Math.min(1f, delta * 0.32f);

        // title: "С возвращением в [logo] Shrine"
        String prefix = "С возвращением в ", brand = "Shrine";
        float pw = width(textRenderer, Fnt.TITLE, prefix), bw = width(textRenderer, Fnt.TITLE_B, brand), logo = 30f;
        float x0 = vw / 2f - (pw + logo + 8f + bw) / 2f, ty = 126f - (1f - a) * 12f;
        text(ctx, textRenderer, Fnt.TITLE, prefix, x0, ty, argb(0.95f * a, 0xFFFFFF));
        centered(ctx, LOGO, x0 + pw + logo / 2f, ty - 2f, logo, logo, argb(a, ACCENT));
        text(ctx, textRenderer, Fnt.TITLE_B, brand, x0 + pw + logo + 8f, ty, argb(a, ACCENT));
        textC(ctx, textRenderer, Fnt.LABEL, "Кто играет?", vw / 2f, 162f, argb(0.5f * a, 0xFFFFFF));

        String raw = LocalDateTime.now().format(CLOCK_FMT);
        int sp = raw.indexOf(' ');
        String clock = (sp >= 0 && sp + 1 < raw.length()) ? raw.substring(0, sp + 1) + Character.toUpperCase(raw.charAt(sp + 1)) + raw.substring(sp + 2) : raw;
        text(ctx, textRenderer, Fnt.LABEL, clock, vw - width(textRenderer, Fnt.LABEL, clock) - 26f, 26f, argb(0.9f * a, 0xFFFFFF));

        // users
        rParams[2] = 0; rDel[2] = 0;
        for (int i = 0; i < count(); i++) {
            float f = anim[i], size = SMALL + (BIG - SMALL) * f, x = cx(i), y = ROW_Y + (1f - a) * 18f;
            Accounts.Acc acc = i == 0 ? null : accs.get(i - 1);
            if (i == 0) {
                centered(ctx, DISC, x, y, size, size, argb((0.16f + 0.10f * f) * a, 0xFFFFFF));
                centered(ctx, I_PLUS, x, y, size * 0.40f, size * 0.40f, argb((0.55f + 0.40f * f) * a, 0xFFFFFF));
            } else {
                avatar(ctx, x, y, size, TINTS[Math.abs(acc.id.hashCode()) % TINTS.length], (0.72f + 0.28f * f) * a);
            }
            if (f > 0.02f) centered(ctx, RING, x, y, size + 24f, size + 24f, argb(0.95f * f * a, 0xFFFFFF));
            float ly = y + size / 2f + 28f;
            if (i == focus) {
                textC(ctx, textRenderer, i == 0 ? Fnt.UI : Fnt.UI_B, i == 0 ? "Добавить пользователя" : acc.name, x, ly, argb(a, 0xFFFFFF));
                if (acc != null) {
                    boolean on = acc.id.equals(Accounts.current);
                    textC(ctx, textRenderer, Fnt.SMALL, acc.label() + (on ? " · вы играете" : ""), x, ly + 21f, argb(0.5f * a, 0xFFFFFF));
                    if (canParams()) {
                        String p = "Параметры";
                        float cw = width(textRenderer, Fnt.SMALL, p) + 34f, py = ly + 48f;
                        rParams[0] = x - cw / 2f; rParams[1] = py - 11f; rParams[2] = cw; rParams[3] = 22f;
                        boolean hp = inside(mx, my, rParams[0], rParams[1], rParams[2], rParams[3]);
                        box(ctx, RR, rParams[0], rParams[1], cw, 22f, 11f, argb((hp ? 0.22f : 0.10f) * a, 0xFFFFFF));
                        box(ctx, RR, rParams[0] + 9f, py - 4f, 14f, 8f, 3f, argb(0.75f * a, 0xFFFFFF));
                        text(ctx, textRenderer, Fnt.SMALL, p, rParams[0] + 28f, py, argb(0.85f * a, 0xFFFFFF));
                    }
                }
            } else {
                String name = i == 0 ? "Добавить пользователя" : acc.name;
                while (name.length() > 3 && width(textRenderer, Fnt.SMALL, name) > 112f) name = name.substring(0, name.length() - 2) + "…";
                textC(ctx, textRenderer, Fnt.SMALL, name, x, ly - 6f, argb(0.45f * a, 0xFFFFFF));
            }
        }

        if (!status.isEmpty()) textC(ctx, textRenderer, Fnt.LABEL, status, vw / 2f, 476f, argb(a, 0xFF8A80));
        else textC(ctx, textRenderer, Fnt.SMALL, "◄ ►  выбрать   ·   Enter  играть", vw / 2f, Scene.REF_H - 22f, argb(0.30f * a, 0xFFFFFF));

        if (menuOpen && canParams()) drawMenu(ctx, mx, my, a);
        if (busy) drawBusy(ctx);
        scene.end(ctx);
        BootFx.veil(ctx, width, height);   // end of the launch flash
    }

    private void drawMenu(DrawContext ctx, float mx, float my, float a) {
        float w = 250f, h = 56f, x = cx(focus) - w / 2f, y = ROW_Y + BIG / 2f + 118f;
        box(ctx, RR, x - 1, y - 1, w + 2, h + 2, 17, argb(0.12f * a, 0xFFFFFF));
        box(ctx, RR, x, y, w, h, 16, argb(0.97f * a, 0x1A1B1F));
        rDel[0] = x + 8f; rDel[1] = y + 8f; rDel[2] = w - 16f; rDel[3] = h - 16f;
        boolean hv = inside(mx, my, rDel[0], rDel[1], rDel[2], rDel[3]);
        box(ctx, RR, rDel[0], rDel[1], rDel[2], rDel[3], 12f, argb((hv ? 0.28f : 0.12f) * a, confirmDel ? 0xFF6A5A : 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.LABEL, confirmDel ? "Нажмите ещё раз — удалить" : "Удалить пользователя", x + w / 2f, y + h / 2f, argb(a, 0xFFFFFF));
    }

    private void drawBusy(DrawContext ctx) {
        ctx.fill(0, 0, Math.round(vw) + 1, Math.round(Scene.REF_H) + 1, argb(0.62f, 0x000000));
        float cxs = vw / 2f, cys = ROW_Y + 10f;
        for (int j = 0; j < 8; j++) {
            double ang = j * Math.PI / 4.0;
            float phase = (((scene.time * 1.6f - j * 0.125f) % 1f) + 1f) % 1f;
            centered(ctx, DOT, cxs + (float) Math.cos(ang) * 30f, cys + (float) Math.sin(ang) * 30f, 10f, 10f, argb((1f - phase) * 0.95f, 0xFFFFFF));
        }
        textC(ctx, textRenderer, Fnt.UI, "Входим как " + busyName + "…", cxs, cys + 78f, argb(0.95f, 0xFFFFFF));
    }

    // ---------- actions ----------
    /** Picking a user is the whole login: the user becomes active and we go straight to "Сетевая игра". */
    private void play(int i) {
        if (i == 0) { client.setScreen(new AddAccountScreen(this)); return; }
        if (pending != null || busy) return;
        useAccount(accs.get(i - 1));
    }

    /** Makes the account active (off the render thread), then opens "Сетевая игра". */
    void useAccount(Accounts.Acc acc) {
        Runnable toServers = () -> client.setScreen(new PsMultiplayerScreen(this));
        if (acc.id.equals(Accounts.current)) { pending = toServers; exitAt = Util.getMeasuringTimeMs(); return; }
        useAccount(acc, toServers);
    }

    /** Switches to the account (off the render thread); then runs {@code after}, if any. */
    private void useAccount(Accounts.Acc acc, Runnable after) {
        if (busy) return;
        busy = true; busyName = acc.name; status = ""; menuOpen = false;
        Thread t = new Thread(() -> {
            String err = Accounts.activate(acc);
            client.execute(() -> {
                busy = false;
                if (err != null) status = "Не удалось войти: " + err;
                else if (after != null) { pending = after; exitAt = Util.getMeasuringTimeMs(); }
            });
        }, "shrine-account-switch");
        t.setDaemon(true);
        t.start();
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (busy || pending != null) return true;
        double mx = click.x() / k, my = click.y() / k;
        if (click.button() == 1) { if (canParams()) { menuOpen = !menuOpen; confirmDel = false; } return true; }
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        if (menuOpen) {
            if (rDel[2] > 0 && inside(mx, my, rDel[0], rDel[1], rDel[2], rDel[3])) {
                if (!confirmDel) { confirmDel = true; return true; }
                Accounts.remove(focusedAcc());
                menuOpen = false; confirmDel = false;
                init();
                return true;
            }
            menuOpen = false; confirmDel = false;
            return true;
        }
        if (rParams[2] > 0 && inside(mx, my, rParams[0], rParams[1], rParams[2], rParams[3])) { menuOpen = true; return true; }
        for (int i = 0; i < count(); i++) {
            if (inside(mx, my, cx(i) - 56, ROW_Y - 56, 112, 112)) { focus = i; play(i); return true; }
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (busy || pending != null) return true;
        int key = input.key();
        if (key == GLFW.GLFW_KEY_ESCAPE) { if (menuOpen) { menuOpen = false; confirmDel = false; } return true; }
        if (menuOpen) return true;
        if (key == GLFW.GLFW_KEY_LEFT) { focus = Math.max(0, focus - 1); lastMx = scene.mx; lastMy = scene.my; return true; }
        if (key == GLFW.GLFW_KEY_RIGHT) { focus = Math.min(count() - 1, focus + 1); lastMx = scene.mx; lastMy = scene.my; return true; }
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER || key == GLFW.GLFW_KEY_SPACE) { play(focus); return true; }
        if ((key == GLFW.GLFW_KEY_DELETE || key == GLFW.GLFW_KEY_BACKSPACE) && canParams()) { menuOpen = true; return true; }
        return super.keyPressed(input);
    }

    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }
    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean shouldPause() { return false; }
}
