package com.shrine;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/**
 * Hud > "Boss Bar": the vanilla boss bar can be moved and scaled. The vanilla element is wrapped in a matrix transform,
 * so nothing about it changes when the function is off. The position is set by dragging the frame while chat is open ({@link HudEditor}).
 */
final class BossBarHud implements HudEditScreen.HudPanel {
    private BossBarHud() {}
    static final BossBarHud PANEL = new BossBarHud();

    static final String KEY = "hud.bossbar", K_SCALE = "boss.scale", K_X = "boss.x", K_Y = "boss.y";
    private static final float VANILLA_W = 182f, VANILLA_TOP = 12f, FRAME_H = 19f;

    static void register() {
        try {
            HudElementRegistry.replaceElement(Identifier.of("minecraft", "boss_bar"), original -> (ctx, tick) -> {
                if (!ShrineCfg.bool(KEY, true)) { original.render(ctx, tick); return; }
                MinecraftClient mc = MinecraftClient.getInstance();
                float k = mc.getWindow().getScaledHeight() / Scene.REF_H;
                float cx = mc.getWindow().getScaledWidth() / 2f, s = sc();
                ctx.getMatrices().pushMatrix();
                ctx.getMatrices().translate(posX() * k, posY() * k);
                ctx.getMatrices().translate(cx, VANILLA_TOP);
                ctx.getMatrices().scale(s, s);
                ctx.getMatrices().translate(-cx, -VANILLA_TOP);
                original.render(ctx, tick);
                ctx.getMatrices().popMatrix();
            });
        } catch (Throwable t) {
            System.err.println("[Shrine] boss bar element could not be wrapped: " + t);
        }
    }

    static float posX() { return ShrineCfg.num(K_X, 0f); }
    static float posY() { return ShrineCfg.num(K_Y, 0f); }
    static float sc() { return Math.max(0.5f, Math.min(2.5f, ShrineCfg.num(K_SCALE, 1f))); }
    private static float k() { return MinecraftClient.getInstance().getWindow().getScaledHeight() / Scene.REF_H; }

    // ---------- the chat editor ----------
    @Override public String title() { return "Боссбар"; }
    @Override public boolean enabled() { return ShrineCfg.bool(KEY, true); }
    @Override public boolean placeholder() { return true; }
    @Override public float[] bounds(float vw) {
        float k = k(), s = sc();
        return new float[]{vw / 2f - VANILLA_W * s / 2f / k + posX(), VANILLA_TOP / k + posY(), VANILLA_W * s / k, FRAME_H * s / k};
    }
    @Override public void drawDemo(DrawContext ctx, TextRenderer tr, float vw) {}
    @Override public void place(float vw, float left, float top, float[] b) {
        float k = k(), s = sc();
        ShrineCfg.setNum(K_X, Math.max(-vw, Math.min(vw, left - (vw / 2f - VANILLA_W * s / 2f / k))));
        ShrineCfg.setNum(K_Y, Math.max(-VANILLA_TOP / k, Math.min(Scene.REF_H - 30f, top - VANILLA_TOP / k)));
    }
    @Override public void reset() { ShrineCfg.setNum(K_X, 0f); ShrineCfg.setNum(K_Y, 0f); ShrineCfg.setNum(K_SCALE, 1f); }
    @Override public float scale() { return sc(); }
    @Override public void setScale(float s) { ShrineCfg.setNum(K_SCALE, s); }
}
