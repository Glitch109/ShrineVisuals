package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.GameMode;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import net.fabricmc.loader.api.FabricLoader;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Play with friends: opens the world to LAN and carries it out through the built-in tunnel. No setup needed. */
final class FriendsHost {
    private FriendsHost() {}

    static final String K_SERVER = "friends.server", K_RPORT = "friends.rport", K_PIRATES = "friends.pirates";

    private static BoreTunnel tunnel;
    private static volatile boolean hosting, ready;
    static volatile String error = "";
    /** Result of the self-test of the public link (empty = not tested yet). */
    static volatile String check = "";
    static volatile boolean checkOk;

    /** Public link given by e4all / e4mc (they publish the world themselves and write the link into the chat). */
    static volatile String link = "";
    static volatile long startedAt;
    private static final java.util.regex.Pattern LINK =
            java.util.regex.Pattern.compile("([a-z0-9][a-z0-9.-]*\\.e4mc\\.link)", java.util.regex.Pattern.CASE_INSENSITIVE);

    /** True when the e4all / e4mc mod is inside the game: then the world goes online through it, no setup, no port in the link. */
    static boolean e4() {
        for (var m : FabricLoader.getInstance().getAllMods()) {
            String id = m.getMetadata().getId();
            if (id.startsWith("e4mc") || id.startsWith("e4all")) return true;
        }
        return false;
    }

    /** Every game chat line goes through here: we pick the link that e4all writes. */
    static void onMessage(String text) {
        if (text == null) return;
        var m = LINK.matcher(text);
        if (!m.find()) return;
        link = m.group(1).toLowerCase();
        if (hosting) { ready = true; selfTest(link, 25565, null); }
    }

    static int tries() { BoreTunnel t = tunnel; return t == null ? 0 : t.incoming; }
    static String lastErr() { BoreTunnel t = tunnel; return t == null ? "" : t.lastErr; }

    static boolean hosting() { return hosting; }
    static boolean ready() { return ready; }
    static boolean pirates() { return ShrineCfg.bool(K_PIRATES, true); }

    /** The link for friends (same port every time while it is free). Empty until the first start. */
    static String address() {
        if (!link.isEmpty()) return link;
        if (e4() && tunnel == null) return "";
        int p = ShrineCfg.integer(K_RPORT, 0);
        return p > 0 ? ShrineCfg.str(K_SERVER, "bore.pub").trim() + ":" + p : "";
    }

    static void start() {
        error = "";
        check = "";
        MinecraftClient mc = MinecraftClient.getInstance();
        IntegratedServer srv = mc.getServer();
        if (srv == null) { error = "Только в одиночном мире"; return; }
        int local;
        if (srv.isRemote()) {
            local = srv.getServerPort();               // already open to LAN (vanilla "Open to LAN")
        } else {
            local = freePort();
            GameMode gm = mc.interactionManager != null ? mc.interactionManager.getCurrentGameMode() : GameMode.SURVIVAL;
            if (local <= 0 || !srv.openToLan(gm, false, local)) { error = "Не удалось открыть мир для сети"; return; }
        }
        srv.setOnlineMode(!pirates());
        stopTunnel();
        ready = false;
        hosting = true;
        startedAt = System.currentTimeMillis();
        if (e4()) {
            // e4all hooks openToLan and brings the world online by itself; the link arrives in the chat.
            if (!link.isEmpty()) { ready = true; selfTest(link, 25565, null); }
            else {
                // safety net: no link after 25 s (no e4 servers / no internet for QUIC) -> the old tunnel
                Thread w = new Thread(() -> {
                    try { Thread.sleep(25000); } catch (InterruptedException ignored) { return; }
                    if (hosting && link.isEmpty() && tunnel == null) {
                        IntegratedServer s2 = MinecraftClient.getInstance().getServer();
                        if (s2 != null && s2.isRemote()) launch(s2.getServerPort(), ShrineCfg.integer(K_RPORT, 0), true);
                    }
                }, "shrine-e4-fallback");
                w.setDaemon(true);
                w.start();
            }
            return;
        }
        launch(local, ShrineCfg.integer(K_RPORT, 0), true);
    }

    private static void launch(int local, int want, boolean retry) {
        BoreTunnel t = new BoreTunnel(ShrineCfg.str(K_SERVER, "bore.pub").trim(), local, want);
        tunnel = t;
        t.start(port -> {
            ShrineCfg.setInt(K_RPORT, port);
            ShrineCfg.save();
            ready = true;
            selfTest(ShrineCfg.str(K_SERVER, "bore.pub").trim(), port, t);
        }, msg -> {
            if (tunnel != t) return;
            if (!ready && want > 0 && retry) { t.stop(); launch(local, 0, false); return; }   // the old port is taken: get a new one
            error = msg;
            ready = false;
            hosting = false;
            t.stop();
        });
    }

    /** The world was closed: e4all dies with it, so its link is no longer valid. */
    static void worldClosed() { stop(); link = ""; }

    static void stop() { stopTunnel(); hosting = false; ready = false; check = ""; }

    private static void stopTunnel() {
        if (tunnel != null) { tunnel.stop(); tunnel = null; }
    }

    /** Knocks on our own public link like a friend would (Minecraft server-list ping) and tells whether it answers. */
    private static void selfTest(String host, int port, BoreTunnel t) {
        check = "Проверяю ссылку…";
        checkOk = false;
        Thread th = new Thread(() -> {
            String res;
            boolean ok = false;
            try (Socket s = new Socket()) {
                s.connect(new InetSocketAddress(host, port), 8000);
                s.setSoTimeout(8000);
                OutputStream o = s.getOutputStream();
                byte[] hb = host.getBytes(StandardCharsets.UTF_8);
                ByteArrayOutputStream hs = new ByteArrayOutputStream();
                hs.write(0x00);                    // handshake
                writeVarInt(hs, -1);               // protocol version is ignored for status
                writeVarInt(hs, hb.length);
                hs.write(hb);
                hs.write(port >> 8); hs.write(port & 0xFF);
                hs.write(1);                       // next state: status
                writeVarInt(o, hs.size());
                hs.writeTo(o);
                o.write(1); o.write(0);            // status request
                o.flush();
                int len = readVarInt(s.getInputStream());
                ok = len > 2;
                res = ok ? "Ссылка отвечает снаружи. Не заходит друг — у него не открывается " + host + " (VPN)"
                         : "Ссылка ответила странно — мир не принимает подключения";
            } catch (Exception ex) {
                String m = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
                res = "Ссылка не отвечает (" + m + ") — друзья не зайдут";
            }
            if (t != null && tunnel != t) return;
            checkOk = ok;
            check = res;
            if (t != null) t.resetStats();         // do not count our own test as a friend's knock
        }, "shrine-selftest");
        th.setDaemon(true);
        th.start();
    }

    private static void writeVarInt(OutputStream o, int v) throws IOException {
        while ((v & ~0x7F) != 0) { o.write((v & 0x7F) | 0x80); v >>>= 7; }
        o.write(v);
    }

    private static int readVarInt(InputStream in) throws IOException {
        int r = 0, shift = 0, b;
        do {
            b = in.read();
            if (b < 0) throw new IOException("обрыв");
            r |= (b & 0x7F) << shift;
            shift += 7;
            if (shift > 35) throw new IOException("ошибка ответа");
        } while ((b & 0x80) != 0);
        return r;
    }

    private static int freePort() {
        try (ServerSocket s = new ServerSocket(0)) { return s.getLocalPort(); } catch (Exception e) { return -1; }
    }

    static void setPirates(boolean v) {
        ShrineCfg.setBool(K_PIRATES, v);
        ShrineCfg.save();
        IntegratedServer srv = MinecraftClient.getInstance().getServer();
        if (srv != null) srv.setOnlineMode(!v);
    }

    /** Names of the connected friends (without yourself). */
    static List<String> players() {
        List<String> out = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();
        IntegratedServer srv = mc.getServer();
        if (srv == null || !hosting) return out;
        String me = mc.getSession().getUsername();
        for (ServerPlayerEntity p : srv.getPlayerManager().getPlayerList()) {
            String n = p.getName().getString();
            if (!n.equals(me)) out.add(n);
        }
        return out;
    }
}
