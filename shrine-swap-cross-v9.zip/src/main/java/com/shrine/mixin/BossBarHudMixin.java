package com.shrine.mixin;

import com.shrine.BgCtx;
import net.minecraft.client.gui.hud.BossBarHud;
import net.minecraft.network.packet.s2c.play.BossBarS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Multi Account: boss bars of a background account are not shown. */
@Mixin(BossBarHud.class)
public abstract class BossBarHudMixin {
    @Inject(method = "handlePacket", at = @At("HEAD"), cancellable = true)
    private void shrine$bgBossBar(BossBarS2CPacket packet, CallbackInfo ci) {
        if (BgCtx.active) ci.cancel();
    }
}
