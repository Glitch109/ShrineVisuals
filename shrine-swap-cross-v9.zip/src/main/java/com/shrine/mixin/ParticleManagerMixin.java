package com.shrine.mixin;

import com.shrine.BgCtx;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.entity.Entity;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Multi Account: particles of a background account are not shown. */
@Mixin(ParticleManager.class)
public abstract class ParticleManagerMixin {
    @Inject(method = "addParticle(Lnet/minecraft/client/particle/Particle;)V", at = @At("HEAD"), cancellable = true)
    private void shrine$bgParticle(Particle particle, CallbackInfo ci) {
        if (BgCtx.active) ci.cancel();
    }

    @Inject(method = "addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;)V", at = @At("HEAD"), cancellable = true)
    private void shrine$bgEmitter(Entity entity, ParticleEffect effect, CallbackInfo ci) {
        if (BgCtx.active) ci.cancel();
    }

    @Inject(method = "addEmitter(Lnet/minecraft/entity/Entity;Lnet/minecraft/particle/ParticleEffect;I)V", at = @At("HEAD"), cancellable = true)
    private void shrine$bgEmitterAged(Entity entity, ParticleEffect effect, int maxAge, CallbackInfo ci) {
        if (BgCtx.active) ci.cancel();
    }
}
