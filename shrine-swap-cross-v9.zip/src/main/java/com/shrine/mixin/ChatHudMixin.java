package com.shrine.mixin;

import com.shrine.BgCtx;
import com.shrine.Sess;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Multi Account: a background account's chat goes to its own log in the menu, not into the chat of the account on the screen. */
@Mixin(ChatHud.class)
public abstract class ChatHudMixin {
    @Inject(method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
            at = @At("HEAD"), cancellable = true)
    private void shrine$bgChat(Text message, MessageSignatureData signature, MessageIndicator indicator, CallbackInfo ci) {
        if (!BgCtx.active) return;
        Sess s = BgCtx.cur;
        if (s != null) s.incoming(message.getString());
        ci.cancel();
    }
}
