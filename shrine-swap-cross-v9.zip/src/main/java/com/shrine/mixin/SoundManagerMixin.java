package com.shrine.mixin;

import com.shrine.BgCtx;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundManager;
import net.minecraft.client.sound.SoundSystem;
import net.minecraft.client.sound.TickableSoundInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Multi Account: sounds of a background account are not played. */
@Mixin(SoundManager.class)
public abstract class SoundManagerMixin {
    @Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;)Lnet/minecraft/client/sound/SoundSystem$PlayResult;",
            at = @At("HEAD"), cancellable = true)
    private void shrine$bgPlay(SoundInstance sound, CallbackInfoReturnable<SoundSystem.PlayResult> cir) {
        if (BgCtx.active) cir.setReturnValue(SoundSystem.PlayResult.NOT_STARTED);
    }

    @Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;I)V", at = @At("HEAD"), cancellable = true)
    private void shrine$bgPlayDelayed(SoundInstance sound, int delay, CallbackInfo ci) {
        if (BgCtx.active) ci.cancel();
    }

    @Inject(method = "playNextTick", at = @At("HEAD"), cancellable = true)
    private void shrine$bgPlayNext(TickableSoundInstance sound, CallbackInfo ci) {
        if (BgCtx.active) ci.cancel();
    }
}
