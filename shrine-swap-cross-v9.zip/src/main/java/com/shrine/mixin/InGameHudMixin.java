package com.shrine.mixin;

import com.shrine.BgCtx;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Multi Account: titles and the action bar of a background account do not appear on the screen. */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "setOverlayMessage", at = @At("HEAD"), cancellable = true)
    private void shrine$bgOverlay(Text message, boolean tinted, CallbackInfo ci) {
        if (BgCtx.active) ci.cancel();
    }

    @Inject(method = "setTitleTicks", at = @At("HEAD"), cancellable = true)
    private void shrine$bgTitleTicks(int fadeIn, int stay, int fadeOut, CallbackInfo ci) {
        if (BgCtx.active) ci.cancel();
    }

    @Inject(method = "setSubtitle", at = @At("HEAD"), cancellable = true)
    private void shrine$bgSubtitle(Text subtitle, CallbackInfo ci) {
        if (BgCtx.active) ci.cancel();
    }

    @Inject(method = "setTitle", at = @At("HEAD"), cancellable = true)
    private void shrine$bgTitle(Text title, CallbackInfo ci) {
        if (BgCtx.active) ci.cancel();
    }

    @Inject(method = "clearTitle", at = @At("HEAD"), cancellable = true)
    private void shrine$bgClearTitle(CallbackInfo ci) {
        if (BgCtx.active) ci.cancel();
    }
}
