package com.shrine.mixin;

import com.shrine.BgCtx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Multi Account: what a background account does to the window (screens, camera, showing its world) is kept away from the screen. */
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @Shadow public ClientWorld world;

    @Inject(method = "joinWorld", at = @At("HEAD"), cancellable = true)
    private void shrine$bgJoinWorld(ClientWorld w, CallbackInfo ci) {
        if (BgCtx.active) {            // only remember the new world (dimension change): the renderer keeps showing the other account
            this.world = w;
            ci.cancel();
        }
    }

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void shrine$bgScreen(Screen screen, CallbackInfo ci) {
        if (BgCtx.active) ci.cancel();
    }

    @Inject(method = "setCameraEntity", at = @At("HEAD"), cancellable = true)
    private void shrine$bgCamera(Entity entity, CallbackInfo ci) {
        if (BgCtx.active) ci.cancel();
    }
}
