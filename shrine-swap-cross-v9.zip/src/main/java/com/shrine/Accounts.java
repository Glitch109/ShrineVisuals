package com.shrine;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * The "who is playing" list. Three kinds of accounts:
 * <ul>
 *   <li>launcher: whatever the launcher started the game with (always there, nothing to type);</li>
 *   <li>pirate: just a nick (offline UUID, no token), for servers without license check;</li>
 *   <li>licensed: Microsoft account added by device code; only the refresh token is kept, in config/shrine-accounts.json.</li>
 * </ul>
 * Picking an account swaps the game's Session. Chat signing keys stay those of the launcher account.
 */
final class Accounts {
    private Accounts() {}

    static final class Acc {
        String id = "", type = "pirate", name = "", uuid = "", refresh = "";
        String label() { return switch (type) { case "licensed" -> "Лицензия"; case "launcher" -> "Из лаунчера"; default -> "Пиратский"; }; }
    }

    static final List<Acc> LIST = new ArrayList<>();
    static String lastId = "", current = "launcher";
    static Session original;
    private static boolean ready;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("shrine-accounts.json"); }

    /** Call once the client exists (first title screen): remembers the launcher's session and reads the saved list. */
    static void init() {
        if (ready) return;
        ready = true;
        try { original = MinecraftClient.getInstance().getSession(); } catch (Throwable ignored) { }
        load();
        Acc l = find("launcher");
        if (l == null) { l = new Acc(); l.id = "launcher"; l.type = "launcher"; LIST.add(0, l); }
        try { if (original != null) l.name = original.getUsername(); } catch (Throwable ignored) { }
        if (l.name.isBlank()) l.name = "Игрок";
        current = "launcher";
    }

    static Acc find(String id) { for (Acc a : LIST) if (a.id.equals(id)) return a; return null; }
    static Acc currentAcc() { Acc a = find(current); return a != null ? a : (LIST.isEmpty() ? null : LIST.get(0)); }

    private static void load() {
        LIST.clear();
        try {
            Path f = file();
            if (!Files.isRegularFile(f)) return;
            JsonObject root = JsonParser.parseString(Files.readString(f, StandardCharsets.UTF_8)).getAsJsonObject();
            lastId = root.has("last") ? root.get("last").getAsString() : "";
            for (var e : root.getAsJsonArray("accounts")) {
                JsonObject o = e.getAsJsonObject();
                Acc a = new Acc();
                a.id = str(o, "id"); a.type = str(o, "type"); a.name = str(o, "name"); a.uuid = str(o, "uuid"); a.refresh = str(o, "refresh");
                if (!a.id.isBlank()) LIST.add(a);
            }
        } catch (Throwable t) {
            System.err.println("[Shrine] could not read accounts: " + t);
        }
    }

    private static String str(JsonObject o, String k) { return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : ""; }

    static void save() {
        try {
            JsonObject root = new JsonObject();
            root.addProperty("last", lastId);
            JsonArray arr = new JsonArray();
            for (Acc a : LIST) {
                JsonObject o = new JsonObject();
                o.addProperty("id", a.id); o.addProperty("type", a.type); o.addProperty("name", a.name);
                o.addProperty("uuid", a.uuid); o.addProperty("refresh", a.refresh);
                arr.add(o);
            }
            root.add("accounts", arr);
            Path f = file();
            Files.createDirectories(f.getParent());
            Files.writeString(f, GSON.toJson(root), StandardCharsets.UTF_8);
        } catch (Throwable t) {
            System.err.println("[Shrine] could not save accounts: " + t);
        }
    }

    static boolean validNick(String s) { return s != null && s.matches("[A-Za-z0-9_]{3,16}"); }

    static Acc addPirate(String name) {
        for (Acc a : LIST) if (a.type.equals("pirate") && a.name.equalsIgnoreCase(name)) return a;
        Acc a = new Acc();
        a.id = "p-" + UUID.randomUUID().toString().substring(0, 8);
        a.type = "pirate"; a.name = name; a.uuid = offlineUuid(name).toString();
        LIST.add(a);
        save();
        return a;
    }

    static Acc addLicensed(String name, UUID uuid, String refresh) {
        Acc a = null;
        for (Acc x : LIST) if (x.type.equals("licensed") && x.uuid.equals(uuid.toString())) a = x;
        if (a == null) { a = new Acc(); a.id = "m-" + uuid.toString().substring(0, 8); a.type = "licensed"; LIST.add(a); }
        a.name = name; a.uuid = uuid.toString(); a.refresh = refresh;
        save();
        return a;
    }

    static void remove(Acc a) {
        if (a == null || a.type.equals("launcher")) return;
        LIST.remove(a);
        if (a.id.equals(lastId)) lastId = "";
        save();
    }

    static UUID offlineUuid(String name) { return UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8)); }

    /** Switches the game to this account. Blocks (licensed accounts talk to Microsoft): call it off the render thread. @return null if all is well, else a message. */
    static String activate(Acc a) {
        try {
            switch (a.type) {
                case "launcher" -> {
                    if (original == null) return "Сессия лаунчера недоступна";
                    if (MinecraftClient.getInstance().getSession() != original) setSession(original);
                }
                case "licensed" -> {
                    MsLogin.Result r = MsLogin.refresh(a.refresh);
                    a.refresh = r.refresh(); a.name = r.name(); a.uuid = r.uuid().toString();
                    setSession(make(r.name(), r.uuid(), r.token(), true));
                }
                default -> setSession(make(a.name, offlineUuid(a.name), "0", false));
            }
            current = a.id;
            lastId = a.id;
            save();
            return null;
        } catch (Throwable t) {
            return describe(t);
        }
    }

    static String describe(Throwable t) {
        Throwable r = t;
        while (r.getCause() != null && r.getCause() != r) r = r.getCause();
        if (t instanceof NoClassDefFoundError || r instanceof NoClassDefFoundError || t instanceof ClassNotFoundException)
            return "Вход через Microsoft недоступен: в моде нет ViaFabricPlus";
        if (r instanceof NoSuchFieldException) return "не нашёл поле сессии в этой версии игры";
        String m = r.getMessage() == null || r.getMessage().isBlank() ? r.getClass().getSimpleName() : r.getMessage();
        m = m.replace('\n', ' ');
        return m.length() > 90 ? m.substring(0, 90) + "…" : m;
    }

    // ---------- the session swap (by reflection, so a renamed constructor or field cannot break the build) ----------
    private static Session make(String name, UUID uuid, String token, boolean msa) throws Exception {
        for (Constructor<?> c : Session.class.getDeclaredConstructors()) {
            Class<?>[] p = c.getParameterTypes();
            if (p.length < 5 || p[0] != String.class || p[1] != UUID.class || p[2] != String.class || p[3] != Optional.class || p[4] != Optional.class) continue;
            Object[] args = new Object[p.length];
            args[0] = name; args[1] = uuid; args[2] = token; args[3] = Optional.empty(); args[4] = Optional.empty();
            if (p.length == 6 && p[5].isEnum()) {           // older versions: Session.AccountType
                Object pick = null;
                for (Object e : p[5].getEnumConstants()) {
                    String n = ((Enum<?>) e).name();
                    if (msa ? n.equalsIgnoreCase("MSA") : n.equalsIgnoreCase("LEGACY")) pick = e;
                }
                args[5] = pick != null ? pick : p[5].getEnumConstants()[0];
            }
            c.setAccessible(true);
            return (Session) c.newInstance(args);
        }
        throw new IllegalStateException("Не нашёл конструктор Session");
    }

    private static void setSession(Session s) throws Exception {
        Field f = null;
        for (Field x : MinecraftClient.class.getDeclaredFields()) {      // the only non-static field of this type is the session
            if (x.getType() == Session.class && !java.lang.reflect.Modifier.isStatic(x.getModifiers())) { f = x; break; }
        }
        if (f == null) {
            String fieldName = FabricLoader.getInstance().getMappingResolver()
                    .mapFieldName("named", "net.minecraft.client.MinecraftClient", "session", "Lnet/minecraft/client/session/Session;");
            f = MinecraftClient.class.getDeclaredField(fieldName);
        }
        f.setAccessible(true);
        f.set(MinecraftClient.getInstance(), s);
    }
}
