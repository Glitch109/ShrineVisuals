package com.shrine;

import net.raphimc.minecraftauth.MinecraftAuth;
import net.raphimc.minecraftauth.java.JavaAuthManager;
import net.raphimc.minecraftauth.java.model.MinecraftProfile;
import net.raphimc.minecraftauth.java.model.MinecraftToken;
import net.raphimc.minecraftauth.msa.data.MsaConstants;
import net.raphimc.minecraftauth.msa.model.MsaApplicationConfig;
import net.raphimc.minecraftauth.msa.model.MsaDeviceCode;
import net.raphimc.minecraftauth.msa.model.MsaToken;
import net.raphimc.minecraftauth.msa.service.impl.DeviceCodeMsaAuthService;

import java.util.UUID;
import java.util.function.Consumer;

/**
 * Microsoft (licensed) login by device code: the game shows a code, the player types it on microsoft.com/link on any device.
 * Uses the open MinecraftAuth library that ViaFabricPlus already carries (compiled against, not copied). Every call blocks:
 * run it on a background thread. If the library is missing at run time, loading this class fails and {@link Accounts#describe} says so.
 */
final class MsLogin {
    private MsLogin() {}

    private static final MsaApplicationConfig CONFIG = new MsaApplicationConfig(MsaConstants.JAVA_TITLE_ID, MsaConstants.SCOPE_TITLE_AUTH);

    record Code(String uri, String directUri, String code) {}
    record Result(String token, String refresh, UUID uuid, String name) {}

    /** First login: calls onCode with the code to show, then waits (up to 5 minutes) until the player confirms. */
    static Result loginInteractive(Consumer<Code> onCode) throws Exception {
        JavaAuthManager m = JavaAuthManager.create(MinecraftAuth.createHttpClient())
                .msaApplicationConfig(CONFIG)
                .login(DeviceCodeMsaAuthService::new, (Consumer<MsaDeviceCode>) dc ->
                        onCode.accept(new Code(dc.getVerificationUri(), dc.getDirectVerificationUri(), dc.getUserCode())));
        return finish(m);
    }

    /** Later logins: a saved refresh token is enough. */
    static Result refresh(String refreshToken) throws Exception {
        JavaAuthManager m = JavaAuthManager.create(MinecraftAuth.createHttpClient())
                .msaApplicationConfig(CONFIG)
                .login(refreshToken);
        return finish(m);
    }

    private static Result finish(JavaAuthManager m) throws Exception {
        MsaToken msa = m.getMsaToken().getUpToDate();
        MinecraftToken mc = m.getMinecraftToken().getUpToDate();
        MinecraftProfile p = m.getMinecraftProfile().getUpToDate();
        return new Result(mc.getToken(), msa.getRefreshToken(), p.getId(), p.getName());
    }
}
