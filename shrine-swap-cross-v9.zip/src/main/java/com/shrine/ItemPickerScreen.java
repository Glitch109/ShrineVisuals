package com.shrine;

import com.shrine.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.shrine.Gfx.*;

/**
 * "Предмет 1 / 2" of АвтоСвап: a window with every item the game knows (vanilla and modded, all of them are in the registry
 * the server synced) and a search field on top. Click an item to pick it.
 */
final class ItemPickerScreen extends Screen {
    private static final float W = 540f, H = 400f, CELL = 44f, ICON = 2f;
    private static final List<Entry> ALL = new ArrayList<>();      // built once, the registry does not change while playing

    private record Entry(Item item, ItemStack stack, String id, String name, String hay) {}

    private final Screen parent;
    private final String cfgKey;
    private float k = 1f, vw = 960f;
    private String query = "";
    private List<Entry> shown = new ArrayList<>();
    private int scrollRow;
    private Entry hovered;

    ItemPickerScreen(Screen parent, String cfgKey) {
        super(Text.literal("Shrine"));
        this.parent = parent;
        this.cfgKey = cfgKey;
        if (ALL.isEmpty()) {
            for (Item it : Registries.ITEM) {
                if (it == Items.AIR) continue;
                ItemStack st = it.getDefaultStack();
                String id = Registries.ITEM.getId(it).toString();
                String nm = st.getName().getString();
                ALL.add(new Entry(it, st, id, nm, (nm + " " + id + " " + id.replace('_', ' ').replace(':', ' ')).toLowerCase(Locale.ROOT)));
            }
        }
        refilter();
    }

    /** Loose search: every word of the query must occur somewhere in the name or id; endings are forgiven ("тотемов" finds "тотем"). */
    private void refilter() {
        String[] words = query.trim().toLowerCase(Locale.ROOT).split("\\s+");
        shown = new ArrayList<>();
        for (Entry e : ALL) {
            boolean ok = true;
            for (String w : words) {
                if (w.isEmpty() || e.hay().contains(w)) continue;
                if (w.length() >= 5 && e.hay().contains(w.substring(0, w.length() - 2))) continue;
                ok = false;
                break;
            }
            if (ok) shown.add(e);
        }
        scrollRow = 0;
    }

    @Override protected void init() { k = height / Scene.REF_H; vw = width / k; }
    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }

    private float wx() { return (vw - W) / 2f; }
    private float wy() { return (Scene.REF_H - H) / 2f; }
    private float gx() { return wx() + 20f; }
    private float gy() { return wy() + 94f; }
    private int cols() { return Math.max(1, (int) ((W - 40f) / CELL)); }
    private int rows() { return Math.max(1, (int) ((H - 94f - 40f) / CELL)); }
    private int totalRows() { return (shown.size() + cols() - 1) / cols(); }

    private String tail(Fnt f, String s, float maxW) {
        while (s.length() > 1 && width(textRenderer, f, s) > maxW) s = s.substring(1);
        return s;
    }

    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        ctx.fillGradient(0, 0, width, height, argb(0.62f, 0x050505), argb(0.78f, 0x161616));
        float mx = mxReal / k, my = myReal / k;
        float x = wx(), y = wy();
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.scale(k, k);

        box(ctx, RR, x - 1, y - 1, W + 2, H + 2, 27, argb(0.14f, 0xFFFFFF));
        box(ctx, RR, x, y, W, H, 26, argb(0.95f, 0x0E0E0E));
        String title = AutoSwap.K_A.equals(cfgKey) ? "Предмет 1" : "Предмет 2";
        text(ctx, textRenderer, Fnt.UI_B, title, x + 22, y + 28, argb(1f, 0xFFFFFF));
        String cur = ShrineCfg.str(AutoSwap.K_A.equals(cfgKey) ? AutoSwap.K_NAME_A : AutoSwap.K_NAME_B,
                AutoSwap.K_A.equals(cfgKey) ? AutoSwap.DEF_NAME_A : AutoSwap.DEF_NAME_B);
        String curS = "Сейчас: " + cur;
        text(ctx, textRenderer, Fnt.SMALL, curS, x + W - 22 - width(textRenderer, Fnt.SMALL, curS), y + 28, argb(0.55f, 0xFFFFFF));

        // search field (always focused)
        box(ctx, RR, x + 20, y + 48, W - 40, 34, 12, argb(0.08f, 0xFFFFFF));
        box(ctx, RR_RING, x + 20, y + 48, W - 40, 34, 12, argb(0.22f, ACCENT));
        boolean caret = (Util.getMeasuringTimeMs() / 500L) % 2L == 0L;
        if (query.isEmpty()) text(ctx, textRenderer, Fnt.SMALL, "Поиск предмета...", x + 36, y + 65, argb(0.4f, 0xFFFFFF));
        else text(ctx, textRenderer, Fnt.SMALL, tail(Fnt.SMALL, query, W - 90f) + (caret ? "|" : ""), x + 36, y + 65, argb(1f, 0xFFFFFF));

        // item grid
        hovered = null;
        int cols = cols(), rows = rows();
        String selId = ShrineCfg.str(cfgKey, AutoSwap.K_A.equals(cfgKey) ? AutoSwap.DEF_A : AutoSwap.DEF_B);
        float gx = gx(), gy = gy();
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int i = (scrollRow + r) * cols + c;
                if (i >= shown.size()) break;
                Entry e = shown.get(i);
                float cx = gx + c * CELL, cy = gy + r * CELL;
                boolean hov = inside(mx, my, cx, cy, CELL, CELL);
                if (hov) hovered = e;
                boolean sel = e.id().equals(selId);
                if (hov || sel) box(ctx, RR, cx + 2, cy + 2, CELL - 4, CELL - 4, 10, argb(sel ? 0.30f : 0.10f, sel ? ACCENT : 0xFFFFFF));
                if (sel) box(ctx, RR_RING, cx + 2, cy + 2, CELL - 4, CELL - 4, 10, argb(0.7f, ACCENT));
                m.pushMatrix();
                m.translate(cx + (CELL - 16f * ICON) / 2f, cy + (CELL - 16f * ICON) / 2f);
                m.scale(ICON, ICON);
                ctx.drawItem(e.stack(), 0, 0);
                m.popMatrix();
            }
        }
        if (shown.isEmpty()) textC(ctx, textRenderer, Fnt.SMALL, "Ничего не найдено", x + W / 2f, gy + 60, argb(0.5f, 0xFFFFFF));

        // scrollbar
        int tr = totalRows();
        if (tr > rows) {
            float trackH = rows * CELL, th = Math.max(24f, trackH * rows / tr);
            float ty = gy + (trackH - th) * (scrollRow / (float) (tr - rows));
            box(ctx, RR, x + W - 14, gy, 4, trackH, 2, argb(0.08f, 0xFFFFFF));
            box(ctx, RR, x + W - 14, ty, 4, th, 2, argb(0.55f, ACCENT));
        }

        // footer: the name of the item under the cursor, and how many were found
        String foot = hovered != null ? hovered.name() + "  ·  " + hovered.id() : "Выбери предмет из списка";
        text(ctx, textRenderer, Fnt.SMALL, tail(Fnt.SMALL, foot, W - 160f), x + 22, y + H - 22, argb(0.75f, 0xFFFFFF));
        String cnt = shown.size() + " шт.";
        text(ctx, textRenderer, Fnt.TINY_B, cnt, x + W - 22 - width(textRenderer, Fnt.TINY_B, cnt), y + H - 22, argb(0.45f, 0xFFFFFF));
        m.popMatrix();
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        double mx = click.x() / k, my = click.y() / k;
        if (inside(mx, my, gx(), gy(), cols() * CELL, rows() * CELL)) {
            int c = (int) ((mx - gx()) / CELL), r = (int) ((my - gy()) / CELL);
            int i = (scrollRow + r) * cols() + c;
            if (c >= 0 && c < cols() && r >= 0 && i >= 0 && i < shown.size()) {
                Entry e = shown.get(i);
                AutoSwap.choose(cfgKey, e.id(), e.name());
                close();
                return true;
            }
        } else if (!inside(mx, my, wx(), wy(), W, H)) {      // a click outside the window closes it
            close();
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int max = Math.max(0, totalRows() - rows());
        scrollRow = Math.max(0, Math.min(max, scrollRow - (int) Math.signum(verticalAmount) * 2));
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        int cp = input.codepoint();
        if (cp >= 32 && cp != 127 && query.length() < 40) {
            query += new String(Character.toChars(cp));
            refilter();
        }
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int kc = input.key();
        if (kc == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        if (kc == GLFW.GLFW_KEY_BACKSPACE) {
            if (!query.isEmpty()) { query = query.substring(0, query.length() - 1); refilter(); }
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        if (client != null) client.setScreen(parent);
    }
}
