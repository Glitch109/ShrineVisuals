package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Auto > "АвтоСвап": one key swaps your left hand with a chosen item. You pick the two items yourself (press the row in the
 * settings: a window with every item and a search field opens) and the key yourself.
 *
 * Offhand is item A: the key brings item B to the left hand, and the next press brings A back. Offhand is something
 * else: the key brings A, or B if there is no A.
 *
 * It is done like a player does it, so a server has nothing to complain about:
 * <ul>
 *   <li>the item is in the hotbar: no inventory is opened. The slot is selected, "swap hands" (the F action) is sent, the old
 *       slot is selected again; each step is its own tick;</li>
 *   <li>the item is in the inventory: the inventory is opened (nothing is drawn), the slot is swapped with the left hand
 *       by a normal click, the inventory is closed; the movement keys that were held are held again afterwards.</li>
 * </ul>
 * A card with the item that came to the hand slides in at the top ({@link SwapToast}).
 */
final class AutoSwap {
    private AutoSwap() {}

    static final String KEY = "auto.swap.on", K_KEY = "auto.swap.key", K_A = "auto.swap.a", K_B = "auto.swap.b",
            K_NAME_A = "auto.swap.a.name", K_NAME_B = "auto.swap.b.name", K_MSG = "auto.swap.msg";
    static final String DEF_A = "minecraft:totem_of_undying", DEF_B = "minecraft:shield";
    static final String DEF_NAME_A = "Тотем бессмертия", DEF_NAME_B = "Щит";
    static final int DEF_KEY = GLFW.GLFW_KEY_R;

    private static boolean down;

    // the swap runs over a few ticks
    private static final int IDLE = 0, H_SELECT = 1, H_SWAP = 2, H_RESTORE = 3, I_OPEN = 4, I_CLICK = 5, I_CLOSE = 6;
    private static int phase = IDLE, slot, prevSlot, cooldown;
    private static ItemStack shown = ItemStack.EMPTY;
    private static boolean[] savedKeys = new boolean[0];

    private static String idOf(ItemStack s) {
        return s.isEmpty() ? "minecraft:air" : Registries.ITEM.getId(s.getItem()).toString();
    }

    private static boolean held() {
        int key = ShrineCfg.integer(K_KEY, DEF_KEY);
        if (key < 0) return false;
        long w = GLFW.glfwGetCurrentContext();
        if (w == 0L) return false;
        if (key >= 1000) return GLFW.glfwGetMouseButton(w, key - 1000) == GLFW.GLFW_PRESS;
        return GLFW.glfwGetKey(w, key) == GLFW.GLFW_PRESS;
    }

    /** The inventory that is opened for the swap: it does the real thing for the server, but draws nothing. */
    private static final class Ghost extends InventoryScreen {
        Ghost(PlayerEntity p) { super(p); }
        @Override public void render(DrawContext ctx, int mx, int my, float delta) { }
        @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }   // no dimming / blur either
    }

    /** The player inventory in any of its forms (in creative mode the game swaps the plain one for the creative screen by itself). */
    private static boolean inventoryOpen(MinecraftClient mc) {
        return mc.currentScreen instanceof InventoryScreen || mc.currentScreen instanceof CreativeInventoryScreen;
    }

    /** Called every client tick. */
    static void tick(MinecraftClient mc) {
        boolean now = held();
        boolean edge = now && !down;
        down = now;                                   // also tracked while a screen is open, so closing it never fires a swap
        if (phase != IDLE) { step(mc); return; }
        if (cooldown > 0) cooldown--;
        if (!edge || !ShrineCfg.bool(KEY, true) || cooldown > 0) return;
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.interactionManager == null) return;
        plan(mc);
    }

    private static String nameOf(String id) {
        return id.equals(ShrineCfg.str(K_A, DEF_A)) ? ShrineCfg.str(K_NAME_A, DEF_NAME_A) : ShrineCfg.str(K_NAME_B, DEF_NAME_B);
    }

    /** Slot of the item: 0..8 is the hotbar (searched first), 9..35 the rest of the inventory; -1 when there is none. */
    private static int find(PlayerEntity p, String id) {
        for (int i = 0; i < 36; i++) if (idOf(p.getInventory().getStack(i)).equals(id)) return i;
        return -1;
    }

    private static void card(ItemStack item, String title, String sub) {
        if (ShrineCfg.bool(K_MSG, true)) SwapToast.show(item, title, sub);
    }

    private static KeyBinding[] moveKeys(MinecraftClient mc) {
        return new KeyBinding[]{mc.options.forwardKey, mc.options.backKey, mc.options.leftKey, mc.options.rightKey,
                mc.options.jumpKey, mc.options.sprintKey, mc.options.sneakKey};
    }

    private static void plan(MinecraftClient mc) {
        PlayerEntity p = mc.player;
        String a = ShrineCfg.str(K_A, DEF_A), b = ShrineCfg.str(K_B, DEF_B);
        String off = idOf(p.getOffHandStack());
        String want;
        int found;
        if (off.equals(a)) { want = b; found = find(p, b); }
        else if (off.equals(b)) { want = a; found = find(p, a); }
        else {
            want = a; found = find(p, a);
            if (found < 0) { want = b; found = find(p, b); }
        }
        if (found < 0) { card(ItemStack.EMPTY, "АвтоСвап", "Нет предмета: " + nameOf(want)); cooldown = 10; return; }
        slot = found;
        shown = p.getInventory().getStack(slot).copy();
        prevSlot = p.getInventory().getSelectedSlot();
        phase = slot < 9 ? H_SELECT : I_OPEN;
        step(mc);
    }

    private static void finish() {
        phase = IDLE;
        cooldown = 6;                                  // never two swaps back to back
        card(shown, null, "Перемещено в левую руку");
    }

    private static void abort(MinecraftClient mc) {
        if (mc.player != null && phase >= H_SWAP && phase <= H_RESTORE) mc.player.getInventory().setSelectedSlot(prevSlot);
        phase = IDLE;
        cooldown = 6;
    }

    private static void step(MinecraftClient mc) {
        PlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || mc.getNetworkHandler() == null) { phase = IDLE; return; }
        switch (phase) {
            case H_SELECT -> {                        // item in the hotbar: no inventory at all
                if (mc.currentScreen != null) { abort(mc); return; }
                p.getInventory().setSelectedSlot(slot);
                phase = H_SWAP;
            }
            case H_SWAP -> {                          // the game has told the server about the new slot by now
                if (mc.currentScreen != null) { abort(mc); return; }
                mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN));
                phase = H_RESTORE;
            }
            case H_RESTORE -> {
                p.getInventory().setSelectedSlot(prevSlot);
                finish();
            }
            case I_OPEN -> {                          // item in the inventory: open it like a player would
                KeyBinding[] keys = moveKeys(mc);
                savedKeys = new boolean[keys.length];
                for (int i = 0; i < keys.length; i++) savedKeys[i] = keys[i].isPressed();
                mc.setScreen(new Ghost(p));
                phase = I_CLICK;
            }
            case I_CLICK -> {
                if (!inventoryOpen(mc)) { restoreKeys(mc); phase = IDLE; cooldown = 6; return; }      // somebody closed it: stop
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);   // 40 = swap with the left hand
                phase = I_CLOSE;
            }
            case I_CLOSE -> {
                if (inventoryOpen(mc)) mc.currentScreen.close();                      // sends the normal "inventory closed" packet
                restoreKeys(mc);
                finish();
            }
            default -> phase = IDLE;
        }
    }

    /** Opening a screen lets go of every key: give the movement keys that were held back. */
    private static void restoreKeys(MinecraftClient mc) {
        KeyBinding[] keys = moveKeys(mc);
        for (int i = 0; i < keys.length && i < savedKeys.length; i++) keys[i].setPressed(savedKeys[i]);
    }

    // ---------- used by the settings window ----------
    /** The row text under "Предмет 1 / 2". */
    static String hintFor(String key) {
        boolean a = K_A.equals(key);
        return "Сейчас: " + ShrineCfg.str(a ? K_NAME_A : K_NAME_B, a ? DEF_NAME_A : DEF_NAME_B) + "  ·  нажми, чтобы выбрать из списка";
    }

    /** Stores the item picked in the item window as item 1 or 2. */
    static void choose(String key, String id, String name) {
        boolean a = K_A.equals(key);
        ShrineCfg.setStr(a ? K_A : K_B, id);
        ShrineCfg.setStr(a ? K_NAME_A : K_NAME_B, name);
        ShrineCfg.save();
    }

    static String keyName(int k) {
        if (k < 0) return "Не задана";
        if (k >= 1000) return switch (k - 1000) {
            case 2 -> "Колёсико";
            case 3 -> "Мышь 4";
            case 4 -> "Мышь 5";
            default -> "Мышь " + (k - 999);
        };
        if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F12) return "F" + (k - GLFW.GLFW_KEY_F1 + 1);
        String n = switch (k) {
            case GLFW.GLFW_KEY_SPACE -> "Пробел";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "L Shift";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "R Shift";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "L Ctrl";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "R Ctrl";
            case GLFW.GLFW_KEY_LEFT_ALT -> "L Alt";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "R Alt";
            case GLFW.GLFW_KEY_TAB -> "Tab";
            case GLFW.GLFW_KEY_CAPS_LOCK -> "Caps";
            case GLFW.GLFW_KEY_ENTER -> "Enter";
            case GLFW.GLFW_KEY_UP -> "Вверх";
            case GLFW.GLFW_KEY_DOWN -> "Вниз";
            case GLFW.GLFW_KEY_LEFT -> "Влево";
            case GLFW.GLFW_KEY_RIGHT -> "Вправо";
            default -> null;
        };
        if (n != null) return n;
        String g = GLFW.glfwGetKeyName(k, 0);
        return g != null ? g.toUpperCase() : "Клавиша " + k;
    }
}
