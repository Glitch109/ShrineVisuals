package com.shrine;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;

/**
 * Hud > "Cross": your own crosshair. It is a 13 x 13 pixel picture (every pixel has its own color) drawn in the middle of the
 * screen instead of the vanilla crosshair. Two styles: "как в игре" (the pixels invert what is behind them, like the vanilla
 * crosshair) and "сплошной" (flat colors with an opacity). The picture is drawn in the editor ({@link CrossEditScreen}).
 */
final class CrossHud {
    private CrossHud() {}

    static final String KEY = "hud.cross", K_STYLE = "cross.style", K_SCALE = "cross.scale", K_OPACITY = "cross.opacity", K_PIXELS = "cross.pixels";
    static final String[] STYLES = {"Как в игре (инверсия)", "Сплошной цвет"};
    static final int N = 13, C = N / 2;

    private static String cacheStr;
    private static int[] cache;

    static void register() {
        try {
            HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (ctx, tick) -> {
                if (!ShrineCfg.bool(KEY, false)) { original.render(ctx, tick); return; }
                MinecraftClient mc = MinecraftClient.getInstance();
                if (mc.player == null || mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson()) return;
                draw(ctx, pixels(), mc.getWindow().getScaledWidth() / 2f, mc.getWindow().getScaledHeight() / 2f,
                        Math.max(0.5f, Math.min(5f, ShrineCfg.num(K_SCALE, 1f))), ShrineCfg.integer(K_STYLE, 0) == 0,
                        Math.max(0.1f, Math.min(1f, ShrineCfg.num(K_OPACITY, 100f) / 100f)));
            });
        } catch (Throwable t) {
            System.err.println("[Shrine] crosshair element could not be replaced: " + t);
        }
    }

    // ---------- the picture: 169 ARGB ints, kept in the config as 8 hex digits per pixel ----------
    static int[] pixels() {
        String s = ShrineCfg.str(K_PIXELS, "");
        if (cache == null || !s.equals(cacheStr)) { cache = parse(s); cacheStr = s; }
        return cache;
    }

    static void setPixels(int[] px) {
        ShrineCfg.setStr(K_PIXELS, serialize(px));
        cache = px.clone();
        cacheStr = serialize(px);
    }

    private static int[] parse(String s) {
        if (s.length() != N * N * 8) return preset(0);
        int[] px = new int[N * N];
        try {
            for (int i = 0; i < px.length; i++) px[i] = (int) Long.parseLong(s.substring(i * 8, i * 8 + 8), 16);
        } catch (NumberFormatException e) { return preset(0); }
        return px;
    }

    static String serialize(int[] px) {
        StringBuilder b = new StringBuilder(N * N * 8);
        for (int v : px) b.append(String.format("%08X", v));
        return b.toString();
    }

    // ---------- ready-made pictures ----------
    static final String[] PRESET_NAMES = {"Классика", "С зазором", "Толстый", "Точка", "Круг", "Ромб", "Углы", "Т-образный"};
    static final int WHITE = 0xFFFFFFFF;

    static int[] preset(int id) {
        int[] px = new int[N * N];
        for (int y = 0; y < N; y++) {
            for (int x = 0; x < N; x++) {
                int dx = Math.abs(x - C), dy = Math.abs(y - C);
                boolean on = switch (id) {
                    case 0 -> (dx == 0 && dy <= 5) || (dy == 0 && dx <= 5);
                    case 1 -> (dx == 0 && dy >= 2 && dy <= 5) || (dy == 0 && dx >= 2 && dx <= 5);
                    case 2 -> (dx <= 1 && dy >= 1 && dy <= 4) || (dy <= 1 && dx >= 1 && dx <= 4);
                    case 3 -> dx <= 1 && dy <= 1;
                    case 4 -> Math.abs(Math.sqrt(dx * dx + dy * dy) - 5.0) < 0.6 || (dx == 0 && dy == 0);
                    case 5 -> dx + dy == 5;
                    case 6 -> (dx >= 3 && dx <= 5 && dy == 5) || (dy >= 3 && dy <= 5 && dx == 5);
                    default -> (dx == 0 && y > C && dy <= 5) || (dy == 0 && dx <= 5);
                };
                if (on) px[y * N + x] = WHITE;
            }
        }
        return px;
    }

    // ---------- drawing ----------
    /** Draws the picture centered at (cx, cy) in GUI pixels. {@code invert}: vanilla look; otherwise flat colors times {@code opacity}. */
    static void draw(DrawContext ctx, int[] px, float cx, float cy, float scale, boolean invert, float opacity) {
        int cell = Math.max(1, Math.round(scale));            // whole pixels per cell: sharp edges
        float factor = scale / cell;
        float half = N * cell / 2f;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(cx, cy);
        if (Math.abs(factor - 1f) > 0.001f) ctx.getMatrices().scale(factor, factor);
        ctx.getMatrices().translate(-half, -half);
        for (int row = 0; row < N; row++) {
            int y = row * cell, runStart = -1, runColor = 0;
            for (int col = 0; col <= N; col++) {
                int c = col < N ? cellColor(px[row * N + col], invert, opacity) : 0;
                if (runStart >= 0 && c != runColor) { fill(ctx, runStart * cell, y, col * cell, y + cell, runColor, invert); runStart = -1; }
                if (runStart < 0 && c != 0) { runStart = col; runColor = c; }
            }
        }
        ctx.getMatrices().popMatrix();
    }

    private static int cellColor(int argb, boolean invert, float opacity) {
        int a = argb >>> 24;
        if (a == 0) return 0;
        if (invert) return 0xFFFFFFFF;
        int fa = Math.round(a * opacity);
        return fa == 0 ? 0 : (fa << 24) | (argb & 0xFFFFFF);
    }

    private static void fill(DrawContext ctx, int x0, int y0, int x1, int y1, int color, boolean invert) {
        if (invert) ctx.fill(RenderPipelines.GUI_INVERT, x0, y0, x1, y1, color);
        else ctx.fill(x0, y0, x1, y1, color);
    }
}
