package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import org.lwjgl.glfw.GLFW;

import java.util.List;

import static com.shrine.Gfx.*;

/**
 * The HUD editor: while chat is open every widget of the mod (health of the target, Inventory, Players Near, boss bar, scoreboard)
 * shows a frame. Drag a frame to move the widget, drag the square in its corner to resize, right click resets it.
 * Mouse buttons are read straight from GLFW, so chat itself keeps working as usual.
 */
final class HudEditor {
    private HudEditor() {}

    private static final List<HudEditScreen.HudPanel> PANELS = List.of(HudEditScreen.TARGET, InventoryHud.PANEL, NearHud.PANEL, BossBarHud.PANEL, ScoreboardHud.PANEL);

    private static HudEditScreen.HudPanel active;
    private static boolean scaling, wasDown, wasRight;
    private static float grabX, grabY, startScale, startW;

    static void register() {
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (!(screen instanceof ChatScreen)) return;
            active = null; scaling = false; wasDown = false; wasRight = false;
            ScreenEvents.afterRender(screen).register(HudEditor::render);
        });
    }

    private static boolean inside(float[] b, float x, float y, float pad) {
        return x >= b[0] - pad && x <= b[0] + b[2] + pad && y >= b[1] - pad && y <= b[1] + b[3] + pad;
    }

    private static boolean onHandle(float[] b, float x, float y) {
        float hs = Math.min(16f, Math.min(b[2], b[3]) / 2f);
        return x >= b[0] + b[2] - hs && x <= b[0] + b[2] + 3f && y >= b[1] + b[3] - hs && y <= b[1] + b[3] + 3f;
    }

    private static void render(Screen screen, DrawContext ctx, int mx, int my, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        float k = sh / Scene.REF_H, vw = sw / k, vx = mx / k, vy = my / k;
        long win = GLFW.glfwGetCurrentContext();
        boolean down = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean right = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean inputBar = my > sh - 18;                       // the chat input line is not ours

        // ----- input -----
        if (down && !wasDown && !inputBar) {
            for (int i = PANELS.size() - 1; i >= 0; i--) {
                HudEditScreen.HudPanel p = PANELS.get(i);
                float[] b = p.bounds(vw);
                if (!inside(b, vx, vy, 2f)) continue;
                active = p;
                scaling = onHandle(b, vx, vy);
                grabX = scaling ? b[0] : vx - b[0];
                grabY = vy - b[1];
                startScale = p.scale();
                startW = Math.max(10f, b[2]);
                break;
            }
        }
        if (down && active != null) {
            float[] b0 = active.bounds(vw);
            if (scaling) {
                float s = startScale * Math.max(20f, vx - grabX) / startW;
                active.setScale(Math.max(0.5f, Math.min(active.maxScale(), s)));
                active.place(vw, b0[0], b0[1], active.bounds(vw));      // keep the top-left corner where it was
            } else {
                active.place(vw, vx - grabX, vy - grabY, b0);
            }
        }
        if (!down && wasDown && active != null) { active = null; scaling = false; ShrineCfg.save(); }
        if (right && !wasRight && !inputBar) {
            for (int i = PANELS.size() - 1; i >= 0; i--) {
                HudEditScreen.HudPanel p = PANELS.get(i);
                if (inside(p.bounds(vw), vx, vy, 2f)) { p.reset(); ShrineCfg.save(); break; }
            }
        }
        wasDown = down; wasRight = right;

        // ----- drawing -----
        for (HudEditScreen.HudPanel p : PANELS) if (!p.placeholder()) p.drawDemo(ctx, mc.textRenderer, vw);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        for (HudEditScreen.HudPanel p : PANELS) {
            float[] b = p.bounds(vw);
            boolean on = p.enabled(), hover = inside(b, vx, vy, 2f), act = p == active;
            float a = on ? 1f : 0.55f;
            if (p.placeholder()) box(ctx, RR, b[0], b[1], b[2], b[3], 10, argb(0.12f * a, 0xFFFFFF));
            box(ctx, RR_RING, b[0] - 2f, b[1] - 2f, b[2] + 4f, b[3] + 4f, 14, argb((act ? 1f : hover ? 0.95f : 0.55f) * a, 0xFFFFFF));
            String t = p.title() + (on ? "" : " · выкл");
            float ty = b[1] < 16f ? b[1] + b[3] + 9f : b[1] - 9f;
            text(ctx, mc.textRenderer, Fnt.SMALL, t, b[0] + 3f, ty + 1f, argb(0.9f * a, 0x000000));
            text(ctx, mc.textRenderer, Fnt.SMALL, t, b[0] + 2f, ty, argb(a, 0xFFFFFF));
            float hs = Math.min(8f, Math.min(b[2], b[3]) / 3f);
            box(ctx, RR, b[0] + b[2] - hs - 1f, b[1] + b[3] - hs - 1f, hs, hs, 3, argb((scaling && act ? 1f : 0.85f) * a, 0xFFFFFF));
        }
        String hint = "Перетаскивай виджеты · квадрат в углу — размер · правая кнопка — сбросить";
        float tw = width(mc.textRenderer, Fnt.SMALL, hint);
        float hy = Scene.REF_H - 84f;
        box(ctx, RR, vw / 2f - tw / 2f - 12f, hy - 12f, tw + 24f, 24f, 12, argb(0.55f, 0x0C0C10));
        text(ctx, mc.textRenderer, Fnt.SMALL, hint, vw / 2f - tw / 2f, hy, argb(0.9f, 0xFFFFFF));
        ctx.getMatrices().popMatrix();
    }
}
