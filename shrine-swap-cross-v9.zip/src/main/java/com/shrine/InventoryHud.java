package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import static com.shrine.Gfx.*;

/**
 * Hud > "Inventory": the whole inventory (3 rows of 9) as a mini grid over the game. A slot where an item
 * just landed (new item or a bigger stack) lights up green for a second. Position and size: {@link HudEditScreen}.
 */
final class InventoryHud implements HudEditScreen.HudPanel {
    private InventoryHud() {}
    static final InventoryHud PANEL = new InventoryHud();

    static final String KEY = "hud.inventory", K_FLASH = "inv.flash", K_COLOR = "inv.color", K_SCALE = "inv.scale", K_GLASS = "inv.glass", K_X = "inv.x", K_Y = "inv.y";
    static final float TOP = 56f, PAD = 10f, CELL = 26f, GAP = 3f;
    static final int COLS = 9, ROWS = 3, N = COLS * ROWS;
    static final float W = PAD * 2 + COLS * CELL + (COLS - 1) * GAP, H = PAD * 2 + ROWS * CELL + (ROWS - 1) * GAP;
    private static final int GREEN = 0x7CFF7C;

    private static final Item[] items = new Item[N];
    private static final int[] counts = new int[N];
    private static final long[] flash = new long[N];
    private static final ItemStack[] live = new ItemStack[N];
    private static Object lastPlayer;
    private static long joined;
    private static boolean primed;

    static void register() {
        java.util.Arrays.fill(live, ItemStack.EMPTY);
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "inventory_hud"), (ctx, tick) -> render(ctx));
    }

    // ---------- settings ----------
    static float posX() { return ShrineCfg.num(K_X, 0f); }
    static float posY() { return ShrineCfg.num(K_Y, 0f); }
    static float sc() { return Math.max(0.5f, Math.min(2.5f, ShrineCfg.num(K_SCALE, 1f))); }
    private static float glass() { return Math.max(0.2f, Math.min(1f, ShrineCfg.num(K_GLASS, 60f) / 100f)); }
    private static int color() { return ShrineGui.PALETTE[Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 0)))]; }

    // ---------- the in-game element ----------
    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, false)) { primed = false; return; }
        long now = Util.getMeasuringTimeMs();
        PlayerInventory inv = mc.player.getInventory();
        if (lastPlayer != mc.player) { lastPlayer = mc.player; primed = false; joined = now; java.util.Arrays.fill(flash, 0L); }
        boolean watch = primed && now - joined > 1500L && ShrineCfg.bool(K_FLASH, true);
        for (int i = 0; i < N; i++) {
            ItemStack st = inv.getStack(9 + i);          // slots 9..35 = the 27 slots above the hotbar
            Item it = st.isEmpty() ? null : st.getItem();
            int c = st.isEmpty() ? 0 : st.getCount();
            if (watch && c > 0 && (it != items[i] || c > counts[i])) flash[i] = now;
            items[i] = it; counts[i] = c; live[i] = st;
        }
        primed = true;
        float k = mc.getWindow().getScaledHeight() / Scene.REF_H, vw = mc.getWindow().getScaledWidth() / k;
        drawAt(ctx, mc.textRenderer, vw, live, flash, now);
    }

    static void drawAt(DrawContext ctx, TextRenderer tr, float vw, ItemStack[] st, long[] fl, long now) {
        MinecraftClient mc = MinecraftClient.getInstance();
        float k = mc.getWindow().getScaledHeight() / Scene.REF_H;
        float s = sc();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        ctx.getMatrices().translate(vw / 2f + posX(), TOP + posY());
        ctx.getMatrices().scale(s, s);
        ctx.getMatrices().translate(-W / 2f, 0f);
        panel(ctx, tr, st, fl, now);
        ctx.getMatrices().popMatrix();
    }

    private static float amt(long now, long t) { return t <= 0L ? 0f : Math.max(0f, 1f - (now - t) / 1100f); }

    private static void panel(DrawContext ctx, TextRenderer tr, ItemStack[] st, long[] fl, long now) {
        int col = color();
        float any = 0f;
        for (long f : fl) any = Math.max(any, amt(now, f));
        float g = glass();
        box(ctx, RR, 0, 0, W, H, 16, argb(g, 0x0C0C10));                                       // translucent glass body
        box(ctx, RR, 1f, 1f, W - 2f, H * 0.42f, 15, argb(0.05f, 0xFFFFFF));                    // sheen
        if (any > 0f) box(ctx, RR, 0, 0, W, H, 16, argb(0.20f * any, GREEN));
        box(ctx, RR_RING, 0, 0, W, H, 16, argb(0.80f, col));                                   // bright edge
        for (int i = 0; i < N; i++) {
            float sx = PAD + (i % COLS) * (CELL + GAP), sy = PAD + (i / COLS) * (CELL + GAP);
            ItemStack s = st[i];
            if (s == null || s.isEmpty()) {
                box(ctx, RR, sx, sy, CELL, CELL, 7, argb(0.03f, 0xFFFFFF));
                continue;
            }
            box(ctx, RR, sx, sy, CELL, CELL, 7, argb(0.08f, 0xFFFFFF));
            float f = amt(now, fl[i]);
            if (f > 0f) {
                box(ctx, RR, sx, sy, CELL, CELL, 7, argb(0.40f * f, GREEN));
                box(ctx, RR_RING, sx, sy, CELL, CELL, 7, argb(0.95f * f, GREEN));
            }
            float is = 1.15f;
            ctx.getMatrices().pushMatrix();
            ctx.getMatrices().translate(sx + (CELL - 16f * is) / 2f, sy + (CELL - 16f * is) / 2f - 1f);
            ctx.getMatrices().scale(is, is);
            ctx.drawItem(s, 0, 0);
            ctx.getMatrices().popMatrix();
            if (s.isItemBarVisible()) {
                float bw = CELL - 10f, fw = Math.max(2f, bw * s.getItemBarStep() / 13f);
                box(ctx, RR, sx + 5, sy + CELL - 5, bw, 2, 1, argb(0.7f, 0x000000));
                box(ctx, RR, sx + 5, sy + CELL - 5, fw, 2, 1, argb(1f, s.getItemBarColor()));
            }
            if (s.getCount() > 1) {
                String n = String.valueOf(s.getCount());
                float tx = sx + CELL - 3f - width(MinecraftClient.getInstance().textRenderer, Fnt.TINY_B, n);
                text(ctx, tr, Fnt.TINY_B, n, tx + 1f, sy + CELL - 6f + 1f, argb(0.9f, 0x000000));
                text(ctx, tr, Fnt.TINY_B, n, tx, sy + CELL - 6f, argb(1f, 0xFFFFFF));
            }
        }
    }

    // ---------- the position editor ----------
    @Override public String title() { return "Inventory"; }
    @Override public boolean enabled() { return ShrineCfg.bool(KEY, false); }
    @Override public float[] bounds(float vw) { float s = sc(); return new float[]{vw / 2f + posX() - W * s / 2f, TOP + posY(), W * s, H * s}; }
    @Override public float scale() { return sc(); }
    @Override public void setScale(float s) { ShrineCfg.setNum(K_SCALE, s); }
    @Override public void reset() { ShrineCfg.setNum(K_X, 0f); ShrineCfg.setNum(K_Y, 0f); ShrineCfg.setNum(K_SCALE, 1f); }
    @Override public void place(float vw, float left, float top, float[] b) {
        ShrineCfg.setNum(K_X, Math.max(-vw, Math.min(vw, left + b[2] / 2f - vw / 2f)));
        ShrineCfg.setNum(K_Y, Math.max(-TOP, Math.min(Scene.REF_H - TOP - 20f, top - TOP)));
    }
    @Override public void drawDemo(DrawContext ctx, TextRenderer tr, float vw) {
        Item[] pool = {Items.ENDER_PEARL, Items.GOLDEN_APPLE, Items.GOLDEN_APPLE, Items.SPLASH_POTION, Items.TOTEM_OF_UNDYING, Items.TOTEM_OF_UNDYING,
                Items.ARROW, Items.BOW, Items.OBSIDIAN, Items.SPLASH_POTION, Items.SPLASH_POTION, Items.SPLASH_POTION, Items.SPLASH_POTION, null,
                Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, null, Items.OAK_PLANKS, Items.BREAD, Items.IRON_INGOT, Items.DIAMOND, null,
                Items.TNT, Items.FISHING_ROD, Items.COBWEB, null, Items.EXPERIENCE_BOTTLE};
        int[] cnt = {9, 23, 3, 1, 1, 1, 41, 1, 37, 1, 1, 1, 1, 0, 1, 1, 0, 64, 18, 27, 11, 0, 8, 1, 14, 0, 16};
        ItemStack[] st = new ItemStack[N];
        long now = Util.getMeasuringTimeMs();
        long[] fl = new long[N];
        for (int i = 0; i < N; i++) st[i] = pool[i] == null ? ItemStack.EMPTY : new ItemStack(pool[i], Math.max(1, cnt[i]));
        long phase = now % 2600L;
        if (phase < 1100L) { fl[1] = now - phase; fl[18] = now - phase; }
        drawAt(ctx, tr, vw, st, fl, now);
    }
}
