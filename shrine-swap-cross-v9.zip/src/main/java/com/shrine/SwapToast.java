package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import static com.shrine.Gfx.*;

/** The card that slides in at the top when the swap happened: the item that is now in the hand and what was done. */
final class SwapToast {
    private SwapToast() {}

    private static ItemStack stack = ItemStack.EMPTY;
    private static String title = "", sub = "";
    private static long start;
    private static final long LIFE = 2600L;

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "swap_toast"), (ctx, tick) -> render(ctx));
    }

    /** @param item the item to show (may be empty); @param name title (null = the item's own name); @param subtitle the line under it */
    static void show(ItemStack item, String name, String subtitle) {
        stack = item == null ? ItemStack.EMPTY : item.copy();
        title = name != null ? name : (stack.isEmpty() ? "" : stack.getName().getString());
        sub = subtitle;
        start = Util.getMeasuringTimeMs();
    }

    private static void render(DrawContext ctx) {
        if (start == 0L) return;
        long age = Util.getMeasuringTimeMs() - start;
        if (age > LIFE) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        float in = Math.min(1f, age / 260f), out = age > LIFE - 500L ? Math.max(0f, (LIFE - age) / 500f) : 1f;
        float ein = 1f - (1f - in) * (1f - in), a = ein * out;
        if (a < 0.02f) return;
        float k = mc.getWindow().getScaledHeight() / Scene.REF_H, vw = mc.getWindow().getScaledWidth() / k;
        var tr = mc.textRenderer;
        boolean hasItem = !stack.isEmpty();
        float tw = Math.max(width(tr, Fnt.UI_B, title), width(tr, Fnt.SMALL, sub));
        float iconW = hasItem ? 52f : 0f, w = 20f + iconW + tw + 22f, h = 58f;
        float x = vw / 2f - w / 2f, y = 58f - (1f - ein) * 22f;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        box(ctx, RR, x, y, w, h, 20f, argb(0.78f * a, 0x0E0E12));                 // glass body
        box(ctx, RR, x + 1f, y + 1f, w - 2f, h * 0.45f, 19f, argb(0.06f * a, 0xFFFFFF));
        box(ctx, RR_RING, x, y, w, h, 20f, argb(0.60f * a, 0xFFFFFF));
        float tx = x + 20f;
        if (hasItem) {
            float cx = x + 20f + 21f, cy = y + h / 2f;
            centered(ctx, DISC, cx, cy, 42f, 42f, argb(0.14f * a, 0xFFFFFF));
            centered(ctx, RING, cx, cy, 42f, 42f, argb(0.35f * a, 0xFFFFFF));
            ctx.getMatrices().pushMatrix();
            ctx.getMatrices().translate(cx, cy);
            ctx.getMatrices().scale(1.5f, 1.5f);
            ctx.drawItem(stack, -8, -8);
            ctx.getMatrices().popMatrix();
            tx += iconW;
        }
        text(ctx, tr, Fnt.UI_B, title, tx, y + 23f, argb(a, 0xFFFFFF));
        text(ctx, tr, Fnt.SMALL, sub, tx, y + 42f, argb(0.55f * a, 0xFFFFFF));
        ctx.getMatrices().popMatrix();
    }
}
