package com.shrine;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ProgressScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Account > "Multi Account". The game window itself plays one account (the "main" one: {@link Accounts#current}); every other
 * account you connect stays on the same server as a background connection ({@link BotConn}). "Play as" swaps the roles: the
 * chosen account becomes the main one and the account you were playing stays online in the background.
 */
final class MultiAccount {
    private MultiAccount() {}

    static final String KEY = "multi.on", K_SWITCH = "multi.switch", K_RESPAWN = "multi.respawn", K_NEXT = "multi.next";
    static final int DEF_SWITCH = GLFW.GLFW_KEY_F8;

    /** account id -> its background connection (main thread only). */
    static final Map<String, Bg> BOTS = new LinkedHashMap<>();

    private record Creds(String name, UUID uuid, String token) {}

    private static boolean down, down2, busy;
    private static ServerInfo pendingServer;        // rejoin this server (as the new main account) once the old connection is gone
    private static long pendingAt;
    private static String joinedAs = "";

    static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(MultiAccount::tick);
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            ServerInfo now = client.getCurrentServerEntry();
            if (now != null) {
                List<String> drop = new ArrayList<>();
                for (Map.Entry<String, Bg> e : BOTS.entrySet()) if (!e.getValue().server.address.equals(now.address)) drop.add(e.getKey());
                for (String id : drop) { Bg b = BOTS.remove(id); if (b != null) b.stop(); }   // they belong to another server
            }
            if (!joinedAs.isEmpty()) {
                String n = joinedAs;
                joinedAs = "";
                client.execute(() -> { if (client.player != null) client.player.sendMessage(Text.literal("Multi Account: играешь за " + n), true); });
            }
        });
    }

    // ---------- state for the menu ----------
    static boolean isMain(Accounts.Acc a) { return a.id.equals(Accounts.current); }
    static Bg bot(Accounts.Acc a) { return BOTS.get(a.id); }
    static boolean busy() { return busy; }
    static int onlineBots() { int n = 0; for (Bg b : BOTS.values()) if (b.busy()) n++; return n; }

    private static boolean held(String cfgKey, int def) {
        int key = ShrineCfg.integer(cfgKey, def);
        if (key < 0) return false;
        long w = GLFW.glfwGetCurrentContext();
        if (w == 0L) return false;
        if (key >= 1000) return GLFW.glfwGetMouseButton(w, key - 1000) == GLFW.GLFW_PRESS;
        return GLFW.glfwGetKey(w, key) == GLFW.GLFW_PRESS;
    }

    static void say(MinecraftClient mc, String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("Multi Account: " + s), true);
    }

    static void tick(MinecraftClient mc) {
        boolean now = held(K_SWITCH, DEF_SWITCH);
        boolean edge = now && !down;
        down = now;
        boolean now2 = held(K_NEXT, -1);
        boolean edge2 = now2 && !down2;
        down2 = now2;

        for (Bg b : new ArrayList<>(BOTS.values())) b.tick();

        long ms = Util.getMeasuringTimeMs();
        // finishing a "Play as": once the old connection is gone, join the same server with the new session
        if (pendingServer != null) {
            if (ms - pendingAt > 20000L) { pendingServer = null; busy = false; return; }
            if (mc.world == null && mc.getNetworkHandler() == null && mc.currentScreen != null
                    && !(mc.currentScreen instanceof ConnectScreen) && ms - pendingAt > 900L) {
                ServerInfo si = pendingServer;
                pendingServer = null;
                busy = false;
                ConnectScreen.connect(mc.currentScreen, mc, ServerAddress.parse(si.address), si, false, null);
            }
            return;
        }

        if (!ShrineCfg.bool(KEY, false)) return;
        if (mc.player != null && ShrineCfg.bool(K_RESPAWN, true) && mc.player.isDead()) mc.player.requestRespawn();
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;
        if (edge2) { cycle(mc); return; }
        if (edge) mc.setScreen(new MultiAccountScreen());
    }

    // ---------- background accounts ----------
    private static Creds creds(Accounts.Acc a) throws Exception {
        switch (a.type) {
            case "licensed": {
                MsLogin.Result r = MsLogin.refresh(a.refresh);
                a.refresh = r.refresh(); a.name = r.name(); a.uuid = r.uuid().toString();
                Accounts.save();
                return new Creds(r.name(), r.uuid(), r.token());
            }
            case "launcher": {
                if (Accounts.original == null) throw new IllegalStateException("сессия лаунчера недоступна");
                return new Creds(Accounts.original.getUsername(), Accounts.original.getUuidOrNull(), Accounts.original.getAccessToken());
            }
            default:
                return new Creds(a.name, Accounts.offlineUuid(a.name), "");
        }
    }

    /** Connects {@code a} to the server the main account is on. */
    static void connectBot(MinecraftClient mc, Accounts.Acc a) {
        ServerInfo si = mc.getCurrentServerEntry();
        if (si == null) { say(mc, "сначала зайди на сервер"); return; }
        startBotOn(mc, a, si);
    }

    private static void startBotOn(MinecraftClient mc, Accounts.Acc a, ServerInfo si) {
        if (a.id.equals(Accounts.current)) return;                  // that one is the main account
        Bg old = BOTS.get(a.id);
        if (old != null && old.busy()) return;
        Thread t = new Thread(() -> {
            try {
                Creds c = creds(a);
                mc.execute(() -> {
                    BotConn b = new BotConn(mc, a, c.name(), c.uuid(), c.token(), si);
                    BOTS.put(a.id, b);
                    b.start();
                });
            } catch (Throwable e) {
                String why = Accounts.describe(e);
                mc.execute(() -> say(mc, a.name + ": " + why));
            }
        }, "shrine-bot-login");
        t.setDaemon(true);
        t.start();
    }

    static void connectAll(MinecraftClient mc) {
        Accounts.init();
        for (Accounts.Acc a : new ArrayList<>(Accounts.LIST)) if (!isMain(a)) connectBot(mc, a);
    }

    static void stopBot(Accounts.Acc a) {
        Bg b = BOTS.remove(a.id);
        if (b != null) b.stop();
    }

    static void stopAll() {
        for (Bg b : BOTS.values()) b.stop();
        BOTS.clear();
    }

    /** Chat as every connected account (the main one too). */
    static void chatEveryone(MinecraftClient mc, String text) {
        for (Bg b : BOTS.values()) b.sendChat(text);
        sendMain(mc, text);
    }

    static void sendMain(MinecraftClient mc, String text) {
        if (mc.getNetworkHandler() == null || text == null || text.isBlank()) return;
        if (text.startsWith("/")) mc.getNetworkHandler().sendChatCommand(text.substring(1));
        else mc.getNetworkHandler().sendChatMessage(text);
    }

    // ---------- "Play as" ----------
    /** The next account that is kept with its world, so that it can be shown at once (the quick-switch key). */
    static void cycle(MinecraftClient mc) {
        Accounts.init();
        List<Accounts.Acc> list = Accounts.LIST;
        int cur = 0;
        for (int i = 0; i < list.size(); i++) if (isMain(list.get(i))) cur = i;
        for (int i = 1; i < list.size(); i++) {
            Accounts.Acc a = list.get((cur + i) % list.size());
            Bg b = BOTS.get(a.id);
            if (b instanceof Sess s && s.canPromote()) { playAs(mc, a); return; }
        }
        say(mc, "нет другого аккаунта, сохранённого в мире");
    }

    /**
     * Puts {@code next} on the screen. The account that was playing is NOT disconnected: it stays on the server with its world
     * ({@link Sess}). If {@code next} is kept the same way the switch is instant; otherwise it is joined as usual.
     */
    static void playAs(MinecraftClient mc, Accounts.Acc next) {
        if (busy || isMain(next)) return;
        ServerInfo si = mc.getCurrentServerEntry();
        if (si == null) { say(mc, "работает только на сервере"); return; }
        final Accounts.Acc prev = Accounts.currentAcc();
        busy = true;
        say(mc, "перехожу на " + next.name + "…");
        Thread t = new Thread(() -> {
            String err = Accounts.activate(next);                   // the identity first (may talk to Microsoft: off the game thread)
            mc.execute(() -> {
                if (err != null) { busy = false; say(mc, err); return; }
                try {
                    switchNow(mc, prev, next, si);
                } catch (Throwable e) {
                    busy = false;
                    say(mc, "не удалось переключиться: " + e.getClass().getSimpleName());
                }
            });
        }, "shrine-multi-account");
        t.setDaemon(true);
        t.start();
    }

    private static void switchNow(MinecraftClient mc, Accounts.Acc prev, Accounts.Acc next, ServerInfo si) {
        Bg target = BOTS.get(next.id);
        Sess keep = prev == null ? null : Sess.demote(mc, prev, si);   // the account on the screen goes to the background, still online
        if (keep != null) BOTS.put(prev.id, keep);

        if (target instanceof Sess ts && ts.canPromote() && keep != null) {
            BOTS.remove(next.id);
            Sess.promote(mc, ts);                                       // instant: its world is already here
            busy = false;
            say(mc, "играешь за " + next.name);
            return;
        }

        boolean wasBackgroundBot = false;
        if (target != null) {                                           // a plain connection (or a broken one) of that account: it cannot be shown
            wasBackgroundBot = target.busy();
            BOTS.remove(next.id);
            target.stop();
        }
        joinedAs = next.name;
        pendingServer = si;
        pendingAt = Util.getMeasuringTimeMs() + (wasBackgroundBot ? 700L : 0L);
        if (keep != null) {
            mc.setScreen(new ProgressScreen(true));                     // the window is empty now; the old account stays on the server
        } else if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().getConnection().disconnect(Text.literal("Смена аккаунта"));
        }
    }
}
