package com.shrine;

import net.minecraft.client.network.ServerInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * An account that is on the server in the background (not the one the window plays). The menu reads these fields.
 * {@link BotConn}: only a connection (cannot be shown). {@link Sess}: a whole kept session with its own world and player,
 * which can be put on the screen instantly.
 */
abstract class Bg {
    enum State { CONNECTING, ONLINE, FAILED, STOPPED }

    final Accounts.Acc acc;
    final String name;
    final ServerInfo server;

    volatile State state = State.CONNECTING;
    volatile String error = "";
    volatile float health = -1f;
    volatile int food = -1;
    volatile int pingMs = -1;
    volatile String world = "", mode = "";
    final List<String> chat = Collections.synchronizedList(new ArrayList<>());

    Bg(Accounts.Acc acc, String name, ServerInfo server) {
        this.acc = acc;
        this.name = name;
        this.server = server;
    }

    boolean online() { return state == State.ONLINE; }
    boolean busy() { return state == State.CONNECTING || state == State.ONLINE; }
    /** True if "Play as" can show this account without leaving the world. */
    boolean instant() { return false; }

    abstract void tick();
    abstract void stop();
    abstract boolean sendChat(String text);

    void log(String line) {
        if (line == null || line.isBlank()) return;
        chat.add(line);
        while (chat.size() > 200) chat.remove(0);
    }
}
