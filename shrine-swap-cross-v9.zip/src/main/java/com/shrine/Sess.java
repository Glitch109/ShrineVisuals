package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.DisconnectionInfo;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.text.Text;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Proxy;
import java.util.Locale;

/**
 * A whole kept session: the connection, the game's own network handler and the world and player it built. When the window leaves
 * an account, nothing is closed or unloaded: the account's packets are routed through a wrapper that applies each of them with the
 * game's globals pointing at THIS account's world and player (see {@link BgCtx}), and the world, player and interaction manager
 * are kept here. Putting the account back on the screen is then a swap of those references, so it takes no joining at all.
 */
public final class Sess extends Bg {
    private final MinecraftClient mc;
    final ClientConnection conn;
    final ClientPlayNetworkHandler handler;
    private volatile ClientWorld sWorld;
    private volatile ClientPlayerEntity sPlayer;
    private volatile ClientPlayerInteractionManager sIm;
    private volatile boolean fg;
    private ClientPlayPacketListener wrapper;
    private ClientWorld savedWorld;
    private ClientPlayerEntity savedPlayer;
    private ClientPlayerInteractionManager savedIm;
    private int ticks;

    private Sess(MinecraftClient mc, Accounts.Acc acc, ServerInfo server, ClientConnection conn, ClientPlayNetworkHandler handler,
                 ClientWorld world, ClientPlayerEntity player, ClientPlayerInteractionManager im) {
        super(acc, acc.name, server);
        this.mc = mc;
        this.conn = conn;
        this.handler = handler;
        this.sWorld = world;
        this.sPlayer = player;
        this.sIm = im;
        this.state = State.ONLINE;
        refresh();
    }

    @Override boolean instant() { return true; }

    // ---------- taking the account off the screen / putting it back ----------
    /**
     * The window is about to leave the account on the screen. It stays on the server with its world; the window is left empty
     * (no world, no player) so that another account can be joined or put on. Returns null if that is not possible.
     */
    static Sess demote(MinecraftClient mc, Accounts.Acc acc, ServerInfo server) {
        ClientPlayNetworkHandler h = mc.getNetworkHandler();
        if (h == null || mc.player == null || mc.world == null || mc.interactionManager == null) return null;
        ClientConnection c = h.getConnection();
        if (c == null || !c.isOpen()) return null;
        try {
            Sess s = new Sess(mc, acc, server, c, h, mc.world, mc.player, mc.interactionManager);
            if (!s.install()) return null;
            mc.getPacketApplyBatcher().apply();          // what the game had queued for it is applied while it is still on the screen
            mc.player = null;
            mc.world = null;
            mc.interactionManager = null;
            mc.setCameraEntity(null);
            s.fg = false;
            return s;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Puts the kept account on the screen. The window must be empty (see {@link #demote}). */
    static void promote(MinecraftClient mc, Sess s) {
        mc.joinWorld(s.sWorld);                          // the game's own way of showing a world (renderer, particles, camera)
        mc.player = s.sPlayer;
        mc.interactionManager = s.sIm;
        mc.setCameraEntity(s.sPlayer);
        s.uninstall();                                   // the game handles its packets by itself again
        s.fg = true;
        mc.setScreen(null);
    }

    boolean canPromote() { return state == State.ONLINE && sWorld != null && sPlayer != null && sIm != null && conn.isOpen(); }

    // ---------- the listener wrapper ----------
    private boolean install() {
        PacketListener cur = conn.getPacketListener();
        if (cur != handler) return false;
        wrapper = (ClientPlayPacketListener) Proxy.newProxyInstance(Sess.class.getClassLoader(),
                new Class<?>[]{ClientPlayPacketListener.class}, (self, m, a) -> dispatch(self, m, a));
        return setListener(handler, wrapper);
    }

    private void uninstall() {
        if (wrapper != null) setListener(wrapper, handler);
        wrapper = null;
    }

    /** Swaps the connection's packet listener (found by value, so no field name is needed). */
    private boolean setListener(PacketListener from, PacketListener to) {
        for (Field f : ClientConnection.class.getDeclaredFields()) {
            if (Modifier.isStatic(f.getModifiers()) || f.getType() != PacketListener.class) continue;
            try {
                f.setAccessible(true);
                if (f.get(conn) == from) {
                    f.set(conn, to);
                    return conn.getPacketListener() == to;
                }
            } catch (Throwable ignored) { }
        }
        return false;
    }

    private Object dispatch(Object self, Method m, Object[] a) throws Throwable {
        if (m.getDeclaringClass() == Object.class) {
            return switch (m.getName()) {
                case "hashCode" -> System.identityHashCode(self);
                case "equals" -> self == a[0];
                default -> "Sess(" + name + ")";
            };
        }
        int n = a == null ? 0 : a.length;
        if (m.isDefault() && n == 2 && a[0] instanceof Packet<?> && a[1] instanceof Exception e && !fg) {
            problem(e);                                  // a broken packet of an account that is not on the screen must not crash the game
            return null;
        }
        if (!m.isDefault() && n == 1 && a[0] instanceof DisconnectionInfo info) {
            if (fg) return call(m, a);                   // on the screen: the game shows its usual "disconnected" screen
            if (state != State.STOPPED && state != State.FAILED) {
                error = info.reason().getString();
                state = State.FAILED;
            }
            return null;
        }
        if (!m.isDefault() && n == 1 && a[0] instanceof Packet<?> && m.getReturnType() == void.class) {
            mc.execute(() -> run(m, a));                 // like the game: handle it on the main thread, in order
            return null;
        }
        return call(m, a);
    }

    private Object call(Method m, Object[] a) throws Throwable {
        try {
            return m.invoke(handler, a);
        } catch (InvocationTargetException e) {
            throw e.getCause() == null ? e : e.getCause();
        }
    }

    private void run(Method m, Object[] a) {
        if (state == State.STOPPED || state == State.FAILED && !fg) return;
        try {
            if (fg) {
                m.invoke(handler, a);
            } else {
                enter();
                try {
                    m.invoke(handler, a);
                } finally {
                    exit();
                }
            }
        } catch (InvocationTargetException e) {
            problem(e.getCause());
        } catch (Throwable t) {
            problem(t);
        }
    }

    private void problem(Throwable t) {
        if (t == null || "OffThreadException".equals(t.getClass().getSimpleName())) return;
        if (state == State.STOPPED) return;
        error = "ошибка: " + (t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
        if (!fg) {
            state = State.FAILED;
            try { conn.disconnect(Text.literal(error)); } catch (Throwable ignored) { }
        }
    }

    // ---------- the game's globals point at this account while its packets are applied ----------
    private void enter() {
        savedWorld = mc.world;
        savedPlayer = mc.player;
        savedIm = mc.interactionManager;
        mc.world = sWorld;
        mc.player = sPlayer;
        mc.interactionManager = sIm;
        BgCtx.cur = this;
        BgCtx.active = true;
    }

    private void exit() {
        BgCtx.active = false;
        BgCtx.cur = null;
        sWorld = mc.world;                               // the game may have created a new world or player (joining, changing dimension)
        sPlayer = mc.player;
        sIm = mc.interactionManager;
        mc.world = savedWorld;
        mc.player = savedPlayer;
        mc.interactionManager = savedIm;
        savedWorld = null;
        savedPlayer = null;
        savedIm = null;
    }

    // ---------- Bg ----------
    @Override
    void tick() {
        if (fg || state == State.STOPPED) return;
        try {
            conn.tick();
            if (state == State.FAILED) return;
            enter();
            try {
                handler.tick();
            } finally {
                exit();
            }
            if (++ticks % 10 == 0) refresh();
        } catch (Throwable t) {
            problem(t);
        }
    }

    private void refresh() {
        ClientPlayerEntity p = sPlayer;
        if (p == null) return;
        health = p.getHealth();
        food = p.getHungerManager().getFoodLevel();
        PlayerListEntry e = handler.getPlayerListEntry(p.getUuid());
        pingMs = e == null ? -1 : e.getLatency();
        if (sWorld != null) world = BotConn.dimName(sWorld.getRegistryKey());
        if (sIm != null) mode = sIm.getCurrentGameMode().name().toLowerCase(Locale.ROOT);
    }

    @Override
    void stop() {
        if (state == State.STOPPED) return;
        state = State.STOPPED;
        try { conn.disconnect(Text.literal("Multi Account: отключён")); } catch (Throwable ignored) { }
        sWorld = null;
        sPlayer = null;
        sIm = null;
    }

    @Override
    boolean sendChat(String text) {
        if (state != State.ONLINE || text == null || text.isBlank() || sPlayer == null) return false;
        enter();
        try {
            if (text.startsWith("/")) handler.sendChatCommand(text.substring(1));
            else handler.sendChatMessage(text);
        } finally {
            exit();
        }
        return true;
    }

    /** Line for the menu's chat view (called from the chat mixin while this account's message arrives). */
    public void incoming(String line) { log(line); }
}
