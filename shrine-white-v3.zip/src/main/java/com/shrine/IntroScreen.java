package com.shrine;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;

/**
 * Takes over when the game has finished loading and lets the launch animation ({@link BootFx}) play on until its end:
 * logo -> particle cloud -> particle logo -> melt -> flash -> menu. Click / any key skips the waiting.
 */
public final class IntroScreen extends Screen {
    private final Screen next;

    public IntroScreen(Screen next) {
        super(Text.literal("Shrine"));
        this.next = next;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        BootFx.release();
        BootFx.draw(ctx);
        if (BootFx.finished()) {
            ctx.fill(0, 0, width, height, 0xFFFFFFFF);   // no empty frame: it would show the vanilla background
            BootFx.handoff();
            client.setScreen(next);
        }
    }

    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) { BootFx.skip(); return true; }

    @Override
    public boolean keyPressed(KeyInput input) { BootFx.skip(); return true; }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean shouldPause() { return false; }
}
