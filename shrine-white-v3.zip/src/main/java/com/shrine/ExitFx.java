package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

/**
 * "Leaving a world" animation (like the reference video): the moment you leave, the last game frame shrinks into a
 * window in the middle of the screen (it covers the "Saving world" / progress screen instead of showing a loading
 * screen), then the server / world screen opens and the window flies into the tile of the world we just left.
 */
final class ExitFx {
    private ExitFx() {}

    static boolean active;                 // the animation is playing on the current screen

    private static final Identifier TEX_ID = Identifier.of("shrine", "exit/shot");
    private static String kind, key;       // what we joined last: "server" + address, or "world" + folder name
    private static long capturedAt, startedAt;
    private static boolean fresh;
    private static volatile NativeImage pending;
    private static boolean registered;

    /** Called when the player presses "Играть". */
    static void remember(String k, String id) { kind = k; key = id; fresh = false; active = false; }

    private static final float SHRINK_MS = 450f;

    /** True from the moment we left a world until the menu has taken over (or 15 s passed). */
    static boolean holding() { return fresh && kind != null && Util.getMeasuringTimeMs() - capturedAt <= 15000L; }

    /** 0 = full screen, 1 = small window in the middle. */
    private static float shrink(long now) { return ease((now - capturedAt) / SHRINK_MS); }

    /** Called when the connection closes: the framebuffer still holds the last game frame. */
    static void capture(MinecraftClient mc) {
        if (kind == null) return;
        release(mc);
        capturedAt = Util.getMeasuringTimeMs();
        fresh = true;
        try {
            ScreenshotRecorder.takeScreenshot(mc.getFramebuffer(), 2, img -> pending = img);
        } catch (Throwable t) {
            pending = null;
        }
    }

    /** @return the remembered key if we have just left a world of this kind (and starts the animation). */
    static String take(String k) {
        if (!fresh || !k.equals(kind) || Util.getMeasuringTimeMs() - capturedAt > 15000L) return null;
        fresh = false;
        active = true;
        startedAt = 0;
        return key;
    }

    private static float ease(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return x < 0.5f ? 4f * x * x * x : 1f - (float) Math.pow(-2f * x + 2f, 3) / 2f;
    }

    private static Identifier texture(MinecraftClient mc) {
        NativeImage img = pending;
        if (img != null) {
            pending = null;
            try {
                mc.getTextureManager().registerTexture(TEX_ID, new NativeImageBackedTexture(() -> "shrine exit", img));
                registered = true;
            } catch (Throwable t) {
                registered = false;
            }
        }
        return registered ? TEX_ID : null;
    }

    private static void release(MinecraftClient mc) {
        pending = null;
        if (registered) {
            try { mc.getTextureManager().destroyTexture(TEX_ID); } catch (Throwable ignored) { }
            registered = false;
        }
        active = false;
        startedAt = 0;
    }

    /**
     * Drawn over the intermediate "Saving world" / progress screen: dark background and the game frame shrinking into
     * a window in the middle. Works in GUI units (w x h), it sets up the virtual canvas itself.
     */
    static void overlay(DrawContext ctx, MinecraftClient mc, int w, int h) {
        Identifier id = texture(mc);
        if (id == null) return;                      // screenshot not read back yet: leave the vanilla screen for a frame
        Gfx.cover(ctx, w, h);
        float k = h / Scene.REF_H, vw = w / k;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        card(ctx, id, vw, vw / 2f, Scene.REF_H / 2f, shrink(Util.getMeasuringTimeMs()), 1f);
        ctx.getMatrices().popMatrix();
    }

    /** s = shrink progress (0 full screen .. 1 window), a = opacity. cx, cy = centre of the card. */
    private static void card(DrawContext ctx, Identifier id, float vw, float cx, float cy, float s, float a) {
        float cw = 230f, ch = cw * Scene.REF_H / vw;
        float W = vw + (cw - vw) * s, H = Scene.REF_H + (ch - Scene.REF_H) * s;
        Gfx.centered(ctx, Gfx.GLOW, cx, cy, W * 1.3f, H * 1.5f, Gfx.argb(0.30f * s * a, Gfx.ACCENT));
        Gfx.blit(ctx, id, Math.round(cx - W / 2f), Math.round(cy - H / 2f), Math.round(W), Math.round(H), Gfx.argb(a, 0xFFFFFF));
        Gfx.box(ctx, Gfx.RR_RING, cx - W / 2f - 2f, cy - H / 2f - 2f, W + 4f, H + 4f, 30f * s + 2f, Gfx.argb(0.55f * s * a, 0xFFFFFF));
    }

    /** Draws on the virtual canvas, over the menu. tx..th = the selected tile the window flies into. */
    static void draw(DrawContext ctx, MinecraftClient mc, float vw, float tx, float ty, float tw, float th) {
        if (!active) return;
        long now = Util.getMeasuringTimeMs();
        if (startedAt == 0) startedAt = now;
        float t = (now - startedAt) / 1000f;
        Identifier id = texture(mc);
        if (t > 0.85f || (id == null && t > 0.5f)) { release(mc); return; }
        if (id == null) return;

        float s = shrink(now);                       // continues from the window if the overlay already shrank it
        float p = ease(t / 0.50f);                   // flight to the tile
        float a = 1f - ease((t - 0.48f) / 0.32f);
        float cx = vw / 2f + (tx + tw / 2f - vw / 2f) * p, cy = Scene.REF_H / 2f + (ty + th / 2f - Scene.REF_H / 2f) * p;
        card(ctx, id, vw, cx, cy, s, a);
    }
}
