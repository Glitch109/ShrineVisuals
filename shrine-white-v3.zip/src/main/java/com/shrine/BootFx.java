package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Random;
import java.util.zip.CRC32;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;

/**
 * Launch animation (replaces the red Mojang overlay), white only, built from the reference launch video:
 *
 *   A  0.0 - 1.6 s   our logo on black with a soft glow, then it shrinks / squeezes into a white core
 *   B  1.4 - 3.2 s   the core bursts into a spherical cloud of fine dust that swirls and breathes
 *   C  3.0 - 4.9 s   the cloud collapses into a bright core (flash), then blooms into the logo made of particles;
 *                    a horizontal band of dust spreads across the screen
 *   D  hold          the particle logo shimmers with a glowing contour (until loading is done, at least {@link #holdMin} s)
 *   E  melt + flash  the logo melts / fragments, the screen whites out, then the menu (light beam + dust) fades in
 *
 * Everything is drawn procedurally in framebuffer pixels (so dust is 1-2 px fine at any GUI scale). The only textures
 * are generated in memory (the resource pack is not loaded yet while the game starts).
 */
public final class BootFx {
    private BootFx() {}

    private static final Identifier SOFT = Identifier.of("shrine", "boot/soft");
    private static final Identifier LOGO_T = Identifier.of("shrine", "boot/logo");
    private static boolean tried, ready, logoReady;
    private static long start, last, eStart, handoffAt;
    private static boolean released;
    private static float holdMin = 5.6f;

    // ---- adaptive quality: every dot / glow is a separate GUI element, so when frames get slow we draw fewer of them ----
    private static int stride = 2;           // 1 = every particle, 2 = every second, 3 = every third
    private static float avgDt = 16f;
    private static int stableFrames;

    // ---- timeline (seconds) ----
    private static final float SHRINK0 = 0.95f, SHRINK1 = 1.55f;
    private static final float BURST = 1.45f, SWIRL_END = 2.8f;
    private static final float COLLAPSE0 = 3.0f, COLLAPSE1 = 3.85f, BLOOM0 = 3.85f, BLOOM1 = 4.85f;
    private static final float MELT = 1.1f, FLASH0 = 0.65f, END = MELT + 0.05f;

    // ---- our logo (96x96 1-bit mask for the particle targets, PNG for the solid logo) ----
    private static final int M = 96;
    private static final String MASK =
            "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000" +
            "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000" +
            "000000000000000000000000000000000000000000000000004000000000000000000100006000000000000000000200" +
            "003000000000000000000600001800000000000000000c00000c00000000000000001800000600000000000000003000" +
            "00030000000000000000600000038000000000000001c0000001c00000000000000380000000e0000000000000070000" +
            "0000700000000000000e00000000380000000000001c000000001c00000000000038000000000e000000000000700000" +
            "000007000000000000e00000000003800000000001e00000000003c00000000003c00000000001e0000000000f800000" +
            "000000f0000000001f00000000000078000000003e0000000000003c000000007c0000000000001e00000000f8000000" +
            "0000000f00000001f00000000000000780000003e000000000000003c0000007c000000000000001e000000f80000000" +
            "00000000f000001f00000000000000007800003e00000000000000003c00007c00000000000000001e0000f800000000" +
            "000000001f0001f000000000000000000f8003e00000000000000000078007c0000000000000000001e00f0000000000" +
            "0000000000f00e00000000000000000000783c000000000000000000003c7c000000000000000000001ff80000000000" +
            "00000000000ff0000000000000000000000fe00000000000000000000007e0000000000000000000000ff00000000000" +
            "00000000001ff8000000000000000000003e7c00000000000000000000783c00000000000000000000f03e0000000000" +
            "0000000001e01f00000000000000000003e00f80000000000000000007c007c000000000000000001f8003e000000000" +
            "000000001f0001f000000000000000003e0000f80000000000000000780000780000000000000000f000003c00000000" +
            "00000001e000001e0000000000000003c000000f000000000000000780000007800000000000000f00000003c0000000" +
            "0000001e00000001e00000000000003c00000000f0000000000000780000000078000000000000f0000000003c000000" +
            "000001e0000000001e000000000003c0000000000f00000000000780000000000700000000000f000000000003800000" +
            "00001c000000000001c00000000038000000000000e000000000700000000000007000000000e0000000000000380000" +
            "0000c00000000000001c00000001800000000000000e0000000300000000000000060000000600000000000000010000" +
            "000800000000000000008000001000000000000000004000002000000000000000002000000000000000000000000000" +
            "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000" +
            "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
    private static final String LOGO_PNG =
            "iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAQEElEQVR4nO2debBcVRHGv3nzEtZAEoKEHapYVGSTRQ0KBhAX" +
            "EDcwCoIoKptIKSioVCkGURAFFQtBBAQCWAYsF0RQRAwKiBFFAdkEApYkBTEiJEDy3s8/+nSd8y5vm3kzc+/cuV3VNcmbM/f2" +
            "6a/P3qe7Bqii3qW+vAWoKF+qDKDHqTKAHqfKAHqcKgPocaoMoMepMoAep9EMoE/SpE4JUlE+NJoB1CRNlbTxGOUqKjZNldQ/" +
            "0pejATsgabmkHSXt3lqZKmoz1cLnTElbahScx+oBnpN0n6T9JO2deXhFxaQ+SUjaQAb+g5JeHK3wSIQM7EckXS/pTZL2Cn/v" +
            "H+O3FeVDNUmDMvBfKekfkp4d7Qcjjg2B3AjulAF+UPjb78JvCVxRvuS9MpJ2k/RGST+T9J/w3YgYjacVuxHcIek2SSdKOlLS" +
            "6sl3FeVHNUWQ3yzp05IekHS/xgBfGrsHyL7oOkmbhpcMSrpMNlkc80UVtYVc78iG6OMkXSrpJxonJuM1AG/pL0i6WNLLJB0t" +
            "aT1JF0p6ZrwvrKhl5PpeS9I7ZODfJOlaNYBFIz2AP/B/kr4qaQ1Jp8rWmWdLWiYbUgYbeGZFzZHreYqkz0r6gKQLZI2xoSG5" +
            "EQNwqsmM4Nuy4eATQaBvSHpKVU/QbvKZ/lRJJ0k6WQb+ubJle0P6b8YAkFSXLQ8/F55xnKR1JH1Ttu6sqD3k4G4v6RRJ75V0" +
            "uaQvqAnwJUlAs9wXPrcD7sToZuDN4bvaBJ5d8VCuJfreBfh90PeFwIykTMPPnqhgDvR7gYeCUAuBtyZCVYYwcfD9368GFgQ9" +
            "/wbYLMGhqee3SsB+4P3AoiDcn4B9hqlAxc2BPxl4C/C7oN+/AXszQfBpoQEIM4IvAS8EIf8UhK6Gg4npdXXgBODJoNe7aWHj" +
            "arWwGwHnASuCsH8G9g3fTchSe4zTRnU8sCzo82+0uGdth9DrA+cQjWABsDOVETSqx8nAscB/gh7voQ3DaquFd4A3Aq4Pgg8C" +
            "vwR2SISvhoTRwV8POJkI/jLg4Hborx2VcCOYja0IAAaAnwPbF0DJRWUHdUtgHvB80N1ybG61Nm1oPO2uzJ7AbaEiq7D163uw" +
            "sS0t1+vsetgGuIZIK4DTgCnt0lcnKjULWxE4PQ4cAdTbVakuY+8xtwF+luhpBXA6sFY79dSpyh0CPJVUbhFwaFKpXjeCWcAN" +
            "QTeD2FL6DGDdduun3RXzMWsKcAqwlEiLgMPozeEgXea9jdhDDmItfy6wTif00snKroEZwTNEWkTvDQe1hN+HDYlgc6TnsZbf" +
            "1m4/5U5WWqFiX8CWNQOh4ouwIaIvU7aM7MD3YZPhR4MOVobPq7AloOjQnkmnKy9sOfM1zABSI/ggMClTtkzsdeoDDgeeCHV3" +
            "8G9m6F5JR+TKSwlbETeKVoXPJ4APUc6ewOuyJgb+4lBnB/9W4m5pR+udpzJ2Am4KCvCe4HHsVLFMRuB12RDbIveJsIO/ANgt" +
            "U7bUBpACuwNwHTb79Z7gMWx1UIbhwAGdCVwc6gkR/FuAHfOsZ57K8Qq/injO7UbwODYn6OaewGV/GXA+1sulhn4r5t2Ta/2K" +
            "oqQ5wJKgGFeQrw66cYmYdvsXhDql4N8C7Jop25MG4MuiycBHiTPj1AgOp7uGg9Q34hIieZ0WkMNsfyTOW1mpEiYBRxI9X1Ij" +
            "OCwpl7vSxlGf3YDLeWm3/wfgNUWqR+4CZJTRDxzN8EZwKMXdNk6PafcD7gpyZ7v9V4cyhXGMyV2AjBJTI3g6KC41giMo5nDg" +
            "sswG/h7kHSQubxdj7vKFAh8o1B1/v3+4StI8SRfJrjfXZTdhNpU0V9IcxQsQRbiZnF7W+Lyk7WTyIrsxdZ+kL8qu1Bfv1lTe" +
            "FjhKi1ob+DTwbGhF6T6BDwd5updlu/07gnwDiax3AXtQsFafcu4CjKJcYbdeLiFOptIdwyPIb06Qgr8vw3f7T2MrmGydCsW5" +
            "CzCGkoX5yF1F3EVLD5DycipJwf9LIlcK/qewI/BCO8HmLsA4Fb0ZcCVxQyU1gnTbuBPypN3+PUGOFPzFmDv36pk6FJJzF2Ac" +
            "7OPn5sAViaL98wngw3RmTpC2/OHAfwo4juIuV7vSAFJFbk4cDtKe4F/YdnK7lJ7uWM4hjvk+NwF4GAO/K1q+c+4CNMBpT3AV" +
            "dqKWGsH9wLRQrtWzbn/egUQXrrTl3wsc0Ib3tp2LtA8wFg3K1tWPycKizA9/872DbSR9LPyt3sL3ekSOfSR9WdImioGx+mSx" +
            "+I6R9PNEnu6hvC1wAq3xlcS196rAy4F3h+/rLXzXbgwd832LdyHm2ycKPtsfiXMXoEl2Rb8TG3shrhAGsZNFESdjzYJfw3zz" +
            "Fybv8E2eXwLbJmXz1klTXINi7UyOk2rJ58GSzpS0uaSVsphFK2Rbso+G/69q4vn18LtrJL07eUa/pIWSDpd0r7o8Mlo3zQFS" +
            "cqsdlAF0rKQ/y/IbrJS0piy+8VYy4BoNhuVGc6qGB/8glQB8SV07BAw3HKyGrQ4gRil5DHM5a2Q48HJHh2esBF4M//4hdkYh" +
            "WjPHyJ1zF6BF7GD0Eb1w/Hr1YuANRHBHm6j5juKx4beriA6cFyflunbMz3LuArSQ/caNgG8G0NwIXsS2jL1ctvWmf/tw+M0q" +
            "Ysv/DhH40oBPyQwgC+Q5ATzfMAL4OrGV9/NSYzg5lBsggn81EfyuW+aNxbkL0AZOQT0tgJgu324jumY5TwYuC98PELv9u7Fl" +
            "YOlavnO3LgPHIt+lG5CFU71a0UvHl4mfk3SlLLPGGZJeF8pLtgR8WBaC/RGVYbY/ApXVAJx8WXiWLMfBKhmYvvxdJgu6LBn4" +
            "fTLjWSLpEFn49bqiYZSOym4AvqFTl3S7pJ0U9+v9zMATLnjmjSUyY7kiPKPUaXHKbgBS7L63lPRbmXOpO2w68K6EZyQdLxsa" +
            "BlVi4J26dSewERqUjfuPyEKsp6d1abKlmqR/S7pZJR3vh6NeMACnusxFW3ppvb032ErS/iqOy3nbqRcMwA91BmRju8K/ST6l" +
            "uEI4RdIrFP0PSk1lr6DP4FeTpbg5RLF79wliTXEFMChpC1kOpOnqRgePBqnMBtAvA3YX2Qrg44oTu7pswnebpCcVVwNuBG+T" +
            "pWFZLTyrtEZQVgPw49xZsrX8TuH/vvSbL0uKPSt8d77i0tA/j5UZTannA2VcBjr4u0u6UdK6Gnqef74MXGnoDt+vJO2roRtC" +
            "z8rO/m9Qc44lhaey9QAO0q6SfiEDfyD57rsy8OuK4PfLwP6WhgI8KGltmcHsFL5rpbNpIahMBjBJsdu/UZbVNAX/Apn3rt82" +
            "9pbvZTzrpoOcbiDdKGl2KFsqIyiLAdRle/6zZa5g0xRdt+uSfixLdeugpuOe/3u5pHNk7t2+O+gHSuvLdgc3VBwiSkHdXhEH" +
            "eEDSYbKU6esogtQn2/49LvnNcJMen+jdLukjiilYfdI4IGmmrIeYpnhu0P2U93n0BDg9nz+TSOl1rTRf0XicOfyZMzC3b4h+" +
            "BO4jcH0oMxGX88Jw7gI0yWkEcgc/vaoFFpBpj0z5RgxrTyxLF8lz3UvoBEpiBLkL0AQ7mFsA8xOA0lvDPwF2z5Rv5h17EY0g" +
            "jfU3gF1K6XojyF2ABjkNwPi9AIyD75k2vo8Fo24W/KwR7EvMiJoNAuFG1rXuYt00CUzTpn9S0qGKEzrfuJkv6TRJDyme8DVL" +
            "vgr4taQjFV3DCHJMl3SpbMOpe88M8rbABlvj+phnr7t7e2t8HvgGNixMtOWP1OvMBh4M7/NhAGyImJUp2zWcuwDjYPfw3QyL" +
            "u+sTMQfgBSwBxTRaD74yz9yZ4Y3gdiY256gMYAR2d+zpmJ+/L8Vc8SuAs7Blm5dvpyzC0rcOZwS3ULAwsOPh3AUYh8JnAGcT" +
            "7/ul4J9Bh7JrZWR6AzFMTGoEvyfeReyK4aCok0Cf8M2QeegcL2myopfO85LOkzluPKOJT/jGSz7ZWyDpQ5LuUPQlGJSdQ3xM" +
            "0hR1y8Qwbwschr0lT8XGdp/w+Y5cttvPo7v11r0dNv5DXIr+F8v4OTVH+cbNuQuQYVfWegzt9h385cBX6Gy3P5YR7MHQMLEu" +
            "59dp78S0dAbgSprO8OAvw8DPs+WPJPMbiSHi06Xp6cR4AkWQt7AGMFa3/0/gGGIu3SJNsFz2fYA7M3IvBY7HglcU0ghyF4Ch" +
            "mzzDgZ+NwVc4JSYy7QH8MSP/IiwfYp0CRhLLWwBXxhSsu8yCfx8GfrZ8Edll25s4HHg9HgDenpQrTD2KoLAaFpUjmyHkfiL4" +
            "hVHYOOu0N7En8DnB37ETxELFFspbWZOAg4BHgpLSRAsp+N1iAKkR7EWML+hG8AAWWLIwASfyUpDzwdgEL1XSj7B99UK1lCbq" +
            "6EYwHxvavH4LidlCczeCPA3gQGKUT1fOFcAmGSV2K7v8G2GHWCuJ6WSuoD0nl4U2gLTl78/QA5VBzJGjLOA7ewvfFksVS6jr" +
            "SmAelg0l1/p2GnxhY/u9iTIAfkD5wM/WfTY2HKwIdV4JXApsnGe9O62EA4CHiPQslli5rOCn9ReWRfw7DI1fOBdzbs2l/p14" +
            "icfXez0Wds3pSeBEirW12249CNgA82f0re5/AUeRU0LMTlX6VcBNRFpCzPPTC+Bn9bEpZgTeE/huYcf10c6HeyU2Ba4h0mNY" +
            "Pr1eAz+rlw2A84hG8DjwEWw46NjysN2V3BgLsux0F7bxU8+U6zV2gGcCFxGN4GFsFzEt03UGkLb8S4i7e78BXlsA5ReFXU+b" +
            "AKcSN8SuxxxN0jJdYwAu8IbA5UT6KfDyAii9aJyeh7yPuDF2HbB9pkxbuNFMGqORX6muS/qA7OKGZNe1T5L0gIYGZaxoaPiZ" +
            "H8l09yVZjKLFkk6UZVBvm95aZQAu4CRZJK6TZOFV5smic1Xgj0xuBAOSfigLcvFVWWiaB2WRS55Tu/TXwm6sji1llmI+cSeQ" +
            "4wZHF3I6HMwBHsU2yj4DrEWbTkVb8ZA+bBPj/ZhH7Aos8UJXpVAtCDvI/Vhm9EWYL+TB7dLlRKOEebd0gKSLJT0l676ulQ0B" +
            "VbffPNUlvUuWuew5WX6DW9RinU7EAFyQ7WWXNNaSdJQsrVr6fUWNU6q7HWUTw41kt6JvVQsTWDR7M8gF3FbSV8JzPiEDv08V" +
            "+BMl111N0l9lBrBM0smycPctu3XUTA/g4O4o6TNBmHNl4FfAt568tW8tu472P9lwu1gt0HejBuAv3FrSXEmLZGP+0lYIU9GI" +
            "5LpdU9LnZfck58ruRU5I740OAcgidBwkS6p0pirwO0EerWS5pMtlQaz3VAsuxTbaA6wnS6ggWUDFCvzOkut6piwc7lLZ0PtC" +
            "0w9swAD6JO0s2+27Qy/Nt1NRZ8h1vrYsPtE/ZVnSm3vYOA2gJovAuZqkpxXDsFbg50Ou+9VlsQj+K+nFph7UQA9Q6vx5XUw+" +
            "D2iqMZYxX0BFDVBRQ8RU1CGqDKDHqTKAHqfKAHqcKgPocaoMoMepMoAep/8DuLl+KgXWBxEAAAAASUVORK5CYII=";

    private static final int NL = 1800, ND = 500;
    private static final float[][] LP = new float[NL][10];   // hx, hy, edge, ang, radF, phase, size, bright, r1, r2
    private static final float[][] DP = new float[ND][7];    // fx, fy, bandU, bandV, phase, size, speed
    static {
        boolean[] on = new boolean[M * M];
        for (int i = 0; i < M * M / 8; i++) {
            int v = Integer.parseInt(MASK.substring(i * 2, i * 2 + 2), 16);
            for (int j = 0; j < 8; j++) on[i * 8 + j] = ((v >> (7 - j)) & 1) != 0;
        }
        boolean[] fat = on.clone();               // thicken the thin blades once so the particle logo reads well
        for (int y = 1; y < M - 1; y++)
            for (int x = 1; x < M - 1; x++)
                if (on[y * M + x]) { fat[y * M + x - 1] = true; fat[y * M + x + 1] = true; fat[(y - 1) * M + x] = true; fat[(y + 1) * M + x] = true; }
        on = fat;
        List<int[]> edge = new ArrayList<>(), fill = new ArrayList<>();
        for (int y = 0; y < M; y++) {
            for (int x = 0; x < M; x++) {
                if (!on[y * M + x]) continue;
                boolean e = x == 0 || y == 0 || x == M - 1 || y == M - 1
                        || !on[y * M + x - 1] || !on[y * M + x + 1] || !on[(y - 1) * M + x] || !on[(y + 1) * M + x];
                (e ? edge : fill).add(new int[]{x, y});
            }
        }
        if (fill.isEmpty()) fill.addAll(edge);
        Random r = new Random(21L);
        for (int i = 0; i < NL; i++) {
            float[] p = LP[i];
            boolean isEdge = i < NL * 0.55f && !edge.isEmpty();
            int[] c = (isEdge ? edge : fill).get(r.nextInt((isEdge ? edge : fill).size()));
            p[0] = (c[0] + r.nextFloat()) / M * 2f - 1f;
            p[1] = (c[1] + r.nextFloat()) / M * 2f - 1f;
            p[2] = isEdge ? 1f : 0f;
            p[3] = r.nextFloat() * 6.2832f;
            p[4] = (float) Math.pow(r.nextFloat(), 0.62);
            p[5] = r.nextFloat() * 6.2832f;
            p[6] = 0.8f + r.nextFloat() * 1.7f;
            p[7] = 0.35f + 0.65f * r.nextFloat();
            p[8] = r.nextFloat(); p[9] = r.nextFloat();
        }
        for (float[] d : DP) {
            d[0] = r.nextFloat(); d[1] = r.nextFloat();
            d[2] = r.nextFloat() * 2f - 1f;
            d[3] = (float) r.nextGaussian();
            d[4] = r.nextFloat() * 6.2832f;
            d[5] = 0.7f + r.nextFloat() * 1.3f;
            d[6] = 0.3f + r.nextFloat();
        }
    }

    // ---------- control (called by IntroScreen) ----------
    /** Loading is finished: the animation may leave the "hold" phase once it has played long enough. */
    public static void release() { released = true; }

    /** Skip: jump to the held logo (if earlier) and leave at once. */
    public static void skip() {
        released = true;
        float t = (Util.getMeasuringTimeMs() - start) / 1000f;
        float target = BLOOM1 + 0.3f;
        if (t < target) start -= (long) ((target - t) * 1000f);
        holdMin = Math.min(holdMin, target);
    }

    /** True once the whole-screen flash has peaked: the next screen can take over. */
    public static boolean finished() { return eStart > 0 && (Util.getMeasuringTimeMs() - eStart) / 1000f >= END; }

    /** Call when the next screen is set: its first frames are covered by a fading white veil (see {@link #veil}). */
    public static void handoff() { handoffAt = Util.getMeasuringTimeMs(); }

    /** White veil that fades away over the first moments of the menu (the end of the flash). */
    public static void veil(DrawContext ctx, int w, int h) {
        if (handoffAt == 0) return;
        float p = (Util.getMeasuringTimeMs() - handoffAt) / 1500f;
        if (p >= 1f) { handoffAt = 0; return; }
        float a = (1f - p) * (1f - p);
        ctx.fill(0, 0, w, h, Gfx.argb(a, 0xFFFFFF));
    }

    // ---------- generated textures ----------
    private static boolean ensure(MinecraftClient mc) {
        if (ready) return true;
        if (tried) return false;
        tried = true;
        try {
            NativeImage img = NativeImage.read(new ByteArrayInputStream(softPng(256)));
            mc.getTextureManager().registerTexture(SOFT, new NativeImageBackedTexture(() -> "shrine boot", img));
            ready = true;
        } catch (Throwable t) {
            ready = false;
            return false;
        }
        try {
            NativeImage logo = NativeImage.read(new ByteArrayInputStream(Base64.getDecoder().decode(LOGO_PNG)));
            mc.getTextureManager().registerTexture(LOGO_T, new NativeImageBackedTexture(() -> "shrine boot logo", logo));
            logoReady = true;
        } catch (Throwable t) {
            logoReady = false;
        }
        return ready;
    }

    /** Minimal PNG writer (no java.awt). White RGBA, alpha = soft falloff. */
    private static byte[] softPng(int n) throws Exception {
        byte[] raw = new byte[(n * 4 + 1) * n];
        int o = 0;
        for (int y = 0; y < n; y++) {
            raw[o++] = 0;
            for (int x = 0; x < n; x++) {
                float dx = (x + 0.5f) / n * 2f - 1f, dy = (y + 0.5f) / n * 2f - 1f;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                float a = d >= 1f ? 0f : (float) Math.pow(1f - d, 2.2);
                raw[o++] = (byte) 255; raw[o++] = (byte) 255; raw[o++] = (byte) 255;
                raw[o++] = (byte) Math.round(a * 255f);
            }
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(new byte[]{(byte) 0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A});
        ByteArrayOutputStream ihdr = new ByteArrayOutputStream();
        DataOutputStream d = new DataOutputStream(ihdr);
        d.writeInt(n); d.writeInt(n); d.writeByte(8); d.writeByte(6); d.writeByte(0); d.writeByte(0); d.writeByte(0);
        chunk(out, "IHDR", ihdr.toByteArray());
        ByteArrayOutputStream z = new ByteArrayOutputStream();
        try (DeflaterOutputStream dz = new DeflaterOutputStream(z, new Deflater(6))) { dz.write(raw); }
        chunk(out, "IDAT", z.toByteArray());
        chunk(out, "IEND", new byte[0]);
        return out.toByteArray();
    }

    private static void chunk(ByteArrayOutputStream out, String type, byte[] data) throws Exception {
        DataOutputStream d = new DataOutputStream(out);
        d.writeInt(data.length);
        byte[] t = type.getBytes("US-ASCII");
        d.write(t); d.write(data);
        CRC32 crc = new CRC32();
        crc.update(t); crc.update(data);
        d.writeInt((int) crc.getValue());
    }

    // ---------- math ----------
    private static float cl(float x) { return Math.max(0f, Math.min(1f, x)); }
    private static float sm(float x) { x = cl(x); return x * x * (3f - 2f * x); }
    private static float mix(float a, float b, float t) { return a + (b - a) * t; }

    private static void soft(DrawContext ctx, float x, float y, float w, float h, float alpha) {
        if (alpha <= 0.004f) return;
        Gfx.centered(ctx, SOFT, x, y, w, h, Gfx.argb(alpha, 0xFFFFFF));
    }

    private static void dot(DrawContext ctx, float x, float y, int s, float alpha, int rgb) {
        if (alpha <= 0.01f) return;
        int ix = Math.round(x), iy = Math.round(y);
        ctx.fill(ix, iy, ix + s, iy + s, Gfx.argb(alpha, rgb));
    }

    // ---------- drawing ----------
    public static void draw(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!ensure(mc)) return;
        long now = Util.getMeasuringTimeMs();
        if (start == 0 || now - last > 3000L) {        // a new session: first launch, or a later resource reload
            start = now; eStart = 0; released = false; holdMin = 5.6f; stride = 2; avgDt = 16f; stableFrames = 0;
        } else {
            float dt = Math.min(250f, now - last);
            avgDt = avgDt * 0.9f + dt * 0.1f;
            if (++stableFrames > 20) {
                if (avgDt > 24f && stride < 3) { stride++; stableFrames = 0; }
                else if (avgDt < 15f && stride > 1) { stride--; stableFrames = 0; }
            }
        }
        last = now;
        float t = (now - start) / 1000f;
        if (released && eStart == 0 && t >= holdMin) eStart = now;
        float te = eStart > 0 ? (now - eStart) / 1000f : 0f;
        float m = sm(te / MELT);                                  // melt progress 0..1
        float flash = eStart > 0 ? sm((te - FLASH0) / (END - FLASH0)) : 0f;

        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        ctx.fill(0, 0, w, h, 0xFF000000);

        // from here on we draw in framebuffer pixels: dust stays 1-2 px at any GUI scale
        float sf = (float) mc.getWindow().getScaleFactor();
        float pw = w * sf, ph = h * sf, u = ph / Scene.REF_H;
        float cx = pw / 2f, cy = ph / 2f;
        float LS = 135f * u;                                       // half size of the logo
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(1f / sf, 1f / sf);

        // ===== A: solid logo, shrinks into the core =====
        float shr = sm((t - SHRINK0) / (SHRINK1 - SHRINK0));
        float aLogo = sm(t / 0.5f) * (1f - sm((t - 1.3f) / 0.3f));
        if (aLogo > 0.01f) {
            float sc = 1f - 0.86f * shr;
            soft(ctx, cx, cy, LS * 3.0f * sc, LS * 3.0f * sc, 0.40f * aLogo);
            soft(ctx, cx, cy, LS * 1.8f * sc, LS * 1.8f * sc, 0.30f * aLogo);
            if (logoReady) {
                ctx.getMatrices().pushMatrix();
                ctx.getMatrices().translate(cx, cy);
                ctx.getMatrices().rotate(0.5f * shr);
                ctx.getMatrices().scale(sc * (1f - 0.45f * shr), sc);
                Gfx.centered(ctx, LOGO_T, 0f, 0f, LS * 2f, LS * 2f, Gfx.argb(aLogo, 0xFFFFFF));
                ctx.getMatrices().popMatrix();
            }
        }

        // ===== the core (between A and the logo) =====
        float bump = Math.max(0f, 1f - Math.abs(t - 3.75f) / 0.4f);
        float core = (38f + 50f * sm((t - 1.4f) / 1.4f) + 5f * (float) Math.sin(t * 3.1f) + 120f * bump * bump) * u;
        float coreA = sm((t - 1.15f) / 0.3f) * (1f - sm((t - 3.95f) / 0.8f)) * (1f - m);
        if (coreA > 0.01f) {
            soft(ctx, cx, cy, core * 4.2f, core * 3.6f, 0.30f * coreA);
            soft(ctx, cx, cy, core * 2.0f, core * 1.8f, 0.60f * coreA);
            soft(ctx, cx, cy, core * 0.8f, core * 0.8f, 0.95f * coreA);
        }

        // ===== B/C: cloud -> core -> logo bloom; D: held; E: melt =====
        float pa = sm((t - BURST) / 0.35f);
        float burst = 1f - (float) Math.pow(1f - cl((t - BURST) / 1.15f), 3.0);
        float s1 = sm((t - COLLAPSE0) / (COLLAPSE1 - COLLAPSE0));
        float s2 = sm((t - BLOOM0) / (BLOOM1 - BLOOM0));
        float cloudR = 175f * u * (1f - 0.22f * sm((t - SWIRL_END) / 0.9f));
        int px1 = Math.max(1, Math.round(u * 0.5f));
        if (pa > 0.01f) {
            // soft haze of the cloud
            float hz = pa * (1f - s1) * 0.26f;
            soft(ctx, cx, cy, cloudR * 2.6f * burst, cloudR * 2.2f * burst, hz);
            for (int i = 0; i < NL; i += stride) {
                float[] p = LP[i];
                boolean edge = p[2] > 0.5f;
                // cloud position
                float rr = cloudR * p[4] * burst * (1f + 0.05f * (float) Math.sin(2.2f * t + p[5]));
                float ang = p[3] + 0.45f * Math.max(0f, t - BURST) * (1f - 0.5f * p[4]);
                float x = (float) Math.cos(ang) * rr * 1.15f, y = (float) Math.sin(ang) * rr * 0.95f;
                // collapse to the core, then bloom out to the logo
                x *= 1f - s1; y *= 1f - s1;
                float hx = p[0] * LS, hy = p[1] * LS;
                float breathe = 1f + 0.014f * (float) Math.sin(t * 1.3f + p[5]);
                hx *= breathe; hy *= breathe;
                if (eStart > 0) {            // E: the logo melts and fragments
                    float wx = ((float) Math.sin(p[1] * 4.2f + t * 2.1f + p[5]) + 0.6f * (float) Math.sin(p[0] * 7.3f - t * 1.7f)) * 70f * u * m;
                    float wy = ((float) Math.cos(p[0] * 3.7f + t * 1.9f) + 0.6f * (float) Math.cos(p[1] * 6.1f + t * 2.3f + p[5])) * 55f * u * m;
                    hx = hx * (1f - 0.40f * m) + wx; hy = hy * (1f - 0.40f * m) + wy;
                }
                x = mix(x, hx, s2); y = mix(y, hy, s2);
                float jit = (2.2f - 1.4f * s2) * u * 0.5f;
                x += (float) Math.sin(t * 6.1f + p[5]) * jit * (0.5f + p[8]);
                y += (float) Math.cos(t * 5.3f + p[5] * 1.7f) * jit * (0.5f + p[9]);

                float tw = 0.65f + 0.35f * (float) Math.sin(t * (2f + 3f * p[8]) + p[5]);
                float a;
                if (edge) a = mix(0.80f, 1.00f, s2) * tw;
                else a = mix(0.75f, 0.60f, s2) * p[7] * tw;
                a *= pa * (1f - 0.65f * m);
                int rgb = p[7] > 0.8f ? 0xFFFFFF : 0xDCDCDC;
                dot(ctx, cx + x, cy + y, (p[6] > 1.9f || (stride > 1 && p[6] > 1.3f)) ? px1 + 1 : px1, a, rgb);
                // glowing contour
                if (edge && i % (3 * stride) == 0 && s2 > 0.02f) soft(ctx, cx + x, cy + y, 12f * u, 12f * u, 0.17f * s2 * (1f - 0.7f * m));
                // soft grains of the cloud
                if (i % (16 * stride) == 0) soft(ctx, cx + x, cy + y, 26f * u, 26f * u, 0.06f * pa * (1f - s2));
            }
            // halo of the formed logo
            float hl = s2 * (1f - 0.75f * m);
            soft(ctx, cx, cy, LS * 3.4f, LS * 3.4f, 0.40f * hl);
            soft(ctx, cx, cy, LS * 2.0f, LS * 2.0f, 0.42f * hl);
        }

        // ===== dust: fine specks over the whole screen, then a horizontal band =====
        float da = sm((t - 0.8f) / 0.6f) * (1f - m);
        if (da > 0.01f) {
            float bandMix = sm((t - 3.0f) / 1.3f);
            for (int di = 0; di < ND; di += stride) {
                float[] d = DP[di];
                float fx = d[0] * pw + (float) Math.sin(t * 0.5f * d[6] + d[4]) * 9f * u;
                float fy = d[1] * ph + (float) Math.cos(t * 0.4f * d[6] + d[4]) * 9f * u;
                float bx = cx + d[2] * pw * 0.56f + (float) Math.sin(t * 0.7f + d[4]) * 8f * u;
                float by = cy + (d[3] * 11f + 11f * (float) Math.sin(d[2] * 5f + t * 0.9f)) * u * (0.6f + 0.5f * bandMix);
                float x = mix(fx, bx, bandMix), y = mix(fy, by, bandMix);
                float tw = 0.45f + 0.55f * Math.abs((float) Math.sin(t * 1.6f * d[6] + d[4]));
                float edgeFade = 1f - 0.7f * Math.abs(d[2]) * bandMix;
                dot(ctx, x, y, d[5] > 1.6f ? px1 + 1 : px1, 0.85f * tw * da * edgeFade, 0xE6E6E6);
            }
            soft(ctx, cx, cy, pw * 1.25f, 90f * u, 0.12f * bandMix * da);
        }
        ctx.getMatrices().popMatrix();

        // ===== E: whole-screen flash into the menu =====
        if (flash > 0.001f) ctx.fill(0, 0, w, h, Gfx.argb(flash, 0xFFFFFF));
    }
}
