package com.shrine;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Account > "Multi Account". The game window itself plays one account (the "main" one: {@link Accounts#current}); every other
 * account you connect stays on the same server as a background connection ({@link BotConn}). "Play as" swaps the roles: the
 * chosen account becomes the main one and the account you were playing stays online in the background.
 */
final class MultiAccount {
    private MultiAccount() {}

    static final String KEY = "multi.on", K_SWITCH = "multi.switch", K_RESPAWN = "multi.respawn";
    static final int DEF_SWITCH = GLFW.GLFW_KEY_F8;

    /** account id -> its background connection (main thread only). */
    static final Map<String, BotConn> BOTS = new LinkedHashMap<>();

    private record Creds(String name, UUID uuid, String token) {}

    private static boolean down, busy;
    private static ServerInfo pendingServer;        // rejoin this server (as the new main account) once the old connection is gone
    private static long pendingAt;
    private static Accounts.Acc pendingBotAcc;      // the account that was playing: it goes to the background
    private static ServerInfo pendingBotServer;
    private static long pendingBotAt;
    private static String joinedAs = "";

    static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(MultiAccount::tick);
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            ServerInfo now = client.getCurrentServerEntry();
            if (now != null) {
                List<String> drop = new ArrayList<>();
                for (Map.Entry<String, BotConn> e : BOTS.entrySet()) if (!e.getValue().server.address.equals(now.address)) drop.add(e.getKey());
                for (String id : drop) { BotConn b = BOTS.remove(id); if (b != null) b.stop(); }   // they belong to another server
            }
            if (!joinedAs.isEmpty()) {
                String n = joinedAs;
                joinedAs = "";
                client.execute(() -> { if (client.player != null) client.player.sendMessage(Text.literal("Multi Account: играешь за " + n), true); });
            }
        });
    }

    // ---------- state for the menu ----------
    static boolean isMain(Accounts.Acc a) { return a.id.equals(Accounts.current); }
    static BotConn bot(Accounts.Acc a) { return BOTS.get(a.id); }
    static boolean busy() { return busy; }
    static int onlineBots() { int n = 0; for (BotConn b : BOTS.values()) if (b.busy()) n++; return n; }

    private static boolean held() {
        int key = ShrineCfg.integer(K_SWITCH, DEF_SWITCH);
        if (key < 0) return false;
        long w = GLFW.glfwGetCurrentContext();
        if (w == 0L) return false;
        if (key >= 1000) return GLFW.glfwGetMouseButton(w, key - 1000) == GLFW.GLFW_PRESS;
        return GLFW.glfwGetKey(w, key) == GLFW.GLFW_PRESS;
    }

    static void say(MinecraftClient mc, String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("Multi Account: " + s), true);
    }

    static void tick(MinecraftClient mc) {
        boolean now = held();
        boolean edge = now && !down;
        down = now;

        for (BotConn b : BOTS.values()) b.tick();

        long ms = Util.getMeasuringTimeMs();
        if (pendingBotAcc != null && ms >= pendingBotAt) {          // the account we left goes to the background
            Accounts.Acc a = pendingBotAcc;
            ServerInfo si = pendingBotServer;
            pendingBotAcc = null;
            pendingBotServer = null;
            startBotOn(mc, a, si);
        }

        // finishing a "Play as": once the old connection is gone, join the same server with the new session
        if (pendingServer != null) {
            if (ms - pendingAt > 20000L) { pendingServer = null; busy = false; return; }
            if (mc.world == null && mc.getNetworkHandler() == null && mc.currentScreen != null
                    && !(mc.currentScreen instanceof ConnectScreen) && ms - pendingAt > 900L) {
                ServerInfo si = pendingServer;
                pendingServer = null;
                busy = false;
                ConnectScreen.connect(mc.currentScreen, mc, ServerAddress.parse(si.address), si, false, null);
            }
            return;
        }

        if (!ShrineCfg.bool(KEY, false)) return;
        if (mc.player != null && ShrineCfg.bool(K_RESPAWN, true) && mc.player.isDead()) mc.player.requestRespawn();
        if (!edge || mc.player == null || mc.world == null || mc.currentScreen != null) return;
        mc.setScreen(new MultiAccountScreen());
    }

    // ---------- background accounts ----------
    private static Creds creds(Accounts.Acc a) throws Exception {
        switch (a.type) {
            case "licensed": {
                MsLogin.Result r = MsLogin.refresh(a.refresh);
                a.refresh = r.refresh(); a.name = r.name(); a.uuid = r.uuid().toString();
                Accounts.save();
                return new Creds(r.name(), r.uuid(), r.token());
            }
            case "launcher": {
                if (Accounts.original == null) throw new IllegalStateException("сессия лаунчера недоступна");
                return new Creds(Accounts.original.getUsername(), Accounts.original.getUuidOrNull(), Accounts.original.getAccessToken());
            }
            default:
                return new Creds(a.name, Accounts.offlineUuid(a.name), "");
        }
    }

    /** Connects {@code a} to the server the main account is on. */
    static void connectBot(MinecraftClient mc, Accounts.Acc a) {
        ServerInfo si = mc.getCurrentServerEntry();
        if (si == null) { say(mc, "сначала зайди на сервер"); return; }
        startBotOn(mc, a, si);
    }

    private static void startBotOn(MinecraftClient mc, Accounts.Acc a, ServerInfo si) {
        if (a.id.equals(Accounts.current)) return;                  // that one is the main account
        BotConn old = BOTS.get(a.id);
        if (old != null && old.busy()) return;
        Thread t = new Thread(() -> {
            try {
                Creds c = creds(a);
                mc.execute(() -> {
                    BotConn b = new BotConn(mc, a, c.name(), c.uuid(), c.token(), si);
                    BOTS.put(a.id, b);
                    b.start();
                });
            } catch (Throwable e) {
                String why = Accounts.describe(e);
                mc.execute(() -> say(mc, a.name + ": " + why));
            }
        }, "shrine-bot-login");
        t.setDaemon(true);
        t.start();
    }

    static void connectAll(MinecraftClient mc) {
        Accounts.init();
        for (Accounts.Acc a : new ArrayList<>(Accounts.LIST)) if (!isMain(a)) connectBot(mc, a);
    }

    static void stopBot(Accounts.Acc a) {
        BotConn b = BOTS.remove(a.id);
        if (b != null) b.stop();
    }

    static void stopAll() {
        for (BotConn b : BOTS.values()) b.stop();
        BOTS.clear();
    }

    /** Chat as every connected account (the main one too). */
    static void chatEveryone(MinecraftClient mc, String text) {
        for (BotConn b : BOTS.values()) b.sendChat(text);
        sendMain(mc, text);
    }

    static void sendMain(MinecraftClient mc, String text) {
        if (mc.getNetworkHandler() == null || text == null || text.isBlank()) return;
        if (text.startsWith("/")) mc.getNetworkHandler().sendChatCommand(text.substring(1));
        else mc.getNetworkHandler().sendChatMessage(text);
    }

    // ---------- "Play as" ----------
    /** Makes {@code next} the account the window plays; the account that was playing stays on the server in the background. */
    static void playAs(MinecraftClient mc, Accounts.Acc next) {
        if (busy || isMain(next)) return;
        ServerInfo si = mc.getCurrentServerEntry();
        if (si == null) { say(mc, "работает только на сервере"); return; }
        Accounts.Acc prev = Accounts.currentAcc();
        boolean wasBot = BOTS.containsKey(next.id);
        busy = true;
        say(mc, "перехожу на " + next.name + "…");
        stopBot(next);                                              // it cannot be on the server twice
        Thread t = new Thread(() -> {
            String err = Accounts.activate(next);                   // may talk to Microsoft: off the game thread
            mc.execute(() -> {
                if (err != null) { busy = false; say(mc, err); return; }
                joinedAs = next.name;
                pendingServer = si;
                pendingAt = Util.getMeasuringTimeMs() + (wasBot ? 600L : 0L);
                if (prev != null && !prev.id.equals(next.id)) {
                    pendingBotAcc = prev;
                    pendingBotServer = si;
                    pendingBotAt = Util.getMeasuringTimeMs() + 1800L;
                }
                if (mc.getNetworkHandler() != null) mc.getNetworkHandler().getConnection().disconnect(Text.literal("Смена аккаунта"));
            });
        }, "shrine-multi-account");
        t.setDaemon(true);
        t.start();
    }
}
