package com.shrine;

import io.netty.channel.ChannelFuture;
import net.minecraft.client.ClientBrandRetriever;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.Address;
import net.minecraft.client.network.AllowedAddressResolver;
import net.minecraft.client.network.ClientDynamicRegistryType;
import net.minecraft.client.network.ClientRegistries;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.entity.EntityPosition;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.DisconnectionInfo;
import net.minecraft.network.NetworkSide;
import net.minecraft.network.NetworkingBackend;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.encryption.NetworkEncryptionUtils;
import net.minecraft.network.listener.ClientConfigurationPacketListener;
import net.minecraft.network.listener.ClientLoginPacketListener;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.message.LastSeenMessagesCollector;
import net.minecraft.network.message.MessageBody;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.network.message.MessageSignatureStorage;
import net.minecraft.network.packet.BrandCustomPayload;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.common.ClientOptionsC2SPacket;
import net.minecraft.network.packet.c2s.common.CommonPongC2SPacket;
import net.minecraft.network.packet.c2s.common.CookieResponseC2SPacket;
import net.minecraft.network.packet.c2s.common.CustomPayloadC2SPacket;
import net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket;
import net.minecraft.network.packet.c2s.common.ResourcePackStatusC2SPacket;
import net.minecraft.network.packet.c2s.config.AcceptCodeOfConductC2SPacket;
import net.minecraft.network.packet.c2s.config.ReadyC2SPacket;
import net.minecraft.network.packet.c2s.config.SelectKnownPacksC2SPacket;
import net.minecraft.network.packet.c2s.login.EnterConfigurationC2SPacket;
import net.minecraft.network.packet.c2s.login.LoginHelloC2SPacket;
import net.minecraft.network.packet.c2s.login.LoginKeyC2SPacket;
import net.minecraft.network.packet.c2s.login.LoginQueryResponseC2SPacket;
import net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;
import net.minecraft.network.packet.c2s.play.MessageAcknowledgmentC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.TeleportConfirmC2SPacket;
import net.minecraft.network.packet.s2c.common.CommonPingS2CPacket;
import net.minecraft.network.packet.s2c.common.CookieRequestS2CPacket;
import net.minecraft.network.packet.s2c.common.DisconnectS2CPacket;
import net.minecraft.network.packet.s2c.common.KeepAliveS2CPacket;
import net.minecraft.network.packet.s2c.common.ResourcePackSendS2CPacket;
import net.minecraft.network.packet.s2c.common.ServerTransferS2CPacket;
import net.minecraft.network.packet.s2c.common.SynchronizeTagsS2CPacket;
import net.minecraft.network.packet.s2c.config.CodeOfConductS2CPacket;
import net.minecraft.network.packet.s2c.config.DynamicRegistriesS2CPacket;
import net.minecraft.network.packet.s2c.config.ReadyS2CPacket;
import net.minecraft.network.packet.s2c.config.SelectKnownPacksS2CPacket;
import net.minecraft.network.packet.s2c.login.LoginCompressionS2CPacket;
import net.minecraft.network.packet.s2c.login.LoginDisconnectS2CPacket;
import net.minecraft.network.packet.s2c.login.LoginHelloS2CPacket;
import net.minecraft.network.packet.s2c.login.LoginQueryRequestS2CPacket;
import net.minecraft.network.packet.s2c.login.LoginSuccessS2CPacket;
import net.minecraft.network.packet.s2c.play.ChatMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.network.packet.s2c.play.GameStateChangeS2CPacket;
import net.minecraft.network.packet.s2c.play.HealthUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerListS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.network.packet.s2c.play.ProfilelessChatMessageS2CPacket;
import net.minecraft.network.state.ConfigurationStates;
import net.minecraft.network.state.LoginStates;
import net.minecraft.network.state.PlayStateFactories;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.resource.ResourceFactory;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.math.BigInteger;
import java.net.InetSocketAddress;
import java.security.PublicKey;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * One extra account connected to the server in the background: no world, no player entity, only what is needed to stay online
 * (login, configuration, keep-alive, teleport confirms) plus the things the Multi Account menu shows: health, food, ping, world,
 * game mode, chat. The three protocol phases are served by proxies that dispatch on the packet class, so a packet we do not care
 * about is simply ignored.
 */
final class BotConn {
    enum State { CONNECTING, ONLINE, FAILED, STOPPED }

    private static final int PLAY = 2, LOGIN = 0, CONFIG = 1;

    final Accounts.Acc acc;
    final String name;
    final UUID uuid;
    final String token;                 // "" for a pirate account
    final ServerInfo server;
    final long startedAt = System.currentTimeMillis();

    volatile State state = State.CONNECTING;
    volatile String error = "";
    volatile float health = -1f;
    volatile int food = -1;
    volatile int pingMs = -1;
    volatile String world = "", mode = "";
    volatile double x, y, z;
    private volatile float yaw, pitch;
    private volatile boolean dead, stopped;
    final List<String> chat = Collections.synchronizedList(new ArrayList<>());

    private final MinecraftClient mc;
    private volatile ClientConnection conn;
    private final ClientRegistries registries = new ClientRegistries();
    private final Map<UUID, String> names = new ConcurrentHashMap<>();
    private final MessageSignatureStorage sigStorage = MessageSignatureStorage.create();
    private final LastSeenMessagesCollector collector = new LastSeenMessagesCollector(20);

    BotConn(MinecraftClient mc, Accounts.Acc acc, String name, UUID uuid, String token, ServerInfo server) {
        this.mc = mc;
        this.acc = acc;
        this.name = name;
        this.uuid = uuid;
        this.token = token == null ? "" : token;
        this.server = server;
    }

    /** "overworld" out of a world key (read from its text, so no accessor name is needed). */
    static String dimName(Object key) {
        String s = String.valueOf(key);
        int e = s.lastIndexOf(']');
        if (e < 0) e = s.length();
        int b = Math.max(s.lastIndexOf(' ', e), s.lastIndexOf('/', e)) + 1;
        String id = s.substring(Math.min(b, e), e);
        int c = id.indexOf(':');
        return c >= 0 ? id.substring(c + 1) : id;
    }

    boolean online() { return state == State.ONLINE; }
    boolean busy() { return state == State.CONNECTING || state == State.ONLINE; }

    // ---------- lifecycle ----------
    void start() {
        Thread t = new Thread(this::run, "shrine-bot-" + name);
        t.setDaemon(true);
        t.start();
    }

    /** Called every client tick (main thread): a connection is driven by its tick, as ConnectScreen does it. */
    void tick() {
        ClientConnection c = conn;
        if (c != null) c.tick();
    }

    void stop() {
        stopped = true;
        ClientConnection c = conn;
        if (c != null) c.disconnect(Text.literal("Multi Account: отключён"));
        if (state != State.FAILED) state = State.STOPPED;
    }

    private void fail(String why) {
        if (state == State.FAILED || stopped) return;
        error = why == null ? "" : why;
        state = State.FAILED;
        ClientConnection c = conn;
        if (c != null) c.disconnect(Text.literal(error));
    }

    private void run() {
        Object prevVia = null;
        boolean viaSet = false;
        try {
            ServerAddress address = ServerAddress.parse(server.address);
            Optional<InetSocketAddress> resolved = AllowedAddressResolver.DEFAULT.resolve(address).map(Address::getInetSocketAddress);
            if (resolved.isEmpty()) { fail("неизвестный адрес сервера"); return; }
            InetSocketAddress isa = resolved.get();
            ClientConnection c = new ClientConnection(NetworkSide.CLIENTBOUND);
            long t0 = System.nanoTime();
            if (Via.available()) {                           // join with the same protocol version as the main connection
                Object forced = Via.forced(server);
                if (forced != null) { prevVia = Via.global(); Via.setGlobal(forced); viaSet = true; }
            }
            ChannelFuture f;
            try {
                f = ClientConnection.connect(isa, NetworkingBackend.remote(mc.options.shouldUseNativeTransport()), c);
                f.syncUninterruptibly();
            } finally {
                if (viaSet) Via.setGlobal(prevVia);
            }
            pingMs = (int) ((System.nanoTime() - t0) / 1_000_000L);
            if (stopped) { c.disconnect(Text.literal("stop")); return; }
            conn = c;
            c.connect(isa.getHostName(), isa.getPort(), LoginStates.C2S, LoginStates.S2C, proxy(ClientLoginPacketListener.class, LOGIN), false);
            c.send(new LoginHelloC2SPacket(name, uuid));
        } catch (Throwable t) {
            Throwable r = t;
            while (r.getCause() != null && r.getCause() != r) r = r.getCause();
            fail(r.getMessage() == null ? r.getClass().getSimpleName() : r.getMessage());
        }
    }

    // ---------- chat from the menu ----------
    boolean sendChat(String text) {
        ClientConnection c = conn;
        if (c == null || state != State.ONLINE || text == null || text.isBlank()) return false;
        if (text.startsWith("/")) {
            c.send(new CommandExecutionC2SPacket(text.substring(1)));
        } else {
            synchronized (collector) {
                LastSeenMessagesCollector.LastSeenMessages seen = collector.collect();
                c.send(new ChatMessageC2SPacket(text, Instant.now(), NetworkEncryptionUtils.SecureRandomUtil.nextLong(), null, seen.update()));
            }
        }
        return true;
    }

    private void log(String line) {
        if (line == null || line.isBlank()) return;
        chat.add(line);
        while (chat.size() > 200) chat.remove(0);
    }

    // ---------- the listener proxies ----------
    @SuppressWarnings("unchecked")
    private <T> T proxy(Class<T> type, int phase) {
        InvocationHandler h = (self, m, a) -> dispatch(phase, self, m, a);
        return (T) Proxy.newProxyInstance(BotConn.class.getClassLoader(), new Class<?>[]{type}, h);
    }

    private Object dispatch(int phase, Object self, Method m, Object[] a) throws Throwable {
        if (m.getDeclaringClass() == Object.class) {
            return switch (m.getName()) {
                case "hashCode" -> System.identityHashCode(self);
                case "equals" -> self == a[0];
                default -> "BotConn(" + name + ")";
            };
        }
        int n = a == null ? 0 : a.length;
        if (m.isDefault()) {
            if (n == 2 && a[0] instanceof Packet<?> && a[1] instanceof Exception e) {      // onPacketException: never crash the game
                fail("ошибка пакета: " + e.getClass().getSimpleName());
                return null;
            }
            if (n == 1 && a[0] instanceof Packet<?> p && m.getReturnType() == void.class) { packet(phase, p); return null; }
            return InvocationHandler.invokeDefault(self, m, a);
        }
        if (n == 1 && a[0] instanceof Packet<?> p) { packet(phase, p); return null; }
        if (n == 1 && a[0] instanceof DisconnectionInfo info) { disconnected(info); return null; }
        if (m.getReturnType() == boolean.class) { ClientConnection c = conn; return c == null || c.isOpen(); }   // isConnectionOpen
        return null;
    }

    private void disconnected(DisconnectionInfo info) {
        if (state == State.FAILED || stopped) { if (state != State.FAILED) state = State.STOPPED; return; }
        String why = info.reason().getString();
        error = why;
        state = State.FAILED;
    }

    private void packet(int phase, Packet<?> p) {
        try {
            switch (phase) {
                case LOGIN -> login(p);
                case CONFIG -> config(p);
                default -> play(p);
            }
        } catch (Throwable t) {
            fail("ошибка: " + (t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage()));
        }
    }

    // ---------- login ----------
    private void login(Packet<?> p) throws Exception {
        ClientConnection c = conn;
        if (p instanceof LoginHelloS2CPacket hello) {
            SecretKey secretKey = NetworkEncryptionUtils.generateSecretKey();
            PublicKey publicKey = hello.getPublicKey();
            String serverHash = new BigInteger(NetworkEncryptionUtils.computeServerId(hello.getServerId(), publicKey, secretKey)).toString(16);
            Cipher decrypt = NetworkEncryptionUtils.cipherFromKey(2, secretKey);
            Cipher encrypt = NetworkEncryptionUtils.cipherFromKey(1, secretKey);
            LoginKeyC2SPacket key = new LoginKeyC2SPacket(secretKey, publicKey, hello.getNonce());
            if (hello.needsAuthentication()) {
                if (token.isEmpty()) { fail("сервер проверяет лицензию, а этот аккаунт пиратский"); return; }
                Util.getIoWorkerExecutor().execute(() -> {
                    try {
                        mc.getApiServices().sessionService().joinServer(uuid, token, serverHash);
                    } catch (Exception e) {
                        fail("не удалось войти по лицензии: " + e.getMessage());
                        return;
                    }
                    c.send(key, PacketCallbacks.always(() -> c.setupEncryption(decrypt, encrypt)));
                });
            } else {
                c.send(key, PacketCallbacks.always(() -> c.setupEncryption(decrypt, encrypt)));
            }
        } else if (p instanceof LoginCompressionS2CPacket comp) {
            c.setCompressionThreshold(comp.getCompressionThreshold(), false);
        } else if (p instanceof LoginSuccessS2CPacket) {
            c.transitionInbound(ConfigurationStates.S2C, proxy(ClientConfigurationPacketListener.class, CONFIG));
            c.send(EnterConfigurationC2SPacket.INSTANCE);
            c.transitionOutbound(ConfigurationStates.C2S);
            c.send(new CustomPayloadC2SPacket(new BrandCustomPayload(ClientBrandRetriever.getClientModName())));
            c.send(new ClientOptionsC2SPacket(mc.options.getSyncedOptions()));
        } else if (p instanceof LoginDisconnectS2CPacket d) {
            fail(d.reason().getString());
        } else if (p instanceof LoginQueryRequestS2CPacket q) {
            c.send(new LoginQueryResponseC2SPacket(q.queryId(), null));
        } else if (p instanceof CookieRequestS2CPacket ck) {
            c.send(new CookieResponseC2SPacket(ck.key(), (byte[]) null));
        }
    }

    // ---------- configuration ----------
    private void config(Packet<?> p) {
        ClientConnection c = conn;
        if (p instanceof KeepAliveS2CPacket k) {
            c.send(new KeepAliveC2SPacket(k.getId()));
        } else if (p instanceof CommonPingS2CPacket ping) {
            c.send(new CommonPongC2SPacket(ping.getParameter()));
        } else if (p instanceof DynamicRegistriesS2CPacket d) {
            registries.putDynamicRegistry(d.registry(), d.entries());
        } else if (p instanceof SynchronizeTagsS2CPacket t) {
            registries.putTags(t.getGroups());
        } else if (p instanceof SelectKnownPacksS2CPacket) {
            c.send(new SelectKnownPacksC2SPacket(List.of()));          // "I know no packs": the server sends the full registries
        } else if (p instanceof ResourcePackSendS2CPacket r) {
            resourcePack(c, r);
        } else if (p instanceof CodeOfConductS2CPacket) {
            c.send(AcceptCodeOfConductC2SPacket.INSTANCE);
        } else if (p instanceof CookieRequestS2CPacket ck) {
            c.send(new CookieResponseC2SPacket(ck.key(), (byte[]) null));
        } else if (p instanceof ServerTransferS2CPacket) {
            fail("сервер перенаправляет на другой адрес");
        } else if (p instanceof DisconnectS2CPacket d) {
            fail(d.reason().getString());
        } else if (p instanceof ReadyS2CPacket) {
            mc.execute(() -> toPlay(c));                                 // like the game: build the registries on the main thread
        }
    }

    private void toPlay(ClientConnection c) {
        if (stopped || state == State.FAILED) return;
        try {
            DynamicRegistryManager.Immutable registryManager = registries.createRegistryManager(
                    ResourceFactory.MISSING,
                    ClientDynamicRegistryType.createCombinedDynamicRegistries().getCombinedRegistryManager(),
                    false);
            c.transitionInbound(PlayStateFactories.S2C.bind(RegistryByteBuf.makeFactory(registryManager)), proxy(ClientPlayPacketListener.class, PLAY));
            c.send(ReadyC2SPacket.INSTANCE);
            c.transitionOutbound(PlayStateFactories.C2S.bind(RegistryByteBuf.makeFactory(registryManager), new PlayStateFactories.PacketCodecModifierContext() {
                @Override
                public boolean isInCreativeMode() { return true; }
            }));
        } catch (Throwable t) {
            fail("не удалось войти в игру: " + (t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage()));
        }
    }

    private void resourcePack(ClientConnection c, ResourcePackSendS2CPacket r) {
        UUID id = r.id();
        for (String s : new String[]{"ACCEPTED", "SUCCESSFULLY_LOADED"}) {         // pretend: the account never renders anything
            try {
                c.send(new ResourcePackStatusC2SPacket(id, ResourcePackStatusC2SPacket.Status.valueOf(s)));
            } catch (IllegalArgumentException ignored) { }
        }
    }

    // ---------- play ----------
    private void play(Packet<?> p) {
        ClientConnection c = conn;
        if (p instanceof KeepAliveS2CPacket k) {
            c.send(new KeepAliveC2SPacket(k.getId()));
        } else if (p instanceof CommonPingS2CPacket ping) {
            c.send(new CommonPongC2SPacket(ping.getParameter()));
        } else if (p instanceof GameJoinS2CPacket j) {
            world = dimName(j.commonPlayerSpawnInfo().dimension());
            mode = j.commonPlayerSpawnInfo().gameMode().name().toLowerCase(Locale.ROOT);
            state = State.ONLINE;
            log("— зашёл на сервер —");
        } else if (p instanceof PlayerRespawnS2CPacket r) {
            world = dimName(r.commonPlayerSpawnInfo().dimension());
            mode = r.commonPlayerSpawnInfo().gameMode().name().toLowerCase(Locale.ROOT);
        } else if (p instanceof GameStateChangeS2CPacket g) {
            if (g.getReason() == GameStateChangeS2CPacket.GAME_MODE_CHANGED) {
                mode = GameMode.byIndex((int) Math.floor(g.getValue() + 0.5f)).name().toLowerCase(Locale.ROOT);
            }
        } else if (p instanceof HealthUpdateS2CPacket h) {
            health = h.getHealth();
            food = h.getFood();
            if (h.getHealth() <= 0f) {
                if (!dead && ShrineCfg.bool(MultiAccount.K_RESPAWN, true)) {
                    dead = true;
                    c.send(new ClientStatusC2SPacket(ClientStatusC2SPacket.Mode.PERFORM_RESPAWN));
                    log("— погиб, возрождаюсь —");
                }
            } else {
                dead = false;
            }
        } else if (p instanceof PlayerPositionLookS2CPacket t) {
            EntityPosition cur = new EntityPosition(new Vec3d(x, y, z), Vec3d.ZERO, yaw, pitch);
            EntityPosition next = EntityPosition.apply(cur, t.change(), t.relatives());
            x = next.position().x; y = next.position().y; z = next.position().z;
            yaw = next.yaw(); pitch = next.pitch();
            c.send(new TeleportConfirmC2SPacket(t.teleportId()));
            c.send(new PlayerMoveC2SPacket.Full(x, y, z, yaw, pitch, true, false));
        } else if (p instanceof PlayerListS2CPacket pl) {
            for (PlayerListS2CPacket.Entry e : pl.getPlayerAdditionEntries()) {
                if (e.profile() != null) names.put(e.profileId(), e.profile().name());
            }
        } else if (p instanceof GameMessageS2CPacket gm) {
            if (!gm.overlay()) log(gm.content().getString());
        } else if (p instanceof ProfilelessChatMessageS2CPacket pc) {
            log(pc.message().getString());
        } else if (p instanceof ChatMessageS2CPacket cm) {
            chatMessage(c, cm);
        } else if (p instanceof ResourcePackSendS2CPacket r) {
            resourcePack(c, r);
        } else if (p instanceof CookieRequestS2CPacket ck) {
            c.send(new CookieResponseC2SPacket(ck.key(), (byte[]) null));
        } else if (p instanceof ServerTransferS2CPacket) {
            fail("сервер перенаправляет на другой адрес");
        } else if (p instanceof DisconnectS2CPacket d) {
            fail(d.reason().getString());
        }
    }

    private void chatMessage(ClientConnection c, ChatMessageS2CPacket cm) {
        String text = "";
        Optional<MessageBody> body = cm.body().toBody(sigStorage);
        if (body.isPresent()) {
            sigStorage.add(body.get(), cm.signature());
            text = body.get().content();
        }
        if (cm.unsignedContent() != null) text = cm.unsignedContent().getString();
        MessageSignatureData sig = cm.signature();
        if (sig != null) {                                       // the server counts what we have "seen"; without this it kicks us
            synchronized (collector) {
                if (collector.add(sig, true) && collector.getMessageCount() > 64) {
                    int n = collector.resetMessageCount();
                    if (n > 0) c.send(new MessageAcknowledgmentC2SPacket(n));
                }
            }
        }
        String who = names.getOrDefault(cm.sender(), "?");
        log("<" + who + "> " + text);
    }
}
