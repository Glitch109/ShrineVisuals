package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Auto > "АвтоСвап": one key swaps your left hand with a chosen item, right on the run, without opening the inventory.
 * You pick the two items yourself (hold an item and press the row in the settings) and the key yourself.
 *
 * Offhand is item A: the key brings item B (from the hotbar, or from the whole inventory if that is switched on) to the
 * left hand, and the next press brings A back. Offhand is something else: the key brings A, or B if there is no A.
 */
final class AutoSwap {
    private AutoSwap() {}

    static final String KEY = "auto.swap.on", K_KEY = "auto.swap.key", K_A = "auto.swap.a", K_B = "auto.swap.b",
            K_NAME_A = "auto.swap.a.name", K_NAME_B = "auto.swap.b.name", K_INV = "auto.swap.inv", K_MSG = "auto.swap.msg";
    static final String DEF_A = "minecraft:totem_of_undying", DEF_B = "minecraft:shield";
    static final String DEF_NAME_A = "Тотем бессмертия", DEF_NAME_B = "Щит";
    static final int DEF_KEY = GLFW.GLFW_KEY_R;

    private static boolean down;

    private static String idOf(ItemStack s) {
        return s.isEmpty() ? "minecraft:air" : Registries.ITEM.getId(s.getItem()).toString();
    }

    private static boolean held() {
        int key = ShrineCfg.integer(K_KEY, DEF_KEY);
        if (key < 0) return false;
        long w = GLFW.glfwGetCurrentContext();
        if (w == 0L) return false;
        if (key >= 1000) return GLFW.glfwGetMouseButton(w, key - 1000) == GLFW.GLFW_PRESS;
        return GLFW.glfwGetKey(w, key) == GLFW.GLFW_PRESS;
    }

    /** Called every client tick. */
    static void tick(MinecraftClient mc) {
        boolean now = held();
        boolean edge = now && !down;
        down = now;                                   // also tracked while a screen is open, so closing it never fires a swap
        if (!edge || !ShrineCfg.bool(KEY, true)) return;
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.interactionManager == null) return;
        swap(mc);
    }

    private static String nameOf(String id) {
        return id.equals(ShrineCfg.str(K_A, DEF_A)) ? ShrineCfg.str(K_NAME_A, DEF_NAME_A) : ShrineCfg.str(K_NAME_B, DEF_NAME_B);
    }

    private static int find(PlayerEntity p, String id, boolean wholeInventory) {
        int max = wholeInventory ? 36 : 9;
        for (int i = 0; i < max; i++) if (idOf(p.getInventory().getStack(i)).equals(id)) return i;
        return -1;
    }

    private static void toast(MinecraftClient mc, String s) {
        if (ShrineCfg.bool(K_MSG, true)) mc.player.sendMessage(Text.literal(s), true);
    }

    private static void swap(MinecraftClient mc) {
        PlayerEntity p = mc.player;
        String a = ShrineCfg.str(K_A, DEF_A), b = ShrineCfg.str(K_B, DEF_B);
        boolean whole = ShrineCfg.bool(K_INV, false);
        String off = idOf(p.getOffHandStack());
        String want;
        int slot;
        if (off.equals(a)) { want = b; slot = find(p, b, whole); }
        else if (off.equals(b)) { want = a; slot = find(p, a, whole); }
        else {
            want = a; slot = find(p, a, whole);
            if (slot < 0) { want = b; slot = find(p, b, whole); }
        }
        if (slot < 0) { toast(mc, "АвтоСвап: нет предмета — " + nameOf(want)); return; }
        int containerSlot = slot < 9 ? 36 + slot : slot;       // hotbar slots are 36..44 in the player's container, the rest keep their number
        mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, containerSlot, 40, SlotActionType.SWAP, p);   // 40 = swap with the left hand
        toast(mc, "АвтоСвап: " + nameOf(want) + " → левая рука");
    }

    // ---------- used by the settings window ----------
    /** The row text under "Предмет 1 / 2". */
    static String hintFor(String key) {
        boolean a = K_A.equals(key);
        return "Сейчас: " + ShrineCfg.str(a ? K_NAME_A : K_NAME_B, a ? DEF_NAME_A : DEF_NAME_B) + "  ·  возьми предмет в руку и нажми";
    }

    /** Remembers the item in the main hand as item 1 or 2. */
    static void remember(MinecraftClient mc, String key) {
        if (mc.player == null) return;
        ItemStack s = mc.player.getMainHandStack();
        if (s.isEmpty()) { mc.player.sendMessage(Text.literal("АвтоСвап: возьми предмет в главную руку и нажми ещё раз"), true); return; }
        boolean a = K_A.equals(key);
        ShrineCfg.setStr(a ? K_A : K_B, idOf(s));
        ShrineCfg.setStr(a ? K_NAME_A : K_NAME_B, s.getName().getString());
        ShrineCfg.save();
    }

    static String keyName(int k) {
        if (k < 0) return "Не задана";
        if (k >= 1000) return switch (k - 1000) {
            case 2 -> "Колёсико";
            case 3 -> "Мышь 4";
            case 4 -> "Мышь 5";
            default -> "Мышь " + (k - 999);
        };
        if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F12) return "F" + (k - GLFW.GLFW_KEY_F1 + 1);
        String n = switch (k) {
            case GLFW.GLFW_KEY_SPACE -> "Пробел";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "L Shift";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "R Shift";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "L Ctrl";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "R Ctrl";
            case GLFW.GLFW_KEY_LEFT_ALT -> "L Alt";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "R Alt";
            case GLFW.GLFW_KEY_TAB -> "Tab";
            case GLFW.GLFW_KEY_CAPS_LOCK -> "Caps";
            case GLFW.GLFW_KEY_ENTER -> "Enter";
            case GLFW.GLFW_KEY_UP -> "Вверх";
            case GLFW.GLFW_KEY_DOWN -> "Вниз";
            case GLFW.GLFW_KEY_LEFT -> "Влево";
            case GLFW.GLFW_KEY_RIGHT -> "Вправо";
            default -> null;
        };
        if (n != null) return n;
        String g = GLFW.glfwGetKeyName(k, 0);
        return g != null ? g.toUpperCase() : "Клавиша " + k;
    }
}
