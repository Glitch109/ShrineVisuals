package com.shrine;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static com.shrine.Gfx.*;

/**
 * Visual > "Частицы мира": a slow cloud of particles floating in the air around you.
 * Four kinds: glowing wireframe cubes, soft glowing orbs, snowflakes and twinkling stars.
 * The particles live in the world (they stay where they are when you walk), the 3D points are projected to the screen
 * with the same view as {@link Predictions}.
 */
final class WorldParticles {
    private WorldParticles() {}

    static final String KEY = "wp.on", K_TYPE = "wp.type", K_COUNT = "wp.count", K_SIZE = "wp.size", K_COLOR = "wp.color";
    static final String[] TYPES = {"Кубы", "Свечение", "Снежинки", "Звёзды"};

    private static final double RANGE = 14.0;      // radius of the cloud around the camera, blocks
    private static final Random RND = new Random();

    private static final class P {
        double x, y, z, vx, vy, vz;
        float size, a0, a1, s0, s1, phase;
    }

    private static final List<P> LIST = new ArrayList<>();
    private static long last;
    private static int lastType = -1;

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "world_particles"),
                (ctx, tick) -> render(ctx, tick));
    }

    private static void spawn(P p, double camX, double camY, double camZ, int type) {
        double dx, dy, dz, l;
        do {
            dx = RND.nextGaussian(); dy = RND.nextGaussian(); dz = RND.nextGaussian();
            l = Math.sqrt(dx * dx + dy * dy + dz * dz);
        } while (l < 1e-3);
        double r = RANGE * Math.cbrt(RND.nextDouble());
        p.x = camX + dx / l * r;
        p.y = camY + dy / l * r * 0.7;
        p.z = camZ + dz / l * r;
        p.a0 = RND.nextFloat() * 6.2832f;
        p.a1 = RND.nextFloat() * 6.2832f;
        p.s0 = (RND.nextFloat() - 0.5f) * 1.2f;
        p.s1 = (RND.nextFloat() - 0.5f) * 1.2f;
        p.phase = RND.nextFloat() * 6.2832f;
        double sp = 0.15 + RND.nextDouble() * 0.25;
        switch (type) {
            case 0 -> {                                  // cubes: mostly small, a few big ones
                p.size = RND.nextFloat() < 0.15f ? 0.35f + RND.nextFloat() * 0.35f : 0.08f + RND.nextFloat() * 0.18f;
                p.vx = (RND.nextDouble() - 0.5) * sp; p.vy = (RND.nextDouble() - 0.5) * sp * 0.6; p.vz = (RND.nextDouble() - 0.5) * sp;
            }
            case 1 -> {                                  // orbs: soft and big, drifting up
                p.size = 0.25f + RND.nextFloat() * 0.6f;
                p.vx = (RND.nextDouble() - 0.5) * sp * 0.6; p.vy = 0.05 + RND.nextDouble() * 0.12; p.vz = (RND.nextDouble() - 0.5) * sp * 0.6;
            }
            case 2 -> {                                  // snow: small, falling
                p.size = 0.04f + RND.nextFloat() * 0.06f;
                p.vx = (RND.nextDouble() - 0.5) * 0.2; p.vy = -(0.25 + RND.nextDouble() * 0.3); p.vz = (RND.nextDouble() - 0.5) * 0.2;
            }
            default -> {                                 // stars: twinkling, almost still
                p.size = 0.12f + RND.nextFloat() * 0.25f;
                p.vx = (RND.nextDouble() - 0.5) * 0.08; p.vy = (RND.nextDouble() - 0.5) * 0.05; p.vz = (RND.nextDouble() - 0.5) * 0.08;
            }
        }
    }

    private static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, true) || !mc.options.getPerspective().isFirstPerson()) return;
        float td = tick.getTickProgress(true);
        Predictions.setupView(mc, td);

        long now = Util.getMeasuringTimeMs();
        float dt = last == 0L ? 0.016f : Math.min(0.1f, (now - last) / 1000f);
        last = now;
        float t = (now % 600000L) / 1000f;

        int type = Math.max(0, Math.min(TYPES.length - 1, ShrineCfg.integer(K_TYPE, 0)));
        int count = Math.max(5, Math.min(150, ShrineCfg.integer(K_COUNT, 45)));
        float scale = Math.max(0.5f, Math.min(2.5f, ShrineCfg.num(K_SIZE, 1f)));
        int ci = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 1)));
        int rgb = ShrineGui.PALETTE[ci];

        if (type != lastType) { LIST.clear(); lastType = type; }
        while (LIST.size() > count) LIST.remove(LIST.size() - 1);
        while (LIST.size() < count) { P p = new P(); spawn(p, Predictions.cx, Predictions.cy, Predictions.cz, type); LIST.add(p); }

        for (P p : LIST) {
            p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
            if (type == 2) { p.x += Math.sin(t * 0.9 + p.phase) * 0.12 * dt; p.z += Math.cos(t * 0.7 + p.phase) * 0.12 * dt; }
            double dx = p.x - Predictions.cx, dy = p.y - Predictions.cy, dz = p.z - Predictions.cz;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > RANGE) {                                  // left the cloud: reappear somewhere else (it is invisible there anyway)
                spawn(p, Predictions.cx, Predictions.cy, Predictions.cz, type);
                continue;
            }
            float fade = (float) Math.min(1.0, (RANGE - dist) / 4.0) * (float) Math.min(1.0, Math.max(0.0, (dist - 0.7) / 1.5));
            if (fade <= 0.01f) continue;
            Vec3d c = new Vec3d(p.x, p.y, p.z);
            switch (type) {
                case 0 -> cube(ctx, p, c, scale, rgb, fade, t);
                case 1 -> orb(ctx, p, c, scale, rgb, fade, t);
                case 2 -> flake(ctx, p, c, scale, rgb, fade);
                default -> star(ctx, p, c, scale, rgb, fade, t);
            }
        }
    }

    /** Pixel size on the screen of something with this size in blocks at this depth. */
    private static float px(float world, float depth, float min, float max) {
        return Math.max(min, Math.min(max, (float) (world * Predictions.sh / (2.0 * Predictions.tanH * depth))));
    }

    private static void cube(DrawContext ctx, P p, Vec3d c, float scale, int rgb, float fade, float t) {
        double h = p.size * scale;
        double a = p.a0 + p.s0 * t, b = p.a1 + p.s1 * t;
        double ca = Math.cos(a), sa = Math.sin(a), cb = Math.cos(b), sb = Math.sin(b);
        Vec3d[] v = new Vec3d[8];
        for (int i = 0; i < 8; i++) {
            double x = (i & 1) == 0 ? -h : h, y = (i & 2) == 0 ? -h : h, z = (i & 4) == 0 ? -h : h;
            double x1 = x * ca + z * sa, z1 = -x * sa + z * ca;          // turn around Y
            double y2 = y * cb - z1 * sb, z2 = y * sb + z1 * cb;         // then tip around X
            v[i] = new Vec3d(c.x + x1, c.y + y2, c.z + z2);
        }
        float th = 0.8f;
        int[][] edges = {{0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
        for (int[] e : edges) Predictions.seg(ctx, v[e[0]], v[e[1]], th, rgb, 0.9f * fade);
    }

    private static void orb(DrawContext ctx, P p, Vec3d c, float scale, int rgb, float fade, float t) {
        float[] s = Predictions.project(c);
        if (s == null) return;
        float pulse = 0.8f + 0.2f * (float) Math.sin(t * 1.3f + p.phase);
        float d = px(p.size * scale, s[2], 3f, 90f);
        centered(ctx, GLOW, s[0], s[1], d * 2.4f, d * 2.4f, argb(0.30f * fade * pulse, rgb));
        centered(ctx, GLOW, s[0], s[1], d * 1.2f, d * 1.2f, argb(0.60f * fade * pulse, rgb));
        centered(ctx, DISC, s[0], s[1], Math.max(1.5f, d * 0.28f), Math.max(1.5f, d * 0.28f), argb(0.9f * fade * pulse, 0xFFFFFF));
    }

    private static void flake(DrawContext ctx, P p, Vec3d c, float scale, int rgb, float fade) {
        float[] s = Predictions.project(c);
        if (s == null) return;
        float d = px(p.size * scale, s[2], 1.2f, 6f);
        centered(ctx, GLOW, s[0], s[1], d * 2.6f, d * 2.6f, argb(0.25f * fade, rgb));
        centered(ctx, DISC, s[0], s[1], d, d, argb(0.9f * fade, rgb));
    }

    private static void star(DrawContext ctx, P p, Vec3d c, float scale, int rgb, float fade, float t) {
        float[] s = Predictions.project(c);
        if (s == null) return;
        float tw = 0.5f + 0.5f * (float) Math.sin(t * (1.5f + p.s0 * 2f) + p.phase);       // twinkle
        float d = px(p.size * scale, s[2], 2f, 40f) * (0.55f + 0.45f * tw);
        float al = fade * (0.35f + 0.65f * tw);
        centered(ctx, GLOW, s[0], s[1], d * 2.2f, d * 2.2f, argb(0.45f * al, rgb));
        Predictions.line(ctx, s[0] - d, s[1], s[0] + d, s[1], 0.9f, argb(al, rgb));
        Predictions.line(ctx, s[0], s[1] - d, s[0], s[1] + d, 0.9f, argb(al, rgb));
        centered(ctx, DISC, s[0], s[1], Math.max(1.5f, d * 0.22f), Math.max(1.5f, d * 0.22f), argb(al, 0xFFFFFF));
    }
}
