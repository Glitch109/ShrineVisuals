package com.shrine;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Player > "Круги прыжка": a ring that spreads over the ground from the spot where you left it, then fades out.
 * Written for this project: it uses the same world->screen projection as {@link Predictions} and {@link WorldParticles}.
 * Three looks: one ring, a double ring (second ring follows a moment later) and a ring of rotating arcs.
 */
final class JumpCircles {
    private JumpCircles() {}

    static final String KEY = "jc.on", K_TYPE = "jc.type", K_SIZE = "jc.size", K_TIME = "jc.time", K_COLOR = "jc.color";
    static final String[] TYPES = {"Кольцо", "Двойное кольцо", "Дуги"};

    private static final int STEPS = 56;           // points of a full circle
    private static final int MAX_ALIVE = 24;       // hard cap so bunny-hopping cannot flood the screen

    /** One ring: where it started and when. */
    private record Ring(double x, double y, double z, long born) {}

    private static final List<Ring> RINGS = new ArrayList<>();
    private static boolean wasOnGround = true;

    static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(JumpCircles::tick);
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "jump_circles"),
                (ctx, tick) -> render(ctx, tick));
    }

    // ---------- spawning: the tick where the feet leave the ground while moving up ----------
    private static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) { RINGS.clear(); wasOnGround = true; return; }
        boolean ground = mc.player.isOnGround();
        if (ShrineCfg.bool(KEY, true) && wasOnGround && !ground && mc.player.getVelocity().y > 0.05
                && !mc.player.isTouchingWater() && !mc.player.isClimbing() && !mc.player.hasVehicle()) {
            if (RINGS.size() >= MAX_ALIVE) RINGS.remove(0);
            RINGS.add(new Ring(mc.player.getX(), mc.player.getY() + 0.03, mc.player.getZ(), Util.getMeasuringTimeMs()));
        }
        wasOnGround = ground;
    }

    // ---------- drawing ----------
    private static void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (RINGS.isEmpty() || mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, true) || !mc.options.getPerspective().isFirstPerson()) return;
        Predictions.setupView(mc, tick.getTickProgress(true));

        int type = Math.max(0, Math.min(TYPES.length - 1, ShrineCfg.integer(K_TYPE, 0)));
        float radius = Math.max(0.5f, Math.min(4f, ShrineCfg.num(K_SIZE, 1.6f)));
        float life = Math.max(0.3f, Math.min(3f, ShrineCfg.num(K_TIME, 1.1f))) * 1000f;
        int ci = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 1)));
        int rgb = ShrineGui.PALETTE[ci];
        long now = Util.getMeasuringTimeMs();

        for (Iterator<Ring> it = RINGS.iterator(); it.hasNext(); ) {
            Ring r = it.next();
            float age = (now - r.born()) / life;
            if (age >= 1f) { it.remove(); continue; }
            switch (type) {
                case 0 -> circle(ctx, r, radius * grow(age), 1.5f, rgb, fade(age), 0f, 1);
                case 1 -> {
                    circle(ctx, r, radius * grow(age), 1.5f, rgb, fade(age), 0f, 1);
                    float a2 = (age - 0.18f) / 0.82f;                       // the second ring starts a little later
                    if (a2 > 0f) circle(ctx, r, radius * 0.7f * grow(a2), 1.1f, rgb, fade(a2) * 0.8f, 0f, 1);
                }
                default -> circle(ctx, r, radius * grow(age), 1.8f, rgb, fade(age), age * 2.4f, 4);   // arcs turn while they spread
            }
        }
    }

    /** Fast at the start, settling at the end. */
    private static float grow(float t) { float u = 1f - t; return 1f - u * u * u; }

    /** Fully visible for a moment, then fading. */
    private static float fade(float t) { float u = 1f - t; return u * u; }

    /**
     * A flat circle on the ground. {@code every}: 1 = closed ring; 4 = draw only a few segments in a row, then skip
     * the same number (a ring made of arcs). {@code spin}: turns the circle (radians).
     */
    private static void circle(DrawContext ctx, Ring r, float rad, float th, int rgb, float alpha, float spin, int every) {
        if (rad < 0.02f || alpha < 0.02f) return;
        Vec3d prev = null;
        for (int i = 0; i <= STEPS; i++) {
            double a = spin + i * (Math.PI * 2.0 / STEPS);
            Vec3d p = new Vec3d(r.x() + Math.cos(a) * rad, r.y(), r.z() + Math.sin(a) * rad);
            boolean visible = every == 1 || ((i / every) % 2 == 0);
            if (prev != null && visible) Predictions.seg(ctx, prev, p, th, rgb, alpha);
            prev = p;
        }
    }
}
